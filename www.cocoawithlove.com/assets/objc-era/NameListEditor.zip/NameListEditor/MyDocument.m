//
//  MyDocument.m
//  NameListEditor
//
//  Created by Matt Gallagher on 1/09/08.
//  Copyright Matt Gallagher 2008 . All rights reserved.
//
//  Permission is given to use this source code file without charge in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "MyDocument.h"

//
// This category on NSMutableString makes it KVC compliant for the key "string"
// (since it already has a "setString:" method.
//
@implementation NSMutableString (StringAccessor)

- (NSString *)string
{
	return self;
}

@end

@implementation MyDocument

@synthesize names;

- (id)init
{
    self = [super init];
    if (self) {
    
		self.names = [NSMutableArray array];
    }
    return self;
}

- (void)dealloc
{
	self.names = nil;
	[super dealloc];
}


- (NSString *)windowNibName
{
    return @"MyDocument";
}

- (void)windowControllerDidLoadNib:(NSWindowController *) aController
{
    [super windowControllerDidLoadNib:aController];
}

- (NSError *)lazyProgrammerError
{
	NSString *lazyProgrammerDomain = @"com.lazyprogrammer.error";
	const NSInteger lazyProgrammerError = 0;
	NSDictionary *description = [NSDictionary dictionaryWithObject:NSLocalizedString(@"An error occurred but the lazy programmer can't be bothered to explain why.", @"") forKey:NSLocalizedDescriptionKey];
	NSError *lazyError = [NSError errorWithDomain:lazyProgrammerDomain code:lazyProgrammerError userInfo:description];
	return lazyError;
}

- (NSData *)dataOfType:(NSString *)typeName error:(NSError **)outError
{
    if (![typeName isEqualTo:@"DocumentType"])
	{
		*outError = [self lazyProgrammerError];
		return nil;
	}

	return [NSKeyedArchiver archivedDataWithRootObject:self.names];
}

- (BOOL)readFromData:(NSData *)data ofType:(NSString *)typeName error:(NSError **)outError
{
	self.names = [NSKeyedUnarchiver unarchiveObjectWithData:data];
	
	if (![self.names isKindOfClass:[NSMutableArray class]])
	{
		*outError = [self lazyProgrammerError];
		return NO;
	}
	else
	{
		for (NSObject *object in [self names])
		{
			if (![object isKindOfClass:[NSMutableString class]])
			{
				*outError = [self lazyProgrammerError];
				return NO;
			}
		}
	}
	
    return YES;
}

@end
