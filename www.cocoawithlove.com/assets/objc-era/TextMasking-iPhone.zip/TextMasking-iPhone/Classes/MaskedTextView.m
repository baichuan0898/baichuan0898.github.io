//
//  MaskedTextView.m
//  TextMasking
//
//  Created by Matt Gallagher on 2009/09/08.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "MaskedTextView.h"

@implementation MaskedTextView

@synthesize text;

- (void)setText:(NSString *)newText
{
	if (newText != text)
	{
		[text release];
		text = [newText retain];
		[self setNeedsDisplay];
	}
}

- (void)drawRect:(CGRect)rect
{
	CGContextRef context = UIGraphicsGetCurrentContext();

	// Draw a dark gray background
	[[UIColor darkGrayColor] setFill];
	CGContextFillRect(context, rect);

	// Draw the text upside-down
	CGContextSaveGState(context);
	CGContextTranslateCTM(context, 0, rect.size.height);
	CGContextScaleCTM(context, 1.0, -1.0);
	[[UIColor whiteColor] setFill];
	[text drawInRect:rect withFont:[UIFont fontWithName:@"HelveticaNeue-Bold" size:124]];
	CGContextRestoreGState(context);

	// Create an image mask from what we've drawn so far
	CGImageRef alphaMask = CGBitmapContextCreateImage(context);

	// Draw a white background (overwriting the previous work)
	[[UIColor whiteColor] setFill];
	CGContextFillRect(context, rect);

    // Draw the image, clipped by the mask
	CGContextSaveGState(context);
	CGContextClipToMask(context, rect, alphaMask);

	[[UIImage imageNamed:@"shuttle.jpg"] drawInRect:rect];
	CGContextRestoreGState(context);
	CGImageRelease(alphaMask);
}

@end

