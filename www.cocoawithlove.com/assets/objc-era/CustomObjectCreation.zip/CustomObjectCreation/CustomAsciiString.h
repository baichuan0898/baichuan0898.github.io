//
//  CustomAsciiString.h
//  CustomObjectCreation
//
//  Created by Matt Gallagher on 2010/08/30.
//  Copyright 2010 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import <Foundation/Foundation.h>

#define CUSTOM_ASCII_STRING_LENGTH 24
#define CUSTOM_ASCII_STRING_ARRAY_COUNT 250000

@interface CustomAsciiString : NSString
{
	char value[CUSTOM_ASCII_STRING_LENGTH];
}
@end

@interface CustomAsciiStringArray : NSArray
{
	NSInteger count;
	char *stringArray;
}
@end
