//
//  CustomAsciiString.m
//  CustomObjectCreation
//
//  Created by Matt Gallagher on 2010/08/30.
//  Copyright 2010 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "CustomAsciiString.h"
#import <objc/runtime.h>

#define RAISE_METHOD_NOT_AVAILABLE_EXCEPTION() \
	[NSException \
		raise:NSInternalInconsistencyException \
		format:@"Method %s should not be invoked on class %s",\
			sel_getName(_cmd), class_getName([self class])];

//
// GetCustomAsciiStringLine
//
// Reads an Ascii string from file until the EOF or newline. A maximum of
// CUSTOM_ASCII_STRING_LENGTH characters will be stored in value with the
// remainder being set to nil.
//
// returns NO if EOF was read, YES otherwise
//
BOOL GetCustomAsciiStringLine(FILE *file, char *value)
{
	long charsRead = 0;
	char c;
    while (charsRead < CUSTOM_ASCII_STRING_LENGTH)
	{
        c = fgetc(file);
        if(c == EOF)
		{
            return NO;
		}
		if (c == '\n')
		{
			return YES;
		}
		value[charsRead++] = c;
	}
	
	while (1)
	{
        c = fgetc(file);
        if(c == EOF)
		{
            return NO;
		}
		if (c == '\n')
		{
			return YES;
		}
	}
	
	return NO;
}

@implementation CustomAsciiString

//
// allocWithZone:
//
// Throw an exception if this class is inadvertently alloc'd
//
+ (id)allocWithZone:(NSZone *)zone
{
	RAISE_METHOD_NOT_AVAILABLE_EXCEPTION();
	return nil;
}

//
// init
//
// Throw an exception if an instance is inadvertently init'd
//
- (id)init
{
	RAISE_METHOD_NOT_AVAILABLE_EXCEPTION();
	return nil;
}

//
// retain
//
// Ignore retains
//
- (id)retain
{
	return self;
}

//
// release
//
// Ignore releases
//
- (void)release
{
}

//
// length
//
// returns the length of the ascii string (runtime calculated)
//
- (NSUInteger)length
{
	for (int i = 0; i < CUSTOM_ASCII_STRING_LENGTH; i++)
	{
		if (value[i] == '\0')
		{
			return i;
		}
	}
	return CUSTOM_ASCII_STRING_LENGTH;
}

//
// characterAtIndex:
//
// returns a unichar for the ascii char at "index"
//
- (unichar)characterAtIndex:(NSUInteger)index
{
	return (unichar)value[index];
}

//
// rawCharacterBuffer
//
// returns the rawCharacterBuffer (used by CustomAsciiStringArray)
//
- (char *)rawCharacterBuffer
{
	return value;
}

@end

@implementation CustomAsciiStringArray

- (NSUInteger)count
{
	return count;
}

- (id)objectAtIndex:(NSUInteger)index
{
	NSAssert(index < CUSTOM_ASCII_STRING_ARRAY_COUNT, @"Index out of bounds");

	NSInteger runtimeCustomAsciiStringSize =
		class_getInstanceSize([CustomAsciiString class]);
	return (id)(stringArray + (runtimeCustomAsciiStringSize * index));
}

//
// init
//
// Creates the array by reading the strings from /usr/share/dict/words
//
// returns the allocated and initialized.
//
- (id)init
{
	self = [super init];
	if (self)
	{
		Class stringClass = [CustomAsciiString class];
		
		//
		// Allocated the array based on the runtime size of CustomAsciiString
		//
		NSInteger runtimeInstanceSize = class_getInstanceSize(stringClass);
		stringArray = calloc(
			runtimeInstanceSize,
			CUSTOM_ASCII_STRING_ARRAY_COUNT);
		if (!stringArray)
		{
			return nil;
		}
		
		//
		// Open the words file
		//
		FILE *file = fopen("/usr/share/dict/words", "r");
		if (!file)
		{
			return nil;
		}
		
		//
		// Set the isa pointer for all CustomAsciiStrings and read the string
		// data for each one
		//
		long stringIndex; 
		for (stringIndex = 0; stringIndex < CUSTOM_ASCII_STRING_ARRAY_COUNT; stringIndex++)
		{
			Class *currentStringIsa =
				(Class *)(stringArray + (runtimeInstanceSize * stringIndex));
			*currentStringIsa = stringClass;
			
			CustomAsciiString *currentString = (CustomAsciiString *)currentStringIsa;
			if (!GetCustomAsciiStringLine(file, [currentString rawCharacterBuffer]))
			{
				break;
			}
		}
		fclose(file);
		
		//
		// Set the array size based on the number of strings read
		//
		count = stringIndex;
	}
	
	return self;
}

//
// dealloc
//
// Frees the array (and all strings)
//
- (void)dealloc
{
	free(stringArray);
	[super dealloc];
}

@end
