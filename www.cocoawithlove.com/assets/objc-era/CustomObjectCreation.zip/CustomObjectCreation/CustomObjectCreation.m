//
//  CustomObjectCreation.m
//  CustomObjectCreation
//
//  Created by Matt Gallagher on 2010/08/30.
//  Copyright 2010 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import <sys/resource.h>
#import <Foundation/Foundation.h>
#import "NSString+SeparatingIntoComponents.h"
#import "CustomAsciiString.h"

int main (int argc, const char * argv[]) {
	struct rusage before, after;

	getrusage(RUSAGE_SELF, &before);

    NSAutoreleasePool * pool = nil;
	NSArray *words = nil;

	for (int i = 0; i < 20; i++)
	{
		[pool drain];
		pool = [[NSAutoreleasePool alloc] init];

	#define USE_STANDARD_STRINGS 1
	#if USE_STANDARD_STRINGS
		words = [[NSString
				stringWithContentsOfFile:@"/usr/share/dict/words"
				encoding:NSASCIIStringEncoding
				error:NULL]
			arrayBySeparatingIntoParagraphs];
	#else
		words = [[[CustomAsciiStringArray alloc] init] autorelease];
	#endif
	}
	
	[words retain];

    [pool drain];
	pool = [[NSAutoreleasePool alloc] init];

	getrusage(RUSAGE_SELF, &after);

	//
	// Output a little information about the array of strings read
	//
	NSInteger maxLength = 0;
	NSInteger totalLength = 0;
	for (NSString *word in words)
	{
		totalLength += [word length];
		if ([word length] > maxLength)
		{
			maxLength = [word length];
		}
	}
	NSLog(@"Maximum length is %ld", maxLength);
	NSLog(@"Average length is %f", (double)totalLength / (double)[words count]);
	NSLog(@"Total count is %ld", [words count]);

	//
	// Output information about memory usage and time taken
	//
	NSLog(@"Memory used = %ld", after.ru_maxrss - before.ru_maxrss);
	NSLog(@"Time taken = %f",
		(after.ru_utime.tv_sec + after.ru_stime.tv_sec) -
		(before.ru_utime.tv_sec + before.ru_stime.tv_sec) +
		1.0e-6 * ((after.ru_utime.tv_usec + after.ru_stime.tv_usec) -
			(before.ru_utime.tv_usec + before.ru_stime.tv_usec)));

    [pool drain];

    return 0;
}
