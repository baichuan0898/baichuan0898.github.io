//
//  ColumnSection.m
//  ColumnSection
//
//  Created by Matt Gallagher on 2010/03/08.
//  Copyright 2010 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "ColumnSection.h"

NSString * const ColumnSectionHeaderDataBinding = @"headerData";

NSString * const ColumnSectionClassKeyOption = @"sectionClassKey";

NSString * const ColumnSectionRowDisplayKeyOption = @"rowDisplayKey";
NSString * const ColumnSectionRowClassKeyOption = @"rowClassKey";

#define ReleaseDestinationRetainSource(a, b) [b retain];[a release];a=b;

@implementation ColumnSection

@synthesize rowDataArrayController;

@synthesize rowDisplayKey;
@synthesize rowClassKey;

@synthesize defaultClass;

@synthesize headerData;
@synthesize headerClass;

//
// rowDisplayData
//
// returns the array of display objects
//
- (NSArray *)rowDisplayData
{
	if (!rowDisplayKey)
	{
		return [rowDataArrayController arrangedObjects];
	}
	return [[rowDataArrayController arrangedObjects] valueForKeyPath:rowDisplayKey];
}

//
// rowData
//
// returns the array of rowData objects
//
- (NSArray *)rowData
{
	return [rowDataArrayController arrangedObjects];
}

//
// dealloc
//
// Release retained instance memory;
//
- (void)dealloc
{
	[rowClassKey release];
	rowClassKey = nil;

	[headerData release];
	headerData = nil;

	[rowDataArrayController release];
	rowDataArrayController = nil;

	[rowDisplayKey release];
	rowDisplayKey = nil;

	[super dealloc];
}

@end
