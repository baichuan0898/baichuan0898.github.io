//
//  ColumnPlugin.m
//  ColumnPlugin
//
//  Created by Matt Gallagher on 2010/03/15.
//  Copyright 2010 Matt Gallagher. All rights reserved.
//

#import "ColumnPlugin.h"

@implementation ColumnPlugin
- (NSArray *)libraryNibNames {
    return [NSArray arrayWithObject:@"ColumnPluginLibrary"];
}

- (NSArray *)requiredFrameworks {
    return [NSArray arrayWithObjects:[NSBundle bundleWithIdentifier:@"com.mattgallagher.ColumnPlugin"], nil];
}

@end
