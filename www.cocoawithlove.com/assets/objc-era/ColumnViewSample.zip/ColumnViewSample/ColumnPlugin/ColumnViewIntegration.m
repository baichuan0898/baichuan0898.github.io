//
//  ColumnView.m
//  ColumnPlugin
//
//  Created by Matt Gallagher on 2010/03/15.
//  Copyright 2010 Matt Gallagher. All rights reserved.
//

#import <InterfaceBuilderKit/InterfaceBuilderKit.h>
#import <ColumnPlugin/ColumnView.h>
#import <ColumnPlugin/ColumnSection.h>
#import "ColumnPluginInspector.h"


@implementation ColumnView ( ColumnView )

- (void)ibPopulateKeyPaths:(NSMutableDictionary *)keyPaths {
    [super ibPopulateKeyPaths:keyPaths];
	
    [[keyPaths objectForKey:IBAttributeKeyPaths]
		addObjectsFromArray:
			[NSArray arrayWithObjects:
				ColumnViewSectionContentKeyOption,
				ColumnSectionRowDisplayKeyOption,
				ColumnSectionClassKeyOption,
				ColumnSectionRowClassKeyOption,
				ColumnViewSectionHeaderDataKeyOption,
				ColumnViewSectionHeaderClassKeyOption,
				ColumnViewAllSectionsSortKeyOption,
				ColumnViewSectionRowSortKeyOption,
			nil]];
}

- (void)ibPopulateAttributeInspectorClasses:(NSMutableArray *)classes {
    [super ibPopulateAttributeInspectorClasses:classes];
    [classes addObject:[ColumnPluginInspector class]];
}

@end
