//
//  ColumnPluginInspector.m
//  ColumnPlugin
//
//  Created by Matt Gallagher on 2010/03/15.
//  Copyright 2010 Matt Gallagher. All rights reserved.
//

#import "ColumnPluginInspector.h"

@implementation ColumnPluginInspector

- (NSString *)viewNibName {
	return @"ColumnPluginInspector";
}

- (void)refresh {
	// Synchronize your inspector's content view with the currently selected objects.
	[super refresh];
}

@end
