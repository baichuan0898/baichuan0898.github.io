//
//  ColumnPlugin.h
//  ColumnPlugin
//
//  Created by Matt Gallagher on 2010/03/15.
//  Copyright 2010 Matt Gallagher. All rights reserved.
//

#import <InterfaceBuilderKit/InterfaceBuilderKit.h>

@interface ColumnPlugin : IBPlugin {

}

@end
