//
//  RowView.m
//  ColumnView
//
//  Created by Matt Gallagher on 2010/03/08.
//  Copyright 2010 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "RowView.h"
#import "ColumnView.h"
#import "ColumnSection.h"

@implementation RowView

@synthesize row;
@synthesize section;
@synthesize selected;

const NSInteger RowViewSectionHeaderIndex = -1;

//
// heightWithRowData:forRow:inSection:
//
// Determines the height that the row would be given the data and position
//
// Parameters:
//    aRowDataObject - the data
//    aRow - the index in the section
//    aSection - the section index
//
// returns the height for the row
//
+ (CGFloat)heightWithRowData:(id)aRowDataObject
	forRow:(NSInteger)aRow
	inSection:(NSInteger)aSection
{
	if (aRow == RowViewSectionHeaderIndex)
	{
		return 50;
	}
	return 40;
}

//
// configureTextField:
//
// Applies styling to the text field based on whether it will be used for a
// header or regular row.
//
// Parameters:
//    forHeader - whether the text field will be used for a header row
//
- (void)configureTextField:(BOOL)forHeader
{
	if (forHeader)
	{
		NSShadow *shadow = [[[NSShadow alloc] init] autorelease];
		[shadow setShadowOffset:NSMakeSize(0, -1)];
		[shadow setShadowColor:[NSColor blackColor]];
		[shadow setShadowBlurRadius:1.0];
		[textField setFont:[NSFont boldSystemFontOfSize:14]];
		[textField setWantsLayer:YES];
		[textField setShadow:shadow];
		[textField setTextColor:[NSColor whiteColor]];

		NSRect bounds = [self bounds];
		bounds.size.height -= 30;
		bounds.size.width -= 5;
		bounds.origin.x += 5;
		bounds.origin.y += 6;
		[textField setFrame:bounds];
	}
	else
	{
		[textField setTextColor:[NSColor blackColor]];
		[textField setFont:[NSFont systemFontOfSize:12]];
		[textField setWantsLayer:NO];
		[textField setShadow:nil];

		NSRect bounds = [self bounds];
		bounds.size.height -= 20;
		bounds.size.width -= 5;
		bounds.origin.x += 5;
		bounds.origin.y += 9;
		[textField setFrame:bounds];
	}
}

//
// textField
//
// returns the default text field, constructing it if necessary
//
- (NSTextField *)textField
{
	if (!textField)
	{
		textField = [[NSTextField alloc] init];
		[textField setEditable:NO];
		[textField setDrawsBackground:NO];
		[textField setBackgroundColor:[NSColor clearColor]];
		[textField setBezeled:NO];

		if (row == RowViewSectionHeaderIndex)
		{
			[self configureTextField:YES];
		}
		else
		{
			[self configureTextField:NO];
		}

		[self addSubview:textField];
	}

	return textField;
}

//
// rowData
//
// The RowView does not store its own data but this method is provided as
// a convenience to fetch it out of the row's section array controller.
//
// returns the row data for this row.
//
- (id)rowData
{
	return [[[self columnSection] rowData] objectAtIndex:row];
}

//
// columnView
//
// returns the superview, cast to a columnView
//
- (ColumnView *)columnView
{
	return (ColumnView *)[self superview];
}

//
// columnView
//
// returns the superview, cast to a columnView
//
- (ColumnSection *)columnSection
{
	return [[(ColumnView *)[self superview] columnSections] objectAtIndex:section];
}

//
// mouseDown:
//
// The default mouseDown selects the row in the columnView
//
// Parameters:
//    anEvent - the event
//
- (void)mouseDown:(NSEvent *)anEvent
{
	if (row == RowViewSectionHeaderIndex)
	{
		return;
	}
	
	[self.columnView selectRow:row inSection:section];
}

//
// drawRect:
//
// The default draw method draws a gradient, colored based on header/selected
// state
//
// Parameters:
//    rect - the rect to fill
//
- (void)drawRect:(NSRect)rect
{
	CGGradientRef gradient;
	if (selected)
	{
		static CGGradientRef selectionGradient = NULL;
		if (!selectionGradient)
		{
			CGColorSpaceRef colorspace = CGColorSpaceCreateDeviceRGB();
			CGFloat endpointColorComponents[2][4] =
				{{0.5, 0.75, 1.0, 1.0}, {0.75, 0.88, 1.0, 1.0}};
			const CGFloat endpointLocations[2] = {0.0, 1.0};
			selectionGradient =
				CGGradientCreateWithColorComponents(
					colorspace,
					(const CGFloat *)endpointColorComponents,
					endpointLocations,
					2);
			CFRelease(colorspace);
		}
		
		gradient = selectionGradient;
	}
	else if (row == RowViewSectionHeaderIndex)
	{
		static CGGradientRef headerGradient = NULL;
		if (!headerGradient)
		{
			CGColorSpaceRef colorspace = CGColorSpaceCreateDeviceRGB();
			CGFloat endpointColorComponents[2][4] =
				{{0.75, 0.75, 0.75, 1.0}, {0.85, 0.85, 0.85, 1.0}};
			const CGFloat endpointLocations[2] = {0.0, 1.0};
			headerGradient =
				CGGradientCreateWithColorComponents(
					colorspace,
					(const CGFloat *)endpointColorComponents,
					endpointLocations,
					2);
			CFRelease(colorspace);
		}
		
		gradient = headerGradient;
	}
	else
	{
		static CGGradientRef backgroundGradient = NULL;
		if (!backgroundGradient)
		{
			CGColorSpaceRef colorspace = CGColorSpaceCreateDeviceRGB();
			CGFloat endpointColorComponents[2][4] =
				{{0.98, 0.98, 0.98, 1.0}, {0.95, 0.95, 0.95, 1.0}};
			const CGFloat endpointLocations[2] = {0.0, 1.0};
			backgroundGradient =
				CGGradientCreateWithColorComponents(
					colorspace,
					(const CGFloat *)endpointColorComponents,
					endpointLocations,
					2);
			CFRelease(colorspace);
		}
		
		gradient = backgroundGradient;
	}

	CGContextRef context = [[NSGraphicsContext currentContext] graphicsPort];
	CGRect cgRect = NSRectToCGRect([self bounds]);
	CGContextDrawLinearGradient(
		context,
		gradient,
		CGPointMake(CGRectGetMinX(cgRect), CGRectGetMinY(cgRect) + 1),
		CGPointMake(CGRectGetMinX(cgRect), CGRectGetMaxY(cgRect)),
		0);
}

//
// setSelected:forRow:inSection:
//
// Sets the internal parameters before the row is configured for drawing. Should
// only be invoked from ColumnView.
//
// Parameters:
//    isSelected - selected state
//    aRow - the index of the row in the section
//    aSection - the index of the section in the ColumnView
//
- (void)setSelected:(BOOL)isSelected
	forRow:(NSInteger)aRow
	inSection:(NSInteger)aSection
{
	if (textField &&
		aRow == RowViewSectionHeaderIndex &&
		row != RowViewSectionHeaderIndex)
	{
		[self configureTextField:YES];
	}
	else if (textField &&
		aRow != RowViewSectionHeaderIndex &&
		row == RowViewSectionHeaderIndex)
	{
		[self configureTextField:NO];
	}
	
	if (selected != isSelected)
	{
		[self willChangeValueForKey:@"selected"];
		selected = isSelected;
		[self didChangeValueForKey:@"selected"];
	}

	if (row != aRow)
	{
		[self willChangeValueForKey:@"row"];
		row = aRow;
		[self didChangeValueForKey:@"row"];
	}
	
	if (section != aSection)
	{
		[self willChangeValueForKey:@"section"];
		section = aSection;
		[self didChangeValueForKey:@"section"];
	}
	
	[self setNeedsDisplay:YES];
}

//
// configureWithRowData:
//
// This is the standard method to override for updating when the data changes.
// The default behavior sets the text field to the description of the rowData.
//
// Parameters:
//    aRowDataObject - the rowData
//
- (void)configureWithRowData:(id)aRowDataObject
{
	[self.textField setStringValue:[aRowDataObject description]];
}

//
// dealloc
//
// Releases the instance memory
//
- (void)dealloc
{
	[textField release];
	textField = nil;

	[super dealloc];
}

@end
