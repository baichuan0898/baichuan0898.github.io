//
//  ColumnSection.h
//  ColumnView
//
//  Created by Matt Gallagher on 2010/03/08.
//  Copyright 2010 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import <Cocoa/Cocoa.h>

@interface ColumnSection : NSObject
{
	NSString *rowClassKey;
	NSString *rowDisplayKey;
	
	Class defaultClass;
	
	id headerData;
	Class headerClass;

	NSArrayController *rowDataArrayController;
}

@property (nonatomic, copy) NSString *rowDisplayKey;
@property (nonatomic, copy) NSString *rowClassKey;

@property (nonatomic, assign) Class defaultClass;

@property (nonatomic, readonly) NSArray *rowData;
@property (nonatomic, retain) id headerData;
@property (nonatomic, assign) Class headerClass;

@property (nonatomic, retain) NSArrayController *rowDataArrayController;

- (NSArray *)rowDisplayData;

@end

extern NSString * const ColumnSectionHeaderDataBinding;

extern NSString * const ColumnSectionClassKeyOption;

extern NSString * const ColumnSectionRowClassKeyOption;
extern NSString * const ColumnSectionRowDisplayKeyOption;
