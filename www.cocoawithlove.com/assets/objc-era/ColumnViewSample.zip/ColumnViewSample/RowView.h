//
//  RowView.h
//  ColumnView
//
//  Created by Matt Gallagher on 2010/03/08.
//  Copyright 2010 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import <Cocoa/Cocoa.h>

@class ColumnView;
@class ColumnSection;

@interface RowView : NSView
{
	NSInteger row;
	NSInteger section;
	BOOL selected;
	NSTextField *textField;
}

@property (nonatomic, readonly) NSInteger row;
@property (nonatomic, readonly) NSInteger section;
@property (nonatomic, readonly) id rowData;
@property (nonatomic, readonly) BOOL selected;
@property (nonatomic, readonly) NSTextField *textField;
@property (nonatomic, readonly) ColumnView *columnView;
@property (nonatomic, readonly) ColumnSection *columnSection;

+ (CGFloat)heightWithRowData:(id)aRowDataObject
	forRow:(NSInteger)aRow
	inSection:(NSInteger)aSection;
- (void)configureWithRowData:(id)aRowDataObject;
- (void)setSelected:(BOOL)isSelected
	forRow:(NSInteger)aRow
	inSection:(NSInteger)aSection;

@end

extern const NSInteger RowViewSectionHeaderIndex;