//
//  AddressBookDataController.m
//  ColumnView
//
//  Created by Matt Gallagher on 2010/03/08.
//  Copyright 2010 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "AddressBookDataController.h"
#import <AddressBook/AddressBook.h>
#import "SynthesizeSingleton.h"
#import "ColumnSection.h"

@implementation AddressBookDataController

SynthesizeSingletonForClassWithAccessor(AddressBookDataController, sharedController);

//
// init
//
// Init method for the object.
//
- (id)init
{
	self = [super init];
	if (self != nil)
	{
		[[NSNotificationCenter defaultCenter]
			addObserver:self
			selector:@selector(addressBookChanged:)
			name:kABDatabaseChangedExternallyNotification
			object:nil];
	}
	return self;
}

- (void)addressBookChanged:(NSNotification *)aNotification
{
	[self willChangeValueForKey:@"groups"];
	[groups release];
	groups = nil;
	[self groups];
	[self didChangeValueForKey:@"groups"];
}

- (NSArray *)groups
{
	if (!groups)
	{
		NSArray *abGroups = [[ABAddressBook sharedAddressBook] groups];
		if (!abGroups || [abGroups count] == 0)
		{
			groups =
				[NSArray arrayWithObject:
					[NSDictionary dictionaryWithObjectsAndKeys:
						[[ABAddressBook sharedAddressBook] people], @"members",
						NSLocalizedString(@"All people", nil), kABGroupNameProperty,
					nil]];
		}
		else
		{
			groups = [NSMutableArray arrayWithCapacity:[abGroups count]];
			for (ABGroup *group in abGroups)
			{
				[(NSMutableArray *)groups addObject:
					[NSDictionary dictionaryWithObjectsAndKeys:
						[group members], @"members",
						[group valueForKey:kABGroupNameProperty], kABGroupNameProperty,
					nil]];
			}
		}
		[groups retain];
	}
	return groups;
}

@end
