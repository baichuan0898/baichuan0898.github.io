//
//  ColumnView.h
//  ColumnView
//
//  Created by Matt Gallagher on 2010/03/08.
//  Copyright 2010 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import <Cocoa/Cocoa.h>

@interface ColumnView : NSView
{
	CGFloat *verticalOffsets;
	NSInteger rowCount;
	NSInteger topVisibleRow;
	NSInteger bottomVisibleRow;
	NSMutableArray *visibleRows;
	
	NSArray *columnSections;
	Class defaultHeaderClass;
	Class defaultRowClass;

	id observedSectionsArrayObject;
	NSString *observedSectionsArrayKeyPath;
	NSString *sectionContentKey;
	NSString *sectionClassKey;
	NSString *rowDisplayKey;
	NSString *rowClassKey;
	NSString *sectionHeaderDataKey;
	NSString *sectionHeaderClassKey;
	NSString *allSectionsSortKey;
	NSString *sectionRowSortKey;
	NSArrayController *selectedSectionArrayController;

	NSInteger selectedSection;
}

@property (nonatomic, retain) id observedSectionsArrayObject;
@property (nonatomic, copy) NSString *observedSectionsArrayKeyPath;
@property (nonatomic, copy) NSString *sectionContentKey;
@property (nonatomic, copy) NSString *sectionClassKey;
@property (nonatomic, copy) NSString *rowDisplayKey;
@property (nonatomic, copy) NSString *rowClassKey;
@property (nonatomic, copy) NSString *sectionHeaderDataKey;
@property (nonatomic, copy) NSString *sectionHeaderClassKey;
@property (nonatomic, copy) NSString *allSectionsSortKey;
@property (nonatomic, copy) NSString *sectionRowSortKey;
@property (nonatomic, retain) NSArray *sectionsArray;
@property (nonatomic, assign) Class defaultHeaderClass;
@property (nonatomic, assign) Class defaultRowClass;
@property (nonatomic, retain) NSArray *columnSections;
@property (nonatomic, readonly) NSArrayController *selectedSectionArrayController;

- (void)reloadData;
- (void)layoutViews;
- (void)redisplay;
- (void)selectRow:(NSInteger)aRow inSection:(NSInteger)aSection;
- (void)selectedRow:(NSInteger *)rowOut inSection:(NSInteger *)sectionOut;

@end

extern NSString * const ColumnViewSectionsArrayBinding;
extern NSString * const ColumnViewSectionContentKeyOption;

extern NSString * const ColumnViewAllSectionsSortKeyOption;
extern NSString * const ColumnViewSectionRowSortKeyOption;

extern NSString * const ColumnViewSectionHeaderDataKeyOption;
extern NSString * const ColumnViewSectionHeaderClassKeyOption;
