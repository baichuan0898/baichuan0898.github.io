//
//  ColumnView.m
//  ColumnView
//
//  Created by Matt Gallagher on 2010/03/08.
//  Copyright 2010 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "ColumnView.h"
#import "ColumnSection.h"
#import "RowView.h"

NSString * const ColumnViewSectionsArrayBinding = @"sectionsArray";
NSString * const ColumnViewSectionContentKeyOption = @"sectionContentKey";

NSString * const ColumnViewAllSectionsSortKeyOption = @"allSectionsSortKey";
NSString * const ColumnViewSectionRowSortKeyOption = @"sectionRowSortKey";

NSString * const ColumnViewSectionHeaderDataKeyOption = @"sectionHeaderDataKey";
NSString * const ColumnViewSectionHeaderClassKeyOption = @"sectionHeaderClassKey";

#define ReleaseDestinationRetainSource(a, b) [b retain];[a release];a=b;

#define BindingOptionDestSourceDefault(a, b, c) \
    if ([options objectForKey:ColumnViewSectionContentKeyOption]) \
	{ \
		if([[options objectForKey:b] length] == 0) \
		{ \
			self.a=[(id)c retain]; \
		} \
		else \
		{ \
			self.a=[options objectForKey:b];\
		} \
	}

@interface ColumnView (PrivateSetter)

@property (nonatomic, retain) NSArrayController *selectedSectionArrayController;

@end

@implementation ColumnView

@synthesize observedSectionsArrayObject;
@synthesize observedSectionsArrayKeyPath;
@synthesize sectionContentKey;
@synthesize sectionClassKey;
@synthesize rowDisplayKey;
@synthesize rowClassKey;
@synthesize sectionHeaderDataKey;
@synthesize sectionHeaderClassKey;
@synthesize allSectionsSortKey;
@synthesize sectionRowSortKey;

@synthesize defaultHeaderClass;
@synthesize defaultRowClass;
@synthesize columnSections;
@dynamic selectedSectionArrayController;

#pragma mark -- Bindings Integration

//
// initialize
//
// Make sure the ColumnViewSectionsArrayBinding is usable from InterfaceBuilder.
//
+ (void)initialize
{
	if (self == [ColumnView class])
	{
		[self exposeBinding:ColumnViewSectionsArrayBinding];
	}
}

//
// initWithCoder:
//
// Initialization method when waking from a NIB must set the options.
//
// Parameters:
//    decoder - the archive from the NIB
//
// returns the initialized object
//
- (id)initWithCoder:(NSCoder *)decoder
{
	self = [super initWithCoder:decoder];
	if (self != nil)
	{
		sectionContentKey = [[decoder decodeObjectForKey:ColumnViewSectionContentKeyOption] retain];
		rowDisplayKey = [[decoder decodeObjectForKey:ColumnSectionRowDisplayKeyOption] retain];
		sectionClassKey = [[decoder decodeObjectForKey:ColumnSectionClassKeyOption] retain];
		rowClassKey = [[decoder decodeObjectForKey:ColumnSectionRowClassKeyOption] retain];
		sectionHeaderDataKey = [[decoder decodeObjectForKey:ColumnViewSectionHeaderDataKeyOption] retain];
		sectionHeaderClassKey = [[decoder decodeObjectForKey:ColumnViewSectionHeaderClassKeyOption] retain];
		allSectionsSortKey = [[decoder decodeObjectForKey:ColumnViewAllSectionsSortKeyOption] retain];
		sectionRowSortKey = [[decoder decodeObjectForKey:ColumnViewSectionRowSortKeyOption] retain];
	}
	return self;
}

//
// encodeWithCoder:
//
// Used to store in a NIB file
//
// Parameters:
//    encoder - the NIB archive
//
- (void)encodeWithCoder:(NSCoder *)encoder
{
	[super encodeWithCoder:encoder];
    [encoder encodeObject:sectionContentKey forKey:ColumnViewSectionContentKeyOption];
    [encoder encodeObject:rowDisplayKey forKey:ColumnSectionRowDisplayKeyOption];
    [encoder encodeObject:sectionClassKey forKey:ColumnSectionClassKeyOption];
    [encoder encodeObject:rowClassKey forKey:ColumnSectionRowClassKeyOption];
    [encoder encodeObject:sectionHeaderDataKey forKey:ColumnViewSectionHeaderDataKeyOption];
    [encoder encodeObject:sectionHeaderClassKey forKey:ColumnViewSectionHeaderClassKeyOption];
    [encoder encodeObject:allSectionsSortKey forKey:ColumnViewAllSectionsSortKeyOption];
    [encoder encodeObject:sectionRowSortKey forKey:ColumnViewSectionRowSortKeyOption];
}

//
// AttributeDescription
//
// Convenience function to create attribute descriptions for the
// optionDescriptionsForBinding: method.
//
NSAttributeDescription *AttributeDescription(NSString *name, id defaultValue)
{
	NSAttributeDescription *description =
		[[[NSAttributeDescription alloc] init] autorelease];
	[description setName:name];
	[description setAttributeType:NSStringAttributeType];
	[description setAttributeValueClassName:@"NSString"];
	if (defaultValue)
	{
		[description setDefaultValue:defaultValue];
	}
	else
	{
		[description setDefaultValue:@""];
	}
	return (NSAttributeDescription *)description;
}

//
// optionDescriptionsForBinding:
//
// Bindings method implementation to aid InterfaceBuilder
//
// Parameters:
//    binding - the name of the binding
//
// returns the options associated with the named binding
//
- (NSArray *)optionDescriptionsForBinding:(NSString *)binding
{
	if ([binding isEqualToString:ColumnViewSectionsArrayBinding])
	{
		NSArray *options =
			[NSArray arrayWithObjects:
				AttributeDescription(ColumnViewSectionContentKeyOption, sectionContentKey ? sectionContentKey : @"self"),
				AttributeDescription(ColumnSectionRowDisplayKeyOption, rowDisplayKey),
				AttributeDescription(ColumnSectionClassKeyOption, sectionClassKey),
				AttributeDescription(ColumnSectionRowClassKeyOption, rowClassKey),
				AttributeDescription(ColumnViewSectionHeaderDataKeyOption, sectionHeaderDataKey),
				AttributeDescription(ColumnViewSectionHeaderClassKeyOption, sectionHeaderClassKey),
				AttributeDescription(ColumnViewAllSectionsSortKeyOption, allSectionsSortKey),
				AttributeDescription(ColumnViewSectionRowSortKeyOption, sectionRowSortKey),
			nil];
		return options;
	}
	
	return [super optionDescriptionsForBinding:binding];
}

//
// bind:toObject:withKeyPath:options:
//
// Establish bindings for the ColumnSection
//
// Parameters:
//    bindingName - name of the binding property to establish
//    observedObject - the starting point for the observed path
//    observedKeyPath - the key path that leads from the observedObject to the desired data
//    options - dictionary of extra options
//
- (void)bind:(NSString *)bindingName toObject:(id)observedObject
	withKeyPath:(NSString *)observedKeyPath options:(NSDictionary *)options
{
	if ([bindingName isEqualToString:ColumnViewSectionsArrayBinding])
	{
#ifndef IB_PLUGIN
		if (observedSectionsArrayObject &&
			[observedSectionsArrayObject isKindOfClass:[NSArrayController class]])
		{
			[observedSectionsArrayObject removeObserver:self forKeyPath:@"selectionIndex"];
		}
#endif
		self.observedSectionsArrayObject = observedObject;
		self.observedSectionsArrayKeyPath = observedKeyPath;

		if (observedSectionsArrayObject &&
			[observedSectionsArrayObject isKindOfClass:[NSArrayController class]])
		{
			if ([[(NSArrayController *)observedSectionsArrayObject arrangedObjects] count] > 0)
			{
				[(NSArrayController *)observedSectionsArrayObject setSelectionIndex:0];
				[self setSelectedSectionArrayController:
					[[columnSections objectAtIndex:0] rowDataArrayController]];
			}
		}

#ifndef IB_PLUGIN
		[observedSectionsArrayObject
			addObserver:self
			forKeyPath:@"selectionIndex"
			options:NSKeyValueObservingOptionPrior | NSKeyValueObservingOptionNew | NSKeyValueObservingOptionOld
			context:nil];
#endif
		
		BindingOptionDestSourceDefault(sectionContentKey, ColumnViewSectionContentKeyOption, @"self");
		BindingOptionDestSourceDefault(rowDisplayKey, ColumnSectionRowDisplayKeyOption, nil);
		BindingOptionDestSourceDefault(sectionClassKey, ColumnSectionClassKeyOption, nil);
		BindingOptionDestSourceDefault(rowClassKey, ColumnSectionRowClassKeyOption, nil);
		BindingOptionDestSourceDefault(sectionHeaderDataKey, ColumnViewSectionHeaderDataKeyOption, nil);
		BindingOptionDestSourceDefault(sectionHeaderClassKey, ColumnViewSectionHeaderClassKeyOption, nil);
		BindingOptionDestSourceDefault(allSectionsSortKey, ColumnViewAllSectionsSortKeyOption, nil);
		BindingOptionDestSourceDefault(sectionRowSortKey, ColumnViewSectionRowSortKeyOption, nil);
	}

	[super
		bind:bindingName
		toObject:observedObject
		withKeyPath:observedKeyPath
		options:options];
}

//
// unbind:
//
// Need to clear the binding. I handle this by passing to
// bind:toObject:withKeyPath:options: passing nil.
//
// Parameters:
//    binding - the binding name
//
- (void)unbind:(NSString *)bindingName
{
	if ([bindingName isEqualToString:ColumnViewSectionsArrayBinding])
	{
#ifndef IB_PLUGIN
		if (observedSectionsArrayObject &&
			[observedSectionsArrayObject isKindOfClass:[NSArrayController class]])
		{
			[observedSectionsArrayObject
				removeObserver:self
				forKeyPath:@"selectionIndex"];
		}
#endif

		[observedSectionsArrayObject release];
		observedSectionsArrayObject = nil;
		
		[observedSectionsArrayKeyPath release];
		observedSectionsArrayKeyPath = nil;
		
		self.columnSections = nil;
	}
	
	[super unbind:bindingName];
}

#pragma mark -- Bindings-related setter methods

//
// setColumnSections:
//
// Re-establishes observations and reloads data when the columnSections changes.
//
// Parameters:
//    newColumnSections - the new array for the columnSections
//
- (void)setColumnSections:(NSArray *)newColumnSections
{
	if (observedSectionsArrayObject &&
		[observedSectionsArrayObject isKindOfClass:[NSArrayController class]])
	{
		[(NSArrayController *)observedSectionsArrayObject setSelectionIndex:NSNotFound];
	}
	
	for (ColumnSection *columnSection in columnSections)
	{
		[columnSection.rowDataArrayController
			removeObserver:self
			forKeyPath:@"arrangedObjects"];
		[columnSection
			removeObserver:self
			forKeyPath:ColumnSectionHeaderDataBinding];
		[columnSection.rowDataArrayController
			removeObserver:self
			forKeyPath:@"selectionIndex"];
	}
	
	ReleaseDestinationRetainSource(columnSections, newColumnSections);
	
	for (ColumnSection *columnSection in columnSections)
	{
		[columnSection.rowDataArrayController
			addObserver:self
			forKeyPath:@"arrangedObjects"
			options:NSKeyValueObservingOptionNew
			context:nil];
		[columnSection
			addObserver:self
			forKeyPath:ColumnSectionHeaderDataBinding
			options:NSKeyValueObservingOptionNew
			context:nil];
		[columnSection.rowDataArrayController
			addObserver:self
			forKeyPath:@"selectionIndex"
			options:NSKeyValueObservingOptionNew
			context:nil];
	}
	
	if (observedSectionsArrayObject &&
		[observedSectionsArrayObject isKindOfClass:[NSArrayController class]] &&
		[columnSections count] > 0)
	{
		[(NSArrayController *)observedSectionsArrayObject setSelectionIndex:0];
	}

	[self reloadData];
}

//
// sectionsArray
//
// returns the sectionsArray fetched from the observed object.
//
- (NSArray *)sectionsArray
{
	return nil;
}

//
// setSectionArray:
//
// When the sectionsArray is set, we need to create the array of ColumnSection
// objects, configured from this array and the other bindings options.
//
// Parameters:
//    newSectionsArray - the new value for the sectionsArray
//
- (void)setSectionsArray:(NSArray *)newSectionsArray
{
	NSMutableArray *newColumnSections = [[NSMutableArray alloc] initWithCapacity:[newSectionsArray count]];
	for (id object in newSectionsArray)
	{
		ColumnSection *section = [[[ColumnSection alloc] init] autorelease];
		
		section.rowDataArrayController =
			[[[NSArrayController alloc] init] autorelease];
		[section.rowDataArrayController
			bind:NSContentArrayBinding
			toObject:object
			withKeyPath:sectionContentKey
			options:nil];
		[section.rowDataArrayController setSelectionIndex:NSNotFound];
		
		if (sectionHeaderDataKey)
		{
			[section
				bind:ColumnSectionHeaderDataBinding
				toObject:object
				withKeyPath:sectionHeaderDataKey
				options:nil];
		}
		
		[section setRowDisplayKey:rowDisplayKey];
		
		if (rowClassKey)
		{
			[section setRowClassKey:rowClassKey];
		}
		else if (sectionClassKey)
		{
			[section setDefaultClass:[object valueForKeyPath:sectionClassKey]];
		}
		else if (defaultRowClass)
		{
			[section setDefaultClass:defaultRowClass];
		}
		
		if (sectionHeaderClassKey)
		{
			[section setHeaderClass:[object valueForKeyPath:sectionHeaderClassKey]];
		}
		else if (defaultHeaderClass)
		{
			[section setHeaderClass:defaultHeaderClass];
		}
		
		if (sectionRowSortKey)
		{
			NSSortDescriptor *sortDescriptor =
				[[[NSSortDescriptor alloc]
					initWithKey:sectionRowSortKey
					ascending:YES
					selector:@selector(localizedCaseInsensitiveCompare:)]
				autorelease];
			[section.rowDataArrayController
				setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
		}
		else if (allSectionsSortKey)
		{
			NSSortDescriptor *sortDescriptor =
				[[[NSSortDescriptor alloc]
					initWithKey:allSectionsSortKey
					ascending:YES
					selector:@selector(localizedCaseInsensitiveCompare:)]
				autorelease];
			[section.rowDataArrayController
				setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
		}
		
		[newColumnSections addObject:section];
	}
	
	self.columnSections = [newColumnSections autorelease];
}

#pragma mark -- Selection related methods

//
// selectedRow:inSection:
//
// Method to determine the selected row and section
//
// Parameters:
//    rowOut - the index of the selected row in the selected section (NSNotFound if no selection)
//    sectionOut - the index of the selected section (NSNotFound if no selection)
//
- (void)selectedRow:(NSInteger *)rowOut inSection:(NSInteger *)sectionOut
{
	NSUInteger section = selectedSection;
	if ([observedSectionsArrayObject isKindOfClass:[NSArrayController class]])
	{
		section = [(NSArrayController *)observedSectionsArrayObject selectionIndex];
	}
	
	if (section == NSNotFound)
	{
		*rowOut = NSNotFound;
		*sectionOut = NSNotFound;
		return;
	}

	NSUInteger row =
		[[[columnSections objectAtIndex:section] rowDataArrayController] selectionIndex];

	if (row == NSNotFound)
	{
		*rowOut = NSNotFound;
		*sectionOut = NSNotFound;
		return;
	}
	
	*rowOut = row;
	*sectionOut = section;
}

//
// selectRow:inSection:
//
// Select a given row. Any currently selected row will be deselected.
//
// Parameters:
//    aRow - the row to select
//    aSection - the section containing the row to select
//
- (void)selectRow:(NSInteger)aRow inSection:(NSInteger)aSection
{
	if (aSection == NSNotFound && [columnSections count] > 0)
	{
		aSection = 0;
	}
	
	BOOL sectionChanged = aSection != selectedSection;
	
	if ([observedSectionsArrayObject isKindOfClass:[NSArrayController class]])
	{
		[(NSArrayController *)observedSectionsArrayObject setSelectionIndex:aSection];
	}
	else if (sectionChanged)
	{
		[self willChangeValueForKey:@"selectedSectionArrayController"];
		selectedSection = aSection;
		[self didChangeValueForKey:@"selectedSectionArrayController"];
	}
	
	if (aSection != NSNotFound)
	{
		[[[columnSections objectAtIndex:aSection]
			rowDataArrayController]
				setSelectionIndex:aRow];
	}
}

//
// selectedSectionArrayController
//
// returns selectedSectionArrayController 
//
- (NSArrayController *)selectedSectionArrayController
{
	return selectedSectionArrayController;
}

//
// setSelectedSectionArrayController:
//
// Setter
//
// Parameters:
//    newController - new value
//
- (void)setSelectedSectionArrayController:(NSArrayController *)newController
{
	ReleaseDestinationRetainSource(selectedSectionArrayController, newController);
}

#pragma mark -- Change observation not handled by bindings

//
// observeValueForKeyPath:ofObject:change:context:
//
// Receives key value change notifications for the following keys.
//
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object
	change:(NSDictionary *)change context:(void *)context
{
	if ([keyPath isEqualToString:@"arrangedObjects"] ||
		[keyPath isEqualToString:ColumnSectionHeaderDataBinding])
	{
		[self reloadData];
		return;
	}
	else if ([keyPath isEqualToString:@"selectionIndex"])
	{
		if ([object isEqual:observedSectionsArrayObject])
		{
			if ([observedSectionsArrayObject selectionIndex] == NSNotFound)
			{
				self.selectedSectionArrayController = nil;
			}
			else
			{
				self.selectedSectionArrayController =
					[[columnSections objectAtIndex:[observedSectionsArrayObject selectionIndex]] rowDataArrayController];
			}
		}

		[self redisplay];
		return;
	}
	
	[super observeValueForKeyPath:keyPath ofObject:object change:change
		context:context];
}

//
// viewDidMoveToSuperview
//
// Observes scroll and resize changes
//
- (void)viewDidMoveToSuperview
{
	NSView *enclosingView = [self superview];
	if (enclosingView)
	{
		NSClipView *clipView = [[self enclosingScrollView] contentView];
		
		[[NSNotificationCenter defaultCenter]
			addObserver:self
			selector:@selector(viewDidScroll:)
			name:NSViewBoundsDidChangeNotification
			object:clipView];
		[[NSNotificationCenter defaultCenter]
			addObserver:self
			selector:@selector(viewDidScroll:)
			name:NSViewFrameDidChangeNotification
			object:enclosingView];
	}
}

//
// viewDidMoveToSuperview
//
// End observing scroll and resize changes
//
- (void)viewWillMoveToSuperview
{
	[[NSNotificationCenter defaultCenter]
		removeObserver:self
		name:NSViewBoundsDidChangeNotification
		object:nil];
	[[NSNotificationCenter defaultCenter]
		removeObserver:self
		name:NSViewFrameDidChangeNotification
		object:nil];
}

//
// viewDidScroll:
//
// Handles scroll and resize changes by invoking layout
//
// Parameters:
//    aNotification - the notification (ignored)
//
- (void)viewDidScroll:(NSNotification *)aNotification
{
	[self layoutViews];
}

#pragma mark -- Row layout and updating

//
// classForRow:inSection:
//
// Parameters:
//	  rowIndex - the index of a row in a section
//    sectionIndex - the index of the section to interrogate
//
// returns the class for the row
//
- (Class)classForRow:(NSInteger)row inSection:(NSInteger)sectionIndex
{
	ColumnSection *section = [self.columnSections objectAtIndex:sectionIndex];
	NSString *sectionRowClassKey = [section rowClassKey];
	if (!sectionRowClassKey)
	{
		Class sectionDefaultClass = [section defaultClass];
		if (!sectionDefaultClass)
		{
			if (!defaultRowClass)
			{
				return [RowView class];
			}
			
			return defaultRowClass;
		}
		
		return sectionDefaultClass;
	}
	
	return [[[section rowData] objectAtIndex:row] valueForKeyPath:sectionRowClassKey];
}

//
// headerClassForSection:
//
// Parameters:
//    sectionIndex - the index of the section to interrogate (ignored if
//		singleSection is true
//
// returns the class to use for the header of section "sectionIndex"
//
- (Class)headerClassForSection:(NSInteger)sectionIndex
{
	ColumnSection *section = [self.columnSections objectAtIndex:sectionIndex];
	Class sectionHeaderClass = [section headerClass];
	if (!sectionHeaderClass)
	{
		if (!defaultHeaderClass)
		{
			return [RowView class];
		}
		
		return defaultHeaderClass;
	}
	
	return sectionHeaderClass;
}

//
// packedRowIndexForRow:inSection:
//
// Find the packed index of the given row in the given section. Use
// RowViewSectionHeaderIndex for header rows.
//
// Parameters:
//    aRow - the row index
//    aSection - the section index
//
// returns the appropriate packed row index
//
- (NSInteger)packedRowIndexForRow:(NSInteger)aRow inSection:(NSInteger)aSection
{
	NSInteger row = 0;
	NSInteger sectionIndex;
	for (sectionIndex = 0; sectionIndex <= aSection; sectionIndex++)
	{
		if (aSection == sectionIndex)
		{
			if (aRow != RowViewSectionHeaderIndex)
			{
				if ([[self.columnSections objectAtIndex:sectionIndex] headerData])
				{
					row++;
				}
				row += aRow;
			}
			break;
		}

		if ([[self.columnSections objectAtIndex:sectionIndex] headerData])
		{
			row++;
		}
		row += [[[self.columnSections objectAtIndex:sectionIndex] rowData] count];
	}
	
	return row;
}

//
// packedRowIndex:toRow:andSection:
//
// Converts a packed row index back into a row and section pair
//
// Parameters:
//    rowIndex - the packed row index
//    rowOut - the index of a row within a section
//    sectionOut - the section index
//
- (void)packedRowIndex:(NSInteger)rowIndex
	toRow:(NSInteger *)rowOut andSection:(NSInteger *)sectionOut
{
	NSInteger packedRow = 0;
	NSInteger section = 0;
	NSInteger row = [[self.columnSections objectAtIndex:section] headerData] ?
		RowViewSectionHeaderIndex : 0;
	while (packedRow < rowIndex)
	{
		if ([[self.columnSections objectAtIndex:section] headerData])
		{
			packedRow++;
		}
		
		NSInteger rowsThisSection = [[[self.columnSections objectAtIndex:section] rowData] count];
		if (packedRow + rowsThisSection > rowIndex)
		{
			row = rowIndex - packedRow;
			break;
		}
		
		packedRow += rowsThisSection;
		section++;
		row = [[self.columnSections objectAtIndex:section] headerData] ?
			RowViewSectionHeaderIndex : 0;
	}

	*rowOut = row;
	*sectionOut = section;
}

//
// layoutView:verticalOffset:height:dataObject:row:section:
//
// Places and configures a row for display
//
// Parameters:
//    aClass - the row's class
//    verticalOffset - the y coordinate for the top of the row
//    height - the height of the row
//    dataObject - the data to set for the row
//    rowIndex - the index of the row in its section (NSNotFound for header rows)
//    sectionIndex - the index of the row's section
//
- (void)layoutView:(RowView *)view
	row:(NSInteger)rowIndex
	section:(NSInteger)sectionIndex
	packedRowIndex:(NSInteger)packedRowIndex
	rowData:(id)dataObject
	selected:(BOOL)selected
{
	[view setFrame:NSMakeRect(
		0,
		verticalOffsets[packedRowIndex],
		self.bounds.size.width,
		verticalOffsets[packedRowIndex + 1] - verticalOffsets[packedRowIndex])];
	[view setSelected:selected forRow:rowIndex inSection:sectionIndex];
	[view configureWithRowData:dataObject];
}

//
// layoutViews
//
// Creates views for visible rows and configures and places them
//
- (void)layoutViews
{
	NSInteger oldTopVisibleRow = topVisibleRow;
	NSInteger oldBottomVisibleRow = bottomVisibleRow;
	topVisibleRow = NSNotFound;
	bottomVisibleRow = NSNotFound;
	
	NSRect visibleRect = [self visibleRect];
	CGFloat top = visibleRect.origin.y;
	CGFloat bottom = visibleRect.origin.y + visibleRect.size.height;
	
	//
	// Find the new top and bottom visible row
	//
	NSInteger packedIndex;
	for (packedIndex = 0; packedIndex < rowCount; packedIndex++)
	{
		if (topVisibleRow == NSNotFound &&
			verticalOffsets[packedIndex + 1] >= top &&
			verticalOffsets[packedIndex] < bottom)
		{
			topVisibleRow = packedIndex;
		}
		
		if (bottomVisibleRow == NSNotFound &&
			(verticalOffsets[packedIndex + 1] >= bottom ||
				packedIndex == rowCount - 1))
		{
			bottomVisibleRow = packedIndex;
		}
	}
	
	//
	// Remove old views that are no longer visible
	//
	NSInteger visibleRowOrigin;
	if ([visibleRows count] > 0)
	{
		NSInteger tailOffset = 0;
		visibleRowOrigin = oldTopVisibleRow;
		for (packedIndex = oldTopVisibleRow; packedIndex <= oldBottomVisibleRow; packedIndex++)
		{
			if (packedIndex < topVisibleRow || packedIndex > bottomVisibleRow)
			{
				[[visibleRows objectAtIndex:packedIndex - visibleRowOrigin - tailOffset] removeFromSuperview];
				
				[visibleRows removeObjectAtIndex:packedIndex - visibleRowOrigin - tailOffset];
				if (packedIndex == visibleRowOrigin)
				{
					visibleRowOrigin++;
				}
				else
				{
					tailOffset++;
				}
			}
		}
		
		if ([visibleRows count] == 0)
		{
			visibleRowOrigin = topVisibleRow;
		}
	}
	else
	{
		//
		// Allocate and positiion the visibleRows array if necessary
		//
		if (visibleRows == nil)
		{
			visibleRows = [[NSMutableArray alloc] init];
		}
		visibleRowOrigin = topVisibleRow;
	}
	
	//
	// If nothing visible, return
	//
	if (topVisibleRow == NSNotFound)
	{
		return;
	}
	
	NSInteger row = 0;
	NSInteger section;
	NSArray *rowData = nil;
	Class sectionRowClass;
	Class headerClass;
	id headerData;
	BOOL classesUnique;
	
	NSInteger rowForSelection;
	NSInteger sectionForSelection;
	[self selectedRow:&rowForSelection inSection:&sectionForSelection];
	
	//
	// Get the data for each visible row and configure and place them all
	//
	for (packedIndex = topVisibleRow; packedIndex <= bottomVisibleRow; packedIndex++)
	{
		if (row == [rowData count])
		{
			[self packedRowIndex:packedIndex toRow:&row andSection:&section];
			rowData = [[self.columnSections objectAtIndex:section] rowDisplayData];
			sectionRowClass = [self classForRow:0 inSection:section];
			headerClass = [self headerClassForSection:section];
			headerData = [[self.columnSections objectAtIndex:section] headerData];
			classesUnique =
				[[self.columnSections objectAtIndex:section] rowClassKey] != nil;
		}
		
		Class rowClass;
		id data;
		if (row == RowViewSectionHeaderIndex)
		{
			rowClass = headerClass;
			data = headerData;
		}
		else
		{
			if (classesUnique)
			{
				rowClass = [self classForRow:row inSection:section];
			}
			else
			{
				rowClass = sectionRowClass;
			}
			data = [rowData objectAtIndex:row];
		}
		
		//
		// Create views for newly visible rows
		//
		RowView *view;
		if (topVisibleRow < visibleRowOrigin)
		{
			view = [[[rowClass alloc] init] autorelease];
			[visibleRows insertObject:view atIndex:0];
			visibleRowOrigin--;
			[self addSubview:view];
		}
		else if (packedIndex >= visibleRowOrigin + [visibleRows count])
		{
			view = [[[rowClass alloc] init] autorelease];
			[visibleRows addObject:view];
			[self addSubview:view];
		}
		else
		{
			view = [visibleRows objectAtIndex:packedIndex - visibleRowOrigin];
		}

		[self
			layoutView:view
			row:row
			section:section
			packedRowIndex:packedIndex
			rowData:data
			selected:row == rowForSelection && section == sectionForSelection];
		
		row++;
	}
	
	//
	// Set the size of the ColumnView so that it is big enough to contain the
	// rows or fill the document area of the scroll view (whichever is bigger)
	//
	CGFloat viewHeight = verticalOffsets[rowCount];
	NSScrollView *enclosingScrollView = [self enclosingScrollView];
	if (enclosingScrollView)
	{
		CGFloat visibleHeight = [enclosingScrollView documentVisibleRect].size.height;
		if (viewHeight < visibleHeight)
		{
			viewHeight = visibleHeight;
		}
	}
	[self setFrameSize:NSMakeSize(self.frame.size.width, viewHeight)];
}

//
// reloadData
//
// Recalculates the height of each row and caches it in the verticalOffsets.
// Determines (based on the current scroll position) which rows are visible and
// reconfigures them with their data.
//
- (void)reloadData
{
	//
	// Clear the offsets
	//
	free(verticalOffsets);
	rowCount = 0;

	//
	// Clear the selection
	//
	selectedSection = NSNotFound;
	
	//
	// Clear all visible rows
	//
	for (RowView *view in visibleRows)
	{
		[view removeFromSuperview];
	}
	[visibleRows release];
	visibleRows = nil;
	
	//
	// Count the rows for each section
	//
	NSInteger sectionIndex;
	NSInteger sectionCount = [self.columnSections count];
	for (sectionIndex = 0; sectionIndex < sectionCount; sectionIndex++)
	{
		if ([[self.columnSections objectAtIndex:sectionIndex] headerData])
		{
			rowCount++;
		}
		rowCount += [[[self.columnSections objectAtIndex:sectionIndex] rowData] count];
	}
	
	//
	// Allocate the vertical offsets (including space for 1 extra row so that
	// we can calculate the height of the final row)
	//	
	verticalOffsets = malloc(sizeof(CGFloat) * rowCount + 1);
	
	//
	// Calculate the height of every row and the offsets
	//
	NSInteger rowIndex = 0;
	CGFloat progress = 0;
	for (sectionIndex = 0; sectionIndex < sectionCount; sectionIndex++)
	{
		id headerData = [[self.columnSections objectAtIndex:sectionIndex] headerData];
		if (headerData)
		{
			verticalOffsets[rowIndex] = progress;
			Class headerClass = [self headerClassForSection:sectionIndex];
			
			CGFloat height =
				[headerClass
					heightWithRowData:headerData
					forRow:RowViewSectionHeaderIndex
					inSection:sectionIndex];
			progress += height;
			rowIndex++;
		}
		
		NSArray *rows = [[self.columnSections objectAtIndex:sectionIndex] rowData];
		Class sectionRowClass = nil;
		if ([[self.columnSections objectAtIndex:sectionIndex] rowClassKey] != nil)
		{
			sectionRowClass = [self classForRow:0 inSection:sectionIndex];
		}
		NSInteger rowInSection = 0;
		for (id row in rows)
		{
			verticalOffsets[rowIndex] = progress;
			Class rowClass =
				(sectionRowClass ?
					sectionRowClass :
					[self classForRow:rowIndex inSection:sectionIndex]);

			CGFloat height =
				[rowClass
					heightWithRowData:row
					forRow:rowInSection
					inSection:sectionIndex];
			progress += height;
			rowInSection++;
			rowIndex++;
		}
	}
	
	//
	// Record the final (rowCount+1) offset
	//
	verticalOffsets[rowIndex] = progress;

	//
	// Apply the layout (which will create all the row views)
	//
	[self layoutViews];
}

//
// redisplay
//
// Refreshes the selection state of all visible rows
//
- (void)redisplay
{
	NSInteger section;
	NSInteger row;
	[self selectedRow:&row inSection:&section];

	for (RowView *rowView in visibleRows)
	{
		NSInteger viewRow = rowView.row;
		NSInteger viewSection = rowView.section;
		[rowView
			setSelected:viewRow == row && viewSection == section
			forRow:viewRow
			inSection:viewSection];
	}
}


#pragma mark -- NSView method implementations

//
// mouseDown:
//
// The default mouseDown selects the row in the columnView
//
// Parameters:
//    anEvent - the event
//
- (void)mouseDown:(NSEvent *)anEvent
{
	[self selectRow:NSNotFound inSection:NSNotFound];
}

//
// isFlipped
//
// returns YES to ensure layout is top to bottom
//
- (BOOL)isFlipped
{
	return YES;
}

//
// drawRect:
//
// The default draw method draws a gradient, colored based on header/selected
// state
//
// Parameters:
//    rect - the rect to fill
//
- (void)drawRect:(NSRect)rect
{
	[[NSColor grayColor] set];
	NSRectFill(rect);
}

//
// dealloc
//
// Release retained instance memory;
//
- (void)dealloc
{
	[self unbind:ColumnViewSectionsArrayBinding];
	
	free(verticalOffsets);

	[observedSectionsArrayObject release];
	observedSectionsArrayObject = nil;
	[observedSectionsArrayKeyPath release];
	observedSectionsArrayKeyPath = nil;

	[rowDisplayKey release];
	rowDisplayKey = nil;

	[observedSectionsArrayObject release];
	observedSectionsArrayObject = nil;
	[observedSectionsArrayKeyPath release];
	observedSectionsArrayKeyPath = nil;
	[sectionContentKey release];
	sectionContentKey = nil;
	[sectionClassKey release];
	sectionClassKey = nil;
	[rowDisplayKey release];
	rowDisplayKey = nil;
	[rowClassKey release];
	rowClassKey = nil;
	[sectionHeaderDataKey release];
	sectionHeaderDataKey = nil;
	[sectionHeaderClassKey release];
	sectionHeaderClassKey = nil;
	[allSectionsSortKey release];
	allSectionsSortKey = nil;
	[sectionRowSortKey release];
	sectionRowSortKey = nil;

	[super dealloc];
}

@end
