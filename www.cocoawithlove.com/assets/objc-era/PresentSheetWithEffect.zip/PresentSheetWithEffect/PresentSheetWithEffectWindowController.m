//
//  PresentSheetWithEffectWindowController.m
//  PresentSheetWithEffect
//
//  Created by Matt Gallagher on 2011/05/05.
//  Copyright 2011 Matt Gallagher. All rights reserved.
//
//  This software is provided 'as-is', without any express or implied
//  warranty. In no event will the authors be held liable for any damages
//  arising from the use of this software. Permission is granted to anyone to
//  use this software for any purpose, including commercial applications, and to
//  alter it and redistribute it freely, subject to the following restrictions:
//
//  1. The origin of this software must not be misrepresented; you must not
//     claim that you wrote the original software. If you use this software
//     in a product, an acknowledgment in the product documentation would be
//     appreciated but is not required.
//  2. Altered source versions must be plainly marked as such, and must not be
//     misrepresented as being the original software.
//  3. This notice may not be removed or altered from any source
//     distribution.
//

#import "PresentSheetWithEffectWindowController.h"
#import <QuartzCore/QuartzCore.h>

@implementation PresentSheetWithEffectWindowController

- (void)windowDidLoad
{
}

- (NSString *)windowNibName
{
	return @"PresentSheetWithEffectWindow";
}

- (void)presentSheetWithWindow:(id)aSheetWindow
	delegate:(id)modalWindowDelegate
	didEndSelector:(SEL)didEndSelector
{
	if (sheetWindow)
	{
		[self dismissSheetForWindow:sheetWindow];
	}
	sheetWindow = [aSheetWindow retain];
	
	CATransition *animation = [CATransition animation];
	[animation setType:kCATransitionFade];
	[[[[self window] contentView] layer] addAnimation:animation forKey:@"layerAnimation"];

	blankingView =
		[[[NSView alloc] initWithFrame:[[[self window] contentView] bounds]] autorelease];
	[[[self window] contentView] addSubview:blankingView];

    CIFilter *exposureFilter = [CIFilter filterWithName:@"CIExposureAdjust"];
    [exposureFilter setDefaults];
	[exposureFilter setValue:[NSNumber numberWithDouble:-1.25] forKey:@"inputEV"];
    CIFilter *saturationFilter = [CIFilter filterWithName:@"CIColorControls"];
    [saturationFilter setDefaults];
	[saturationFilter setValue:[NSNumber numberWithDouble:0.35] forKey:@"inputSaturation"];
    CIFilter *gloomFilter = [CIFilter filterWithName:@"CIGloom"];
    [gloomFilter setDefaults];
	[gloomFilter setValue:[NSNumber numberWithDouble:0.75] forKey:@"inputIntensity"];
	
    [[blankingView layer]
		setBackgroundFilters:[NSArray arrayWithObjects:exposureFilter, saturationFilter, gloomFilter, nil]];

	if ([sheetWindow isKindOfClass:[NSAlert class]])
	{
		if (modalWindowDelegate == nil)
		{
			modalWindowDelegate = self;
			didEndSelector = @selector(didEndPresentedAlert:returnCode:contextInfo:);
		}
		[(NSAlert *)sheetWindow
			beginSheetModalForWindow:[self window]
			modalDelegate:modalWindowDelegate
			didEndSelector:didEndSelector
			contextInfo:NULL];
	}
	else
	{
		[[NSApplication sharedApplication]
			beginSheet:sheetWindow
			modalForWindow:[self window]
			modalDelegate:modalWindowDelegate
			didEndSelector:didEndSelector
			contextInfo:NULL];
	}
}

- (void)dismissSheetForWindow:(id)aSheetWindow
{
	if ([aSheetWindow isKindOfClass:[NSWindow class]])
	{
		[[NSApplication sharedApplication] endSheet:aSheetWindow];
		[aSheetWindow orderOut:nil];
	}

	if (![aSheetWindow isEqual:sheetWindow])
	{
		return;
	}
	
	[sheetWindow autorelease];
	sheetWindow = nil;

	CATransition *animation = [CATransition animation];
	[animation setType:kCATransitionFade];
	[[[[self window] contentView] layer] addAnimation:animation forKey:@"layerAnimation"];

	[blankingView removeFromSuperview];
	blankingView = nil;
}

- (void)didEndPresentedAlert:(NSAlert *)anAlert returnCode:(NSInteger)returnCode
	contextInfo:(void *)contextInfo
{
	[self dismissSheetForWindow:anAlert];
}

@end
