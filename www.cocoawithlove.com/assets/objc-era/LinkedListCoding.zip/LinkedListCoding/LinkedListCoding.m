//
//  Created by Matt Gallagher on 27/03/09.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file without charge in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.

#import <Foundation/Foundation.h>
#import "BlockCoding.h"

#define LINKED_NODE_NAME_SIZE 10
#define NUM_LINKED_NODES 10

struct LinkedNode
{
	char name[LINKED_NODE_NAME_SIZE];
	struct LinkedNode *nextNode;
};
typedef struct LinkedNode LinkedNode;

int main (int argc, const char * argv[])
{
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	
	//
	// Create a head for the linked list
	//
	LinkedNode *nodeHead = (LinkedNode *)malloc(sizeof(LinkedNode));
	snprintf(nodeHead->name, LINKED_NODE_NAME_SIZE, "NodeHead");
	printf("Created node named %s\n", nodeHead->name);
	
	LinkedNode *previousNode = nodeHead;
	LinkedNode *currentNode = nil;
	
	//
	// Create a few nodes for the list
	//
	NSInteger i;
	for (i = 0; i < NUM_LINKED_NODES - 1; i++)
	{
		currentNode = (LinkedNode *)malloc(sizeof(LinkedNode));
		snprintf(currentNode->name, LINKED_NODE_NAME_SIZE, "Node %ld", i);

		previousNode->nextNode = currentNode;
		previousNode = currentNode;

		printf("Created node named %s\n", currentNode->name);
	}
	
	currentNode->nextNode = nil;
	
	//
	// Create a BlockContext and use it to archive the linked list
	//
	BlockContext *wrapperContext =
		[[[BlockContext alloc]
			initWithStartingBlock:nodeHead
			blockSize:sizeof(LinkedNode)
			pointerOffsets:[NSArray arrayWithObject:[NSNumber numberWithInteger:
				(NSUInteger)(&nodeHead->nextNode) - (NSUInteger)nodeHead]]]
		autorelease];
	NSData *encodedData = [NSKeyedArchiver archivedDataWithRootObject:wrapperContext];
	
	//
	// free the original nodes
	//
	currentNode = nodeHead;
	while (currentNode)
	{
		previousNode = currentNode;
		currentNode = previousNode->nextNode;
		free(previousNode);
	}
	
	//
	// Decode the archived linked list
	//
	BlockContext *decodedContext =
		[NSKeyedUnarchiver unarchiveObjectWithData:encodedData];
	
	//
	// Iterate over the nodes in the list to verify that it has the same
	// structure as the source list.
	//
	currentNode = [decodedContext startingBlock];
	while (currentNode)
	{
		printf("Decoded node named %s\n", currentNode->name);
	
		previousNode = currentNode;
		currentNode = previousNode->nextNode;
		free(previousNode);
	}
	
	[pool drain];
	
    return 0;
}
