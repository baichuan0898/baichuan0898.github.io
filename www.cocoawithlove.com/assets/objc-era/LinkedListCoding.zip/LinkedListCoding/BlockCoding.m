//
//  BlockCoding.m
//  LinkedListCoding
//
//  Created by Matt Gallagher on 27/03/09.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file without charge in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "BlockCoding.h"

@implementation BlockContext

@synthesize blockSize;
@synthesize pointerOffsets;
@synthesize startingBlock;

//
// init
//
// Init method for the object.
//
- (id)initWithStartingBlock:(void *)aStartingBlock
	blockSize:(size_t)aBlockSize
	pointerOffsets:(NSArray *)aPointerOffsets
{
	self = [super init];
	if (self != nil)
	{
		CFDictionaryKeyCallBacks pointerCallbacks = {0, NULL, NULL, NULL, NULL, NULL};
		blockToBlockWrapperMappings =
			CFDictionaryCreateMutable(
				kCFAllocatorDefault,
				0,
				&pointerCallbacks,
				&kCFTypeDictionaryValueCallBacks);
		startingBlock = aStartingBlock;
		blockSize = aBlockSize;
		pointerOffsets = [aPointerOffsets retain];
	}
	return self;
}

//
// initWithCoder:
//
// Init method for the object when returning from the archive.
//
- (id)initWithCoder:(NSCoder *)decoder
{
	self = [super init];
	if (self != nil)
	{
		pointerOffsets = [[decoder decodeObjectForKey:@"pointerOffsets"] retain];
		startingBlock = [[decoder decodeObjectForKey:@"startingBlock"] blockPointer];
	}
	return self;
}

//
// dealloc
//
// Releases instance memory.
//
- (void)dealloc
{
	[pointerOffsets release];
	if (blockToBlockWrapperMappings)
	{
		CFRelease(blockToBlockWrapperMappings);
	}
	[super dealloc];
}

//
// encodeWithCoder:
//
// Encodes the context, which in turn encodes the blocks.
//
// Parameters:
//    encoder - the coder used to encode the context
//
- (void)encodeWithCoder:(NSCoder *)encoder
{
	[encoder encodeObject:[self wrapperForBlock:startingBlock] forKey:@"startingBlock"];
	[encoder encodeObject:pointerOffsets forKey:@"pointerOffsets"];
}

//
// wrapperForBlock:
//
// Accesses the BlockWrapper for the specified pointer, creating one if
// it doesn't exist.
//
// Parameters:
//    aBlock - The pointer to lookup
//
// returns the BlockWrapper for aBlock.
//
- (BlockWrapper *)wrapperForBlock:(void *)aBlock
{
	BlockWrapper *wrapper =
		(BlockWrapper *)CFDictionaryGetValue(blockToBlockWrapperMappings, aBlock);
	if (!wrapper)
	{
		wrapper = [[BlockWrapper alloc] initWithBlockContext:self blockPointer:aBlock];
		CFDictionaryAddValue(blockToBlockWrapperMappings, aBlock, wrapper);
		[wrapper release];
	}
	return wrapper;
}

@end

@implementation BlockWrapper

@synthesize blockPointer;

//
// init
//
// Init method for the object.
//
- (id)initWithBlockContext:(BlockContext *)aBlockContext
	blockPointer:(void *)aBlockPointer
{
	self = [super init];
	if (self != nil)
	{
		blockPointer = aBlockPointer;
		blockContext = aBlockContext; // pointer to parent -- don't retain
	}
	return self;
}

//
// initWithCoder:
//
// Init method for the object when returning from the archive.
//
- (id)initWithCoder:(NSCoder *)decoder
{
	self = [super init];
	if (self != nil)
	{
		NSUInteger blockSize;
		const void *bytes = [decoder decodeBytesForKey:@"block" returnedLength:&blockSize];
		blockPointer = malloc(blockSize);
		memcpy(blockPointer, bytes, blockSize);
		
		BlockContext *context = [decoder decodeObjectForKey:@"blockContext"];

		NSArray *childBlocks = [decoder decodeObjectForKey:@"childBlocks"];
		NSArray *pointerOffsets = [context pointerOffsets];
		NSInteger i;
		NSInteger count = [childBlocks count];
		
		NSAssert(count == [pointerOffsets count],
			@"Mismatch between childBlocks and pointerOffsets");
		
		for (i = 0; i < count; i++)
		{
			BlockWrapper *wrapperObject = [childBlocks objectAtIndex:i];
			NSNumber *offsetNumber = [pointerOffsets objectAtIndex:i];
			NSUInteger offset = [offsetNumber integerValue];
			
			void *childPointer = 0;
			if (![wrapperObject isEqual:[NSNull null]])
			{
				childPointer = [wrapperObject blockPointer];
			}
			
			*(void **)((NSUInteger)blockPointer + offset) = childPointer;
		}
	}
	return self;
}

//
// encodeWithCoder:
//
// Archives a representation of the block and locations to which it points.
//
// Parameters:
//    encoder - the coder which will be used for the encoding.
//
- (void)encodeWithCoder:(NSCoder *)encoder
{
	[encoder encodeBytes:blockPointer length:[blockContext blockSize] forKey:@"block"];
	[encoder encodeObject:blockContext forKey:@"blockContext"];

	NSMutableArray *blockWrapperArray =
		[NSMutableArray arrayWithCapacity:[[blockContext pointerOffsets] count]];

	for (NSNumber *offsetNumber in [blockContext pointerOffsets])
	{
		NSUInteger offset = [offsetNumber integerValue];
		void *childBlock = *(void **)((NSUInteger)blockPointer + offset);
		if (!childBlock)
		{
			[blockWrapperArray addObject:[NSNull null]];
			continue;
		}

		BlockWrapper *childWrapper = [blockContext wrapperForBlock:childBlock];
		[blockWrapperArray addObject:childWrapper];
	}
	
	[encoder encodeObject:blockWrapperArray forKey:@"childBlocks"];
}

@end
