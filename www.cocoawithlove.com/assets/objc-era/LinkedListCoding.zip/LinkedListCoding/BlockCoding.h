//
//  BlockCoding.h
//  LinkedListCoding
//
//  Created by Matt Gallagher on 27/03/09.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file without charge in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import <Cocoa/Cocoa.h>

@class BlockWrapper;

@interface BlockContext : NSObject <NSCoding>
{
	CFMutableDictionaryRef blockToBlockWrapperMappings;
	void *startingBlock;
	size_t blockSize;
	NSArray *pointerOffsets;
}

@property (readonly) size_t blockSize;
@property (readonly) void *startingBlock;
@property (readonly, retain, nonatomic) NSArray *pointerOffsets;

- (id)initWithStartingBlock:(void *)aStartingBlock
	blockSize:(size_t)aBlockSize
	pointerOffsets:(NSArray *)aPointerOffsets;
- (BlockWrapper *)wrapperForBlock:(void *)aBlock;

@end

@interface BlockWrapper : NSObject <NSCoding>
{
	BlockContext *blockContext;
	void *blockPointer;
}

@property (readonly) void *blockPointer;

- (id)initWithBlockContext:(BlockContext *)aBlockContext
	blockPointer:(void *)aBlockPointer;

@end
