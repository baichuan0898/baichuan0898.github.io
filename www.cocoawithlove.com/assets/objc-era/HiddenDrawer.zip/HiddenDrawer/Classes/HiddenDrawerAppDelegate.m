//
//  HiddenDrawerAppDelegate.m
//  HiddenDrawer
//
//  Created by Matt Gallagher on 20/05/09.
//  Copyright Matt Gallagher 2009. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "HiddenDrawerAppDelegate.h"
#import "TableViewController.h"
#import "HiddenDrawerViewController.h"

@implementation HiddenDrawerAppDelegate

@synthesize window;
@synthesize viewController;

- (void)applicationDidFinishLaunching:(UIApplication *)application
{
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}


- (void)toggleDrawer
{
	if (drawerController)
	{
		CGRect drawerFrame = drawerController.view.frame;

		[UIView beginAnimations:nil context:nil];
		
		CGRect tableFrame = viewController.view.frame;
		tableFrame.origin.y -= drawerFrame.size.height;
		viewController.view.frame = tableFrame;

		drawerFrame.origin.y -= drawerFrame.size.height;
		drawerController.view.frame = drawerFrame;
		
		[UIView commitAnimations];

		[drawerController.view
			performSelector:@selector(removeFromSuperview)
			withObject:nil
			afterDelay:0.5];
		[drawerController
			performSelector:@selector(release)
			withObject:nil
			afterDelay:0.5];
		drawerController = nil;
	}
	else
	{
		drawerController = [[HiddenDrawerViewController alloc] init];
		
		//
		// Position the drawer below the status bar
		//
		CGRect drawerFrame = drawerController.view.frame;
		CGRect statusBarFrame = [[UIApplication sharedApplication] statusBarFrame];
		drawerFrame.origin.x = statusBarFrame.origin.x;
		drawerFrame.size.width = statusBarFrame.size.width;
		drawerFrame.origin.y = statusBarFrame.origin.y + statusBarFrame.size.height;

		//
		// For the animation, move the drawer up by its own height.
		//
		drawerFrame.origin.y -= drawerFrame.size.height;

		drawerController.view.frame = drawerFrame;
 		[window addSubview:drawerController.view];

		[UIView beginAnimations:nil context:nil];
		
		CGRect tableFrame = viewController.view.frame;
		tableFrame.origin.y += drawerFrame.size.height;
		viewController.view.frame = tableFrame;

		drawerFrame.origin.y += drawerFrame.size.height;
		drawerController.view.frame = drawerFrame;
		
		[UIView commitAnimations];
	}
}


- (void)dealloc
{
    [viewController release];
    [window release];
    [drawerController release];
    [super dealloc];
}


@end
