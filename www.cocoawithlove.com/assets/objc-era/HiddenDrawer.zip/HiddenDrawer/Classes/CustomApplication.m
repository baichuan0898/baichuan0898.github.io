//
//  CustomApplication.m
//  HiddenDrawer
//
//  Created by Matt Gallagher on 19/05/09.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "CustomApplication.h"
#import "HiddenDrawerAppDelegate.h"

@implementation CustomApplication

- (void)sendEvent:(UIEvent *)anEvent
{
	#define GS_EVENT_TYPE_OFFSET 2
	#define GS_EVENT_X_OFFSET 6
	#define GS_EVENT_Y_OFFSET 7
	#define STATUS_BAR_TOUCH_DOWN 1015

	int *eventMemory = (int *)[anEvent performSelector:@selector(_gsEvent)];
	int eventType = eventMemory[GS_EVENT_TYPE_OFFSET];

	if (eventType == STATUS_BAR_TOUCH_DOWN)
	{
		int xMemory = eventMemory[GS_EVENT_X_OFFSET];
		int yMemory = eventMemory[GS_EVENT_Y_OFFSET];

		typedef union {int intValue; float floatValue;} Int2Float;
		float x = ((Int2Float)xMemory).floatValue;
		float y = ((Int2Float)yMemory).floatValue;

		NSLog(@"Status bar down at %f, %f", x, y);
		
		[(HiddenDrawerAppDelegate *)self.delegate toggleDrawer];
	}
	else
	{
		[super sendEvent:anEvent];
	}
}

@end
