//
//  ResultView.h
//  FuelView
//
//  Created by Matt Gallagher on 2011/05/21.
//  Copyright 2011 Matt Gallagher. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ResultView : UIView
{
	NSDictionary *result;
}

@property (nonatomic, copy) NSDictionary *result;

@end
