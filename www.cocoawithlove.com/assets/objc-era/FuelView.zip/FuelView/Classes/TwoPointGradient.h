//
//  TwoPointGradient.h
//  FuelView
//
//  Created by Matt Gallagher on 2011/05/21.
//  Copyright 2011 Matt Gallagher. All rights reserved.
//

#import <UIKit/UIKit.h>

CGGradientRef TwoPointGradient(UIColor *startColor, UIColor *endColor);
