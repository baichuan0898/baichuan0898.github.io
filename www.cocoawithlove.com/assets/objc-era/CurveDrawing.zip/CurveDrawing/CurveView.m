//
//  CurveView.m
//  CurveDrawing
//
//  Created by Matt Gallagher on 12/07/08.
//  Copyright 2008 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file without charge in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "CurveView.h"

@implementation CurveView

//
// Create the "points" array and initialize the values using "resetControlPoints:"
//
- (id)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
	{
		[self resetControlPoints:self];
    }
    return self;
}

//
// Once the Nib is connected, set the "ArcToPoint radius" slider control to
// continuous updating (for smooth redrawing as the control is operated) and
// set the initial radius to halfway along the control.
//
- (void)awakeFromNib
{
	[sliderControl setContinuous:YES];
	[self setRadius:0.5 * ([sliderControl maxValue] - [sliderControl minValue])];
}

//
// This is the setter method for "radius". It will be invoked by the value
// binding on the slider control. We use this method to trigger a redraw when
// the value is set.
//
- (void)setRadius:(float)newValue
{
	radius = newValue;
	[self setNeedsDisplay:YES];
}

//
// This method is invoked when the segmented control is clicked. We update
// our selectedSegment index and trigger a redraw.

//
- (IBAction)changeSegment:(id)sender
{
	selectedSegment = [sender selectedSegment];
	[self setNeedsDisplay:YES];
}

//
// Set all the control points to decent starting values and trigger a redraw
//
- (IBAction)resetControlPoints:(id)sender
{
	NSRect bounds = [self bounds];

	points[0] = NSMakePoint(0.25 * bounds.size.width, 0.25 * bounds.size.height);
	points[1] = NSMakePoint(0.25 * bounds.size.width, 0.75 * bounds.size.height);
	points[2] = NSMakePoint(0.75 * bounds.size.width, 0.75 * bounds.size.height);
	points[3] = NSMakePoint(0.75 * bounds.size.width, 0.25 * bounds.size.height);

	[self setNeedsDisplay:YES];
}

//
// Returns the 8x8 NSRect of the control point for a point specified by value.
//
- (NSRect)controlPointRectForPoint:(NSPoint)currentPoint
{
	const float CONTROL_POINT_SIZE = 8.0;
	
	NSRect controlPointRect =
		NSMakeRect(
			currentPoint.x - 0.5 * CONTROL_POINT_SIZE,
			currentPoint.y - 0.5 * CONTROL_POINT_SIZE,
			CONTROL_POINT_SIZE,
			CONTROL_POINT_SIZE);
	
	return controlPointRect;
}

//
// Returns an NSRect that encloses all the points in the "points" array.
//
- (NSRect)boundsOfAllControlPoints
{
	//
	// Start the min and max tracking with the first point
	//
	float minX = points[0].x;
	float minY = points[0].y;
	float maxX = points[0].x;
	float maxY = points[0].y;
	
	NSInteger pointIndex = 1;
	while (pointIndex < NUM_CONTROL_POINTS)
	{
		//
		// Get each subsequent point and expand the tracked min and max
		// values to enclose it.
		//
		float currentX = points[pointIndex].x; 
		float currentY = points[pointIndex].y;
		if (currentX > maxX)
		{
			maxX = currentX;
		}
		else if (currentX < minX)
		{
			minX = currentX;
		}
		if (currentY > maxY)
		{
			maxY = currentY;
		}
		else if (currentY < minY)
		{
			minY = currentY;
		}
		pointIndex++;
	}
	
	return NSMakeRect(minX, minY, maxX - minX, maxY - minY);
}

//
// This is the drawing method for the view. It will draw:
//	- background as a white square framed in black
//	- a line from point 0 to 1, 1 to 2 and 2 to 3.
//	- the current drawing primitive
//	- all four control points.
//
- (void)drawRect:(NSRect)rect
{
	CGContextRef context = [[NSGraphicsContext currentContext] graphicsPort];
	
	//
	// Draw the background as a white square framed in black
	//
	NSRect nsBounds = [self bounds];
	CGRect cgBounds = NSRectToCGRect(nsBounds);
	CGContextSetRGBFillColor(context, 1.0, 1.0, 1.0, 1.0);
	CGContextFillRect(context, cgBounds);
	CGContextSetRGBFillColor(context, 0, 0, 0, 1.0);
	CGContextSetLineWidth(context, 1.0);
	CGContextStrokeRect(context, cgBounds);
	
	//
	// Draw a line from point 0 to 1, 1 to 2 and 2 to 3.
	//
	CGContextMoveToPoint(
		context,
		NSPointToCGPoint(points[0]).x,
		NSPointToCGPoint(points[0]).y);
	CGContextAddLineToPoint(
		context,
		NSPointToCGPoint(points[1]).x,
		NSPointToCGPoint(points[1]).y);
	CGContextAddLineToPoint(
		context,
		NSPointToCGPoint(points[2]).x,
		NSPointToCGPoint(points[2]).y);
	CGContextAddLineToPoint(
		context,
		NSPointToCGPoint(points[3]).x,
		NSPointToCGPoint(points[3]).y);
	CGContextSetLineWidth(context, 0.5);
	CGContextSetRGBStrokeColor(context, 0.0, 0.0, 0.0, 1.0);
	CGContextStrokePath(context);
	
	//
	// Load the current drawing primitive into the current CGContext path.
	//
	switch (selectedSegment)
	{
		case 0:
			//
			// Move to point zero and add the ArcToPoint
			//
			CGContextMoveToPoint(
				context,
				NSPointToCGPoint(points[0]).x,
				NSPointToCGPoint(points[0]).y);
			CGContextAddArcToPoint(
				context,
				NSPointToCGPoint(points[1]).x,
				NSPointToCGPoint(points[1]).y,
				NSPointToCGPoint(points[2]).x,
				NSPointToCGPoint(points[2]).y,
				radius);
			break;
		case 1:
			//
			// Move to point zero and add the CurveToPoint
			//
			CGContextMoveToPoint(
				context,
				NSPointToCGPoint(points[0]).x,
				NSPointToCGPoint(points[0]).y);
			CGContextAddCurveToPoint(
				context,
				NSPointToCGPoint(points[1]).x,
				NSPointToCGPoint(points[1]).y,
				NSPointToCGPoint(points[2]).x,
				NSPointToCGPoint(points[2]).y,
				NSPointToCGPoint(points[3]).x,
				NSPointToCGPoint(points[3]).y);
			break;
		case 2:
			//
			// Add an Ellipse in the rect enclosing all points
			//
			CGContextAddEllipseInRect(
				context,
				NSRectToCGRect([self boundsOfAllControlPoints]));
			break;
		case 3:
			//
			// Add to point 0 and draw a line lines from 0 to 1, 1 to 2 and 2 to 3
			//
			CGContextMoveToPoint(
				context,
				NSPointToCGPoint(points[0]).x,
				NSPointToCGPoint(points[0]).y);
			CGContextAddLineToPoint(
				context,
				NSPointToCGPoint(points[1]).x,
				NSPointToCGPoint(points[1]).y);
			CGContextAddLineToPoint(
				context,
				NSPointToCGPoint(points[2]).x,
				NSPointToCGPoint(points[2]).y);
			CGContextAddLineToPoint(
				context,
				NSPointToCGPoint(points[3]).x,
				NSPointToCGPoint(points[3]).y);
			break;
		case 4:
			//
			// Move to point zero and add the QuadCurveToPoint
			//
			CGContextMoveToPoint(
				context,
				NSPointToCGPoint(points[0]).x,
				NSPointToCGPoint(points[0]).y);
			CGContextAddQuadCurveToPoint(
				context,
				NSPointToCGPoint(points[1]).x,
				NSPointToCGPoint(points[1]).y,
				NSPointToCGPoint(points[2]).x,
				NSPointToCGPoint(points[2]).y);
			break;
		case 5:
			//
			// Add a Rect in the rect enclosing all points
			//
			CGContextAddRect(
				context,
				NSRectToCGRect([self boundsOfAllControlPoints]));
			break;
	}
	
	//
	// Now that we have added the drawing primitive to the current context's
	// path, we can draw it with a thick black stroke
	//
	CGContextSetLineWidth(context, 3.0);
	CGContextSetRGBStrokeColor(context, 0.0, 0.0, 0.0, 1.0);
	CGContextStrokePath(context);

	//
	// Draw all the control point squares as a filled gray square and a dark
	// gray stroked rect.
	//
	for (NSInteger i = 0; i < NUM_CONTROL_POINTS; i++)
	{
		NSRect nsControlPointRect = [self controlPointRectForPoint:points[i]];
		CGRect cgControlPointRect = NSRectToCGRect(nsControlPointRect);
		CGContextSetRGBFillColor(context, 0.5, 0.5, 0.5, 1.0);
		CGContextFillRect(context, cgControlPointRect);
		CGContextSetRGBStrokeColor(context, 0.25, 0.25, 0.25, 1.0);
		CGContextSetLineWidth(context, 1.0);
		CGContextStrokeRect(context, cgControlPointRect);
	}
}

//
// When a mouse down is received, look to see if any control points are under
// the mouse and drag them around if they are
//
- (void)mouseDown:(NSEvent *)event
{
	//
	// Get the location of the mouse down even
	//
	NSPoint location = [self convertPoint:[event locationInWindow] fromView:nil];

	//
	// Look to see if a point in the "points" array has a control point
	// rectangle at the mouse down location.
	//
	NSInteger match = NSNotFound;
	for (NSInteger i = 0; i < NUM_CONTROL_POINTS; i++)
	{
		NSRect controlPointRect = [self controlPointRectForPoint:points[i]];
		if (NSPointInRect(location, controlPointRect))
		{
			match = i;
			break;
		}
	}
	
	//
	// If no control point exists at the mouse down location, then return
	//
	if (match == NSNotFound)
	{
		return;
	}
	
    while (YES)
	{
		//
		// Begin modal mouse tracking, looking for mouse dragged and mouse
		// up events
		//
        NSEvent *trackingEvent =
			[[self window]
				nextEventMatchingMask:(NSLeftMouseDraggedMask | NSLeftMouseUpMask)];
		
		//
		// Convert the location of the new event to an NSValue and replace
		// the "match" NSValue with the new NSValue in the "points" array.
		//
		NSPoint trackingLocation =
			[self convertPoint:[trackingEvent locationInWindow] fromView:nil];
		points[match] = trackingLocation;
		
		//
		// Redraw the view
		//
		[self setNeedsDisplay:YES];

		//
		// Stop mouse tracking if a mouse up is received
		//
		if ([trackingEvent type] == NSLeftMouseUp)
		{
			break;
		}
	}
}

@end
