//
//  CurveView.h
//  CurveDrawing
//
//  Created by Matt Gallagher on 12/07/08.
//  Copyright 2008 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file without charge in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import <Cocoa/Cocoa.h>

#define NUM_CONTROL_POINTS 4

@interface CurveView : NSView
{
	NSPoint points[NUM_CONTROL_POINTS];
	NSInteger selectedSegment;
	float radius;
	IBOutlet NSSlider *sliderControl;
}

- (IBAction)resetControlPoints:(id)sender;
- (IBAction)changeSegment:(id)sender;
- (void)setRadius:(float)newValue;

@end
