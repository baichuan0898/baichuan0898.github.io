//
//  WebViewConnector.m
//  NewToTheStore
//
//  Created by Matt Gallagher on 21/09/08.
//  Copyright 2008 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file without charge in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "WebViewConnector.h"


@implementation WebViewConnector

- (void)dealloc
{
	[newItemsController removeObserver:self forKeyPath:@"selectedObjects"];
	[super dealloc];
}

- (void)awakeFromNib
{
	[newItemsController addObserver:self forKeyPath:@"selectedObjects" options:0 context:nil];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object
	change:(NSDictionary *)change context:(void *)context
{
	if ([keyPath isEqualTo:@"selectedObjects"])
	{
		if ([object valueForKey:@"selectedObjects"] == 0)
		{
			return;
		}
		
		NSDictionary *selectedObject =
			[[object valueForKey:@"selectedObjects"] objectAtIndex:0];
		[webView setMainFrameURL:[selectedObject objectForKey:@"linkURL"]];

		return;
	}
	
	[super observeValueForKeyPath:keyPath ofObject:object change:change
		context:context];
}

@end
