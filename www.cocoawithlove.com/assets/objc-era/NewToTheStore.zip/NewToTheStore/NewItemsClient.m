//
//  NewItemsClient.m
//  NewToTheStore
//
//  Created by Matt Gallagher on 21/09/08.
//  Copyright 2008 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file without charge in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "NewItemsClient.h"


@implementation NewItemsClient

@synthesize newItems;

- (void)dealloc
{
	[newItems release];
	[responseData release];
	[baseURL release];
	[super dealloc];
}

- (void)awakeFromNib
{
	responseData = [[NSMutableData data] retain];
	baseURL = [[NSURL URLWithString:@"http://store.apple.com"] retain];

    NSURLRequest *request =
        [NSURLRequest requestWithURL:baseURL];
    [[[NSURLConnection alloc] initWithRequest:request delegate:self] autorelease];
}

- (NSURLRequest *)connection:(NSURLConnection *)connection
    willSendRequest:(NSURLRequest *)request
    redirectResponse:(NSURLResponse *)redirectResponse
{
    [baseURL autorelease];
    baseURL = [[request URL] retain];
    return request;
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    [responseData setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [responseData appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    [[NSAlert alertWithError:error] runModal];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    // Once this method is invoked, "responseData" contains the complete result
	NSError *error;
	NSXMLDocument *document =
		[[NSXMLDocument alloc] initWithData:responseData options:NSXMLDocumentTidyHTML error:&error];
	
	// Deliberately ignore error: with most HTML it will be filled numerous
	// "tidy" warnings.
	
	NSXMLElement *rootNode = [document rootElement];
	
	NSString *xpathQueryString = 
		@"//div[@id='newtothestore']/div[@class='modulecontent']/div[@class='list_content']/ul/li/a";

	NSArray *newItemsNodes = [rootNode nodesForXPath:xpathQueryString error:&error];

	if (error)
	{
		[[NSAlert alertWithError:error] runModal];
		return;
	}
	
	[self willChangeValueForKey:@"newItems"];
	[newItems release];
	newItems = [[NSMutableArray array] retain];
	for (NSXMLElement *node in newItemsNodes)
	{
		NSString *relativeString = [[node attributeForName:@"href"] stringValue];
		NSURL *url = [NSURL URLWithString:relativeString relativeToURL:baseURL];
		
		NSString *linkText = [[node childAtIndex:0] stringValue];
		
		[newItems addObject:
			[NSDictionary dictionaryWithObjectsAndKeys:
				[url absoluteString], @"linkURL",
				linkText, @"linkText",
				nil]];
	}
	[self didChangeValueForKey:@"newItems"];
}

@end
