//
//  AppWindowController.m
//  AppWithButton
//
//  Created by Matt Gallagher on 2009/07/01.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//

#import "AppWindowController.h"


@implementation AppWindowController

- (IBAction)buttonPushed:(id)sender
{
	NSString *title = [textField stringValue];
	
	const NSArray *titles = nil;
	if (titles == nil)
	{
		titles = [[NSArray alloc] initWithObjects:
			@"Push the button.",
			@"Button pushed.",
			@"Feel better?",
			@"That's all there is.",
			@"Except for this.",
			@"And this, I guess.",
			nil];
	}
	NSInteger titleIndex = [titles indexOfObject:title];
	if (titleIndex == NSNotFound || titleIndex == [titles count] - 1)
	{
		titleIndex = 0;
	}
	else
	{
		titleIndex++;
	}
	
	[textField setStringValue:[titles objectAtIndex:titleIndex]];
}

@end
