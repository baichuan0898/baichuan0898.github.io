//
//  CustomButtonCell.h
//  AppWithButton
//
//  Created by Matt Gallagher on 2009/07/01.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface CustomButtonCell : NSButtonCell
{
	NSColor *buttonColor;
}

@property (nonatomic, retain) NSColor *buttonColor;

@end
