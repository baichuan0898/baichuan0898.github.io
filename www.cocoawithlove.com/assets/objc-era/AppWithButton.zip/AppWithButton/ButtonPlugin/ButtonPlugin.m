//
//  ButtonPlugin.m
//  ButtonPlugin
//
//  Created by Matt Gallagher on 2009/07/01.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//

#import "ButtonPlugin.h"

@implementation ButtonPlugin
- (NSArray *)libraryNibNames {
    return [NSArray arrayWithObject:@"ButtonPluginLibrary"];
}

- (NSArray *)requiredFrameworks {
    return [NSArray arrayWithObjects:[NSBundle bundleWithIdentifier:@"com.mattgallagher.ButtonPlugin"], nil];
}

@end
