//
//  CustomButtonCell.m
//  ButtonPlugin
//
//  Created by Matt Gallagher on 2009/07/01.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//

#import <InterfaceBuilderKit/InterfaceBuilderKit.h>
#import <ButtonPlugin/CustomButtonCell.h>
#import "ButtonPluginInspector.h"


@implementation CustomButtonCell ( ButtonPlugin )

- (void)ibPopulateKeyPaths:(NSMutableDictionary *)keyPaths {
    [super ibPopulateKeyPaths:keyPaths];
	
    [[keyPaths objectForKey:IBAttributeKeyPaths]
		addObjectsFromArray:[NSArray arrayWithObjects:@"buttonColor", nil]];
}

- (void)ibPopulateAttributeInspectorClasses:(NSMutableArray *)classes {
    [super ibPopulateAttributeInspectorClasses:classes];
    [classes addObject:[ButtonPluginInspector class]];
}

@end
