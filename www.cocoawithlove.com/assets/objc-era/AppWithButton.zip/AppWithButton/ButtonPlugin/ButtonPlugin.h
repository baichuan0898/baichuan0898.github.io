//
//  ButtonPlugin.h
//  ButtonPlugin
//
//  Created by Matt Gallagher on 2009/07/01.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//

#import <InterfaceBuilderKit/InterfaceBuilderKit.h>

@interface ButtonPlugin : IBPlugin {

}

@end
