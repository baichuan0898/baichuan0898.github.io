//
//  ButtonPluginInspector.m
//  ButtonPlugin
//
//  Created by Matt Gallagher on 2009/07/01.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//

#import "ButtonPluginInspector.h"

@implementation ButtonPluginInspector

- (NSString *)viewNibName {
	return @"ButtonPluginInspector";
}

- (void)refresh {
	// Synchronize your inspector's content view with the currently selected objects.
	[super refresh];
}

@end
