//
//  StateController.m
//  DictionaryState
//
//  Created by Matt Gallagher on 9/11/08.
//  Copyright 2008 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file without charge in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "StateController.h"
#import "ContentView.h"

@implementation StateController

@synthesize selectedItem, clockwise;

//
// initialize
//
// Establish a dependent key relationship so that the label is updated
// when either the popup menu or the checkbox changes
//
+ (void)initialize
{
    [self
		setKeys:[NSArray arrayWithObjects:@"selectedItem", @"clockwise", nil]
		triggerChangeNotificationsForDependentKey:@"labelString"];
}

//
// dealloc
//
// Releases instance memory.
//
- (void)dealloc
{
#ifdef STATE_FROM_DICTIONARY
	[states release];
#endif
	[selectedItem release];
	[super dealloc];
}

//
// awakeFromNib
//
// Set the inital state.
//
- (void)awakeFromNib
{
#ifdef STATE_FROM_DICTIONARY
	//
	// This is the one place where "STATE_FROM_DICTIONARY" must do more work:
	// loading the array of states from the property list
	//
	[self willChangeValueForKey:@"popupMenuValues"];
	[self willChangeValueForKey:@"popupMenuItems"];
	states =
		[[NSPropertyListSerialization
			propertyListFromData:
				[NSData dataWithContentsOfFile:
					[[NSBundle mainBundle]
						pathForResource:@"States"
						ofType:@"plist"]]
			mutabilityOption:NSPropertyListImmutable
			format:nil
			errorDescription:nil]
		retain];
	[self didChangeValueForKey:@"popupMenuValues"];
	[self didChangeValueForKey:@"popupMenuItems"];
	self.selectedItem = [states objectAtIndex:0];
#else
	self.selectedItem = [NSDictionary dictionaryWithObject:@"Square" forKey:@"stateName"];
#endif
}

//
// popupMenuItems
//
// Returns the array of states (where "stateName" is the key for the human
// readable label).
//
- (NSArray *)popupMenuItems
{
	//
	// From the dictionary, we return the array of states already loaded.
	// Without a preloaded array, we generate and return the array of states.
	//
#ifdef STATE_FROM_DICTIONARY
	return states;
#else
	return [NSArray arrayWithObjects:
		[NSDictionary dictionaryWithObject:@"Square" forKey:@"stateName"],
		[NSDictionary dictionaryWithObject:@"Triangle" forKey:@"stateName"],
	nil];
#endif
}

#ifndef STATE_FROM_DICTIONARY
//
// stateName
//
// Convenience method to access the state name.
//
- (NSString *)stateName
{
	return [self.selectedItem objectForKey:@"stateName"];
}

#else
//
// clockwiseKey
//
// Unfortunately, the two states of a checkbox can't be string values, so
// this method is needed as a boolean to string value converter.
//
- (NSString *)clockwiseKey
{
	return self.clockwise ? @"clockwiseLabel" : @"anticlockwiseLabel";
}
#endif

//
// labelString
//
// Returns the current "label" string (which describes the current state).
//
- (NSString *)labelString
{
	//
	// From the dictionary, we return the label for the current "clockwise"
	// state. Without the state dictionary, we must construct the label in
	// code.
	//
#ifdef STATE_FROM_DICTIONARY
	return [self.selectedItem objectForKey:[self clockwiseKey]];
#else
	if ([[self stateName] isEqual:@"Square"])
	{
		if (self.clockwise)
		{
			return @"Animating around four points, clockwise";
		}
		else
		{
			return @"Animating around four points, anti-clockwise";
		}
	}
	else if ([[self stateName] isEqual:@"Triangle"])
	{
		if (self.clockwise)
		{
			return @"Animating around three points, clockwise";
		}
		else
		{
			return @"Animating around three points, anti-clockwise";
		}
	}
#endif
	return nil;
}

@end
