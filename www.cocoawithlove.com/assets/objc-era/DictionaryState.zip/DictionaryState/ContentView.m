//
//  ContentView.m
//  DictionaryState
//
//  Created by Matt Gallagher on 9/11/08.
//  Copyright 2008 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file without charge in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "ContentView.h"
#import <QuartzCore/QuartzCore.h>
#import "StateController.h"

@implementation ContentView

//
// dealloc
//
// Releases instance memory.
//
- (void)dealloc
{
	[stateController removeObserver:self forKeyPath:@"selectedItem"];
	[stateController release];
	[super dealloc];
}

//
// pointArray
//
// Method which returns the array of points used for the animation and for
// drawing the shape.
//
- (NSArray *)pointsArray
{
	NSArray *points;
#ifdef STATE_FROM_DICTIONARY
	//
	// Because a property list can't hold NSPoint, there is a little bit of
	// work here converting the NSDictionary from the property list to a
	// true array of NSPoints.
	//
	NSArray *dictionaryPoints = [stateController.selectedItem objectForKey:@"points"];
	points = [NSMutableArray arrayWithCapacity:[dictionaryPoints count]];
	for (NSDictionary *dictionary in dictionaryPoints)
	{
		NSPoint point =
			NSMakePoint(
				[[dictionary objectForKey:@"x"] doubleValue],
				[[dictionary objectForKey:@"y"] doubleValue]);
		[(NSMutableArray *)points addObject:[NSValue valueWithPoint:point]];
	}
#else
	//
	// Without the state dictionary, we must construct the entire arrays of
	// points based on the current state.
	//
	if ([[stateController stateName] isEqual:@"Square"])
	{
		points = 
			[NSArray arrayWithObjects:
				[NSValue valueWithPoint:NSMakePoint(140, 114)],
				[NSValue valueWithPoint:NSMakePoint(340, 114)],
				[NSValue valueWithPoint:NSMakePoint(340, 314)],
				[NSValue valueWithPoint:NSMakePoint(140, 314)],
				[NSValue valueWithPoint:NSMakePoint(140, 114)],
				nil];
	}
	else if ([[stateController stateName] isEqual:@"Triangle"])
	{
		points = 
			[NSArray arrayWithObjects:
				[NSValue valueWithPoint:NSMakePoint(311, 332)],
				[NSValue valueWithPoint:NSMakePoint(130, 197)],
				[NSValue valueWithPoint:NSMakePoint(338, 108)],
				[NSValue valueWithPoint:NSMakePoint(311, 332)],
				nil];
	}
#endif
	return points;
}

//
// startAnimationForLayer:
//
// Begins the animation (or replaces any existing animation).
//
- (void)startAnimationForLayer:(CALayer *)layer
{
	[CATransaction begin];
	[CATransaction setValue:(id)kCFBooleanFalse forKey:kCATransactionDisableActions];
	[CATransaction setValue:[NSNumber numberWithFloat:5.0] forKey:kCATransactionAnimationDuration];
	
	NSArray *points = [self pointsArray];
	if (stateController.clockwise)
	{
		NSMutableArray *reversePoints = [NSMutableArray arrayWithCapacity:[points count]];
		for (NSObject *object in [points reverseObjectEnumerator])
		{
			[reversePoints addObject:object];
		}
		points = reversePoints;
	}
	
	CAKeyframeAnimation *pathAnimation = [CAKeyframeAnimation animationWithKeyPath:@"position"];
	[pathAnimation setValues:points];
	[pathAnimation setRepeatCount:FLT_MAX];

	[layer addAnimation:pathAnimation forKey:@"position"];
	[CATransaction commit];
}

//
// awakeFromNib
//
// Establishes observation of the StateController, constructs the
// "Red Circle" layer and starts the inital animation.
//
- (void)awakeFromNib
{
	[stateController retain];
	[stateController
		addObserver:self
		forKeyPath:@"selectedItem"
		options:NSKeyValueObservingOptionNew
		context:nil];
	[stateController
		addObserver:self
		forKeyPath:@"clockwise"
		options:NSKeyValueObservingOptionNew
		context:nil];
	
	circleLayer = [CALayer new];
	[circleLayer setDelegate:self];
	[circleLayer setNeedsDisplay];
	
	CALayer *layer = [self layer];
	[layer addSublayer:circleLayer];
	
	const CGFloat CIRCLE_DIAMETER = 20.0;
	circleLayer.anchorPoint = CGPointMake(0.5, 0.5);
	circleLayer.frame = CGRectMake(0, 0, CIRCLE_DIAMETER, CIRCLE_DIAMETER);
	
	[self startAnimationForLayer:circleLayer];
}

//
// drawRect:
//
// Draws the gradient background and the shape around which the "Red Circle"
// will animate.
//
- (void)drawRect:(NSRect)rect
{
	//
	// Fill the background with a gradient.
	//
	NSGradient* aGradient =
		[[[NSGradient alloc]
			initWithColorsAndLocations:
				[NSColor colorWithCalibratedRed:094.0/255.0 green:150.0/255.0 blue:255.0/255.0 alpha:1.0], 0.0,
				[NSColor colorWithCalibratedRed:225.0/255.0 green:239.0/255.0 blue:240.0/255.0 alpha:1.0], 0.5,
				[NSColor colorWithCalibratedRed:255.0/255.0 green:204.0/255.0 blue:098.0/255.0 alpha:1.0], 0.65,
				[NSColor colorWithCalibratedRed:172.0/255.0 green:80.0/255.0 blue:013.0/255.0 alpha:1.0], 1.0,
				nil]
		autorelease];
	[aGradient drawInRect:self.bounds angle:-90];
	
	//
	// Construct the bezier from the array of points
	//
	NSArray *points = [self pointsArray];
	NSBezierPath *path = [NSBezierPath bezierPath];
	[path moveToPoint:[[points objectAtIndex:0] pointValue]];
	int i;
	int count = [points count];
	for (i = 1; i < count; i++)
	{
		NSValue *arrayObject = [points objectAtIndex:i];
		[path lineToPoint:[arrayObject pointValue]];
	}
	
#ifdef STATE_FROM_DICTIONARY
	//
	// Set the color for the shape from the dictionary
	//
	NSDictionary *drawColor = [stateController.selectedItem objectForKey:@"drawColor"];
	[[NSColor
		colorWithCalibratedRed:[[drawColor objectForKey:@"red"] doubleValue]
		green:[[drawColor objectForKey:@"green"] doubleValue]
		blue:[[drawColor objectForKey:@"blue"] doubleValue]
		alpha:[[drawColor objectForKey:@"alpha"] doubleValue]]
	set];
#else
	//
	// Set the color for the shape in code
	//
	if ([[stateController stateName] isEqual:@"Square"])
	{
		[[NSColor colorWithCalibratedRed:061.0/255.0 green:187.0/255.0 blue:056.0/255.0 alpha:122.0/255.0] set];
	}
	else if ([[stateController stateName] isEqual:@"Triangle"])
	{
		[[NSColor colorWithCalibratedRed:187.0/255.0 green:056.0/255.0 blue:186.0/255.0 alpha:122.0/255.0] set];
	}
#endif
		
	[path setLineWidth:9.0];
#ifdef STATE_FROM_DICTIONARY
	//
	// Invoke the drawing method specified by the state dictionary
	//
	SEL drawSelector =
		NSSelectorFromString([stateController.selectedItem objectForKey:@"drawSelector"]);
	[path performSelector:drawSelector withObject:nil];
#else
	//
	// Enumerate all the drawing code based on state
	//
	if ([[stateController stateName] isEqual:@"Square"])
	{
		[path fill];
	}
	else if ([[stateController stateName] isEqual:@"Triangle"])
	{
		[path stroke];
	}
#endif
	[path setLineWidth:1.5];
	[[NSColor whiteColor] set];
	[path stroke];
}

//
// drawLayer:inContext:
//
// Draws the "Red Circle" layer
//
- (void)drawLayer:(CALayer *)layer inContext:(CGContextRef)context
{
	//
	// Let the default implementation handle drawing the view
	//
	if ([layer isEqual:[self layer]])
	{
		[super drawLayer:layer inContext:context];
		return;
	}
	
	CGRect insetBounds = CGRectInset(layer.bounds, 2, 2); 
	
	CGContextSetRGBFillColor(context, 0.5, 0, 0, 1);
	CGContextFillEllipseInRect(context, insetBounds);
	
	CGContextSetLineWidth(context, 1.5);
	CGContextSetRGBStrokeColor(context, 1, 1, 1, 1);
	CGContextStrokeEllipseInRect(context, insetBounds);
}

//
// observeValueForKeyPath:ofObject:change:context:
//
// When the state changes, redraw everything and restart the animation.
//
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object
	change:(NSDictionary *)change context:(void *)context
{
	if ([keyPath isEqual:@"selectedItem"] || [keyPath isEqual:@"clockwise"])
	{
		[self setNeedsDisplay:YES];
		[circleLayer setNeedsDisplay];
		[self startAnimationForLayer:circleLayer];
		
		return;
	}
	
	[super observeValueForKeyPath:keyPath ofObject:object change:change
		context:context];
}

@end
