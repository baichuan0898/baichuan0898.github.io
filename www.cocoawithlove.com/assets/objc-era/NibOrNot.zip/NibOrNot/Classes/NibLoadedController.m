//
//  NibLoadedController.m
//  NibOrNot
//
//  Created by Matt Gallagher on 2010/03/02.
//  Copyright 2010 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "NibLoadedController.h"


@implementation NibLoadedController

//
// initWithRowCount:
//
- (id)initWithRowCount:(NSInteger)aRowCount
{
	if (self = [super initWithNibName:nil bundle:nil])
	{
		// Custom initialization
		rowCount = aRowCount;
	}
	return self;
}

//
// viewDidLoad
//
// Sets the rowHeight to something small
//
- (void)viewDidLoad
{
	self.tableView.rowHeight = 20;
}

//
// numberOfSectionsInTableView:
//
// Return the number of sections for the table.
//
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

//
// tableView:numberOfRowsInSection:
//
// Returns the number of rows in a given section.
//
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return rowCount;
}

//
// tableView:cellForRowAtIndexPath:
//
// Returns the cell for a given indexPath.
//
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	static NSString *CellIdentifier = @"Cell";
	
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (cell == nil)
	{
		double startTime = [NSDate timeIntervalSinceReferenceDate];
		
		[[NSBundle mainBundle] loadNibNamed:@"Cell" owner:self options:nil];
		cell = loadedCell;
		loadedCell = nil;

		double endTime = [NSDate timeIntervalSinceReferenceDate];
		
		NSLog(@"Loaded cell in %g seconds", endTime - startTime);
	}
	
	[(UILabel *)[cell viewWithTag:1]
		setText:[NSString stringWithFormat:@"Row %ld", indexPath.row]];

	return cell;
}
@end

