//
//  CodeGeneratedController.m
//  NibOrNot
//
//  Created by Matt Gallagher on 2010/03/02.
//  Copyright 2010 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "CodeGeneratedController.h"

@implementation CodeGeneratedController

//
// initWithRowCount:
//
- (id)initWithRowCount:(NSInteger)aRowCount
{
	if (self = [super initWithNibName:nil bundle:nil])
	{
		// Custom initialization
		rowCount = aRowCount;
	}
	return self;
}

//
// viewDidLoad
//
// Sets the rowHeight to something small
//
- (void)viewDidLoad
{
	self.tableView.rowHeight = 20;
}

//
// numberOfSectionsInTableView:
//
// Return the number of sections for the table.
//
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

//
// tableView:numberOfRowsInSection:
//
// Returns the number of rows in a given section.
//
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return rowCount;
}

//
// tableView:cellForRowAtIndexPath:
//
// Returns the cell for a given indexPath.
//
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	static NSString *CellIdentifier = @"Cell";
	
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (cell == nil)
	{
		double startTime = [NSDate timeIntervalSinceReferenceDate];
		
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
		cell.backgroundView = [[[UIView alloc] initWithFrame:CGRectZero] autorelease];
		cell.backgroundView.backgroundColor = [UIColor colorWithWhite:0.95 alpha:1.0];

		cell.selectedBackgroundView = [[[UIView alloc] initWithFrame:CGRectZero] autorelease];
		cell.selectedBackgroundView.backgroundColor = [UIColor colorWithWhite:0.85 alpha:1.0];
		
		UILabel *firstLabel =
			[[[UILabel alloc] initWithFrame:CGRectMake(5, 0, 60, 20)] autorelease];
		firstLabel.tag = 1;
		firstLabel.font = [UIFont boldSystemFontOfSize:14];
		firstLabel.shadowOffset = CGSizeMake(1,1);
		firstLabel.shadowColor = [UIColor whiteColor];
		firstLabel.textColor = [UIColor colorWithRed:0.0 green:0.2 blue:0.5 alpha:1.0];
		firstLabel.backgroundColor = [UIColor clearColor];
		firstLabel.text = @"placeholder";
		firstLabel.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
		firstLabel.adjustsFontSizeToFitWidth = YES;
		firstLabel.minimumFontSize = 10;
		firstLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		firstLabel.lineBreakMode = UILineBreakModeTailTruncation;
		firstLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		firstLabel.highlightedTextColor = [UIColor clearColor];
		
		[cell addSubview:firstLabel];
		
		UILabel *secondLabel =
			[[[UILabel alloc] initWithFrame:CGRectMake(150, 0, 60, 20)] autorelease];
		secondLabel.tag = 2;
		secondLabel.font = [UIFont boldSystemFontOfSize:14];
		secondLabel.shadowOffset = CGSizeMake(1,1);
		secondLabel.shadowColor = [UIColor whiteColor];
		secondLabel.textColor = [UIColor colorWithRed:0.0 green:0.2 blue:0.5 alpha:1.0];
		secondLabel.backgroundColor = [UIColor clearColor];
		secondLabel.text = @"placeholder";
		secondLabel.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
		secondLabel.adjustsFontSizeToFitWidth = YES;
		secondLabel.minimumFontSize = 10;
		secondLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		secondLabel.lineBreakMode = UILineBreakModeTailTruncation;
		secondLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		secondLabel.highlightedTextColor = [UIColor clearColor];
		
		[cell addSubview:secondLabel];
		
		UILabel *thirdLabel =
			[[[UILabel alloc] initWithFrame:CGRectMake(155, 0, 60, 20)] autorelease];
		thirdLabel.tag = 3;
		thirdLabel.font = [UIFont boldSystemFontOfSize:14];
		thirdLabel.shadowOffset = CGSizeMake(1,1);
		thirdLabel.shadowColor = [UIColor whiteColor];
		thirdLabel.textColor = [UIColor colorWithRed:0.0 green:0.2 blue:0.5 alpha:1.0];
		thirdLabel.backgroundColor = [UIColor clearColor];
		thirdLabel.text = @"placeholder";
		thirdLabel.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
		thirdLabel.adjustsFontSizeToFitWidth = YES;
		thirdLabel.minimumFontSize = 10;
		thirdLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		thirdLabel.lineBreakMode = UILineBreakModeTailTruncation;
		thirdLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		thirdLabel.highlightedTextColor = [UIColor clearColor];
		
		[cell addSubview:thirdLabel];
		
		UILabel *fourthLabel =
			[[[UILabel alloc] initWithFrame:CGRectMake(160, 0, 60, 20)] autorelease];
		fourthLabel.tag = 4;
		fourthLabel.font = [UIFont boldSystemFontOfSize:14];
		fourthLabel.shadowOffset = CGSizeMake(1,1);
		fourthLabel.shadowColor = [UIColor whiteColor];
		fourthLabel.textColor = [UIColor colorWithRed:0.0 green:0.2 blue:0.5 alpha:1.0];
		fourthLabel.backgroundColor = [UIColor clearColor];
		fourthLabel.text = @"placeholder";
		fourthLabel.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
		fourthLabel.adjustsFontSizeToFitWidth = YES;
		fourthLabel.minimumFontSize = 10;
		fourthLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		fourthLabel.lineBreakMode = UILineBreakModeTailTruncation;
		fourthLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		fourthLabel.highlightedTextColor = [UIColor clearColor];
		
		[cell addSubview:fourthLabel];
		
		UILabel *fifthLabel =
			[[[UILabel alloc] initWithFrame:CGRectMake(165, 0, 60, 20)] autorelease];
		fifthLabel.tag = 5;
		fifthLabel.font = [UIFont boldSystemFontOfSize:14];
		fifthLabel.shadowOffset = CGSizeMake(1,1);
		fifthLabel.shadowColor = [UIColor whiteColor];
		fifthLabel.textColor = [UIColor colorWithRed:0.0 green:0.2 blue:0.5 alpha:1.0];
		fifthLabel.backgroundColor = [UIColor clearColor];
		fifthLabel.text = @"placeholder";
		fifthLabel.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
		fifthLabel.adjustsFontSizeToFitWidth = YES;
		fifthLabel.minimumFontSize = 10;
		fifthLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		fifthLabel.lineBreakMode = UILineBreakModeTailTruncation;
		fifthLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		fifthLabel.highlightedTextColor = [UIColor clearColor];
		
		[cell addSubview:fifthLabel];
		
		UILabel *sixthLabel =
			[[[UILabel alloc] initWithFrame:CGRectMake(170, 0, 60, 20)] autorelease];
		sixthLabel.tag = 6;
		sixthLabel.font = [UIFont boldSystemFontOfSize:14];
		sixthLabel.shadowOffset = CGSizeMake(1,1);
		sixthLabel.shadowColor = [UIColor whiteColor];
		sixthLabel.textColor = [UIColor colorWithRed:0.0 green:0.2 blue:0.5 alpha:1.0];
		sixthLabel.backgroundColor = [UIColor clearColor];
		sixthLabel.text = @"placeholder";
		sixthLabel.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
		sixthLabel.adjustsFontSizeToFitWidth = YES;
		sixthLabel.minimumFontSize = 10;
		sixthLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		sixthLabel.lineBreakMode = UILineBreakModeTailTruncation;
		sixthLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		sixthLabel.highlightedTextColor = [UIColor clearColor];
		
		[cell addSubview:sixthLabel];
		
		UILabel *seventhLabel =
			[[[UILabel alloc] initWithFrame:CGRectMake(175, 0, 60, 20)] autorelease];
		seventhLabel.tag = 7;
		seventhLabel.font = [UIFont boldSystemFontOfSize:14];
		seventhLabel.shadowOffset = CGSizeMake(1,1);
		seventhLabel.shadowColor = [UIColor whiteColor];
		seventhLabel.textColor = [UIColor colorWithRed:0.0 green:0.2 blue:0.5 alpha:1.0];
		seventhLabel.backgroundColor = [UIColor clearColor];
		seventhLabel.text = @"placeholder";
		seventhLabel.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
		seventhLabel.adjustsFontSizeToFitWidth = YES;
		seventhLabel.minimumFontSize = 10;
		seventhLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		seventhLabel.lineBreakMode = UILineBreakModeTailTruncation;
		seventhLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		seventhLabel.highlightedTextColor = [UIColor clearColor];
		
		[cell addSubview:seventhLabel];
		
		UILabel *eigthLabel =
			[[[UILabel alloc] initWithFrame:CGRectMake(180, 0, 60, 20)] autorelease];
		eigthLabel.tag = 8;
		eigthLabel.font = [UIFont boldSystemFontOfSize:14];
		eigthLabel.shadowOffset = CGSizeMake(1,1);
		eigthLabel.shadowColor = [UIColor whiteColor];
		eigthLabel.textColor = [UIColor colorWithRed:0.0 green:0.2 blue:0.5 alpha:1.0];
		eigthLabel.backgroundColor = [UIColor clearColor];
		eigthLabel.text = @"placeholder";
		eigthLabel.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
		eigthLabel.adjustsFontSizeToFitWidth = YES;
		eigthLabel.minimumFontSize = 10;
		eigthLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		eigthLabel.lineBreakMode = UILineBreakModeTailTruncation;
		eigthLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		eigthLabel.highlightedTextColor = [UIColor clearColor];
		
		[cell addSubview:eigthLabel];
		
		UILabel *ninthLabel =
			[[[UILabel alloc] initWithFrame:CGRectMake(185, 0, 60, 20)] autorelease];
		ninthLabel.tag = 9;
		ninthLabel.font = [UIFont boldSystemFontOfSize:14];
		ninthLabel.shadowOffset = CGSizeMake(1,1);
		ninthLabel.shadowColor = [UIColor whiteColor];
		ninthLabel.textColor = [UIColor colorWithRed:0.0 green:0.2 blue:0.5 alpha:1.0];
		ninthLabel.backgroundColor = [UIColor clearColor];
		ninthLabel.text = @"placeholder";
		ninthLabel.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
		ninthLabel.adjustsFontSizeToFitWidth = YES;
		ninthLabel.minimumFontSize = 10;
		ninthLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		ninthLabel.lineBreakMode = UILineBreakModeTailTruncation;
		ninthLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		ninthLabel.highlightedTextColor = [UIColor clearColor];
		
		[cell addSubview:ninthLabel];
		
		UILabel *tenthLabel =
			[[[UILabel alloc] initWithFrame:CGRectMake(190, 0, 60, 20)] autorelease];
		tenthLabel.tag = 10;
		tenthLabel.font = [UIFont boldSystemFontOfSize:14];
		tenthLabel.shadowOffset = CGSizeMake(1,1);
		tenthLabel.shadowColor = [UIColor whiteColor];
		tenthLabel.textColor = [UIColor colorWithRed:0.0 green:0.2 blue:0.5 alpha:1.0];
		tenthLabel.backgroundColor = [UIColor clearColor];
		tenthLabel.text = @"placeholder";
		tenthLabel.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
		tenthLabel.adjustsFontSizeToFitWidth = YES;
		tenthLabel.minimumFontSize = 10;
		tenthLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		tenthLabel.lineBreakMode = UILineBreakModeTailTruncation;
		tenthLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		tenthLabel.highlightedTextColor = [UIColor clearColor];
		
		[cell addSubview:tenthLabel];
		
		UILabel *eleventhLabel =
			[[[UILabel alloc] initWithFrame:CGRectMake(195, 0, 60, 20)] autorelease];
		eleventhLabel.tag = 11;
		eleventhLabel.font = [UIFont boldSystemFontOfSize:14];
		eleventhLabel.shadowOffset = CGSizeMake(1,1);
		eleventhLabel.shadowColor = [UIColor whiteColor];
		eleventhLabel.textColor = [UIColor colorWithRed:0.0 green:0.2 blue:0.5 alpha:1.0];
		eleventhLabel.backgroundColor = [UIColor clearColor];
		eleventhLabel.text = @"placeholder";
		eleventhLabel.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
		eleventhLabel.adjustsFontSizeToFitWidth = YES;
		eleventhLabel.minimumFontSize = 10;
		eleventhLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		eleventhLabel.lineBreakMode = UILineBreakModeTailTruncation;
		eleventhLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		eleventhLabel.highlightedTextColor = [UIColor clearColor];
		
		[cell addSubview:eleventhLabel];
		
		UILabel *twelfthLabel =
			[[[UILabel alloc] initWithFrame:CGRectMake(200, 0, 60, 20)] autorelease];
		twelfthLabel.tag = 12;
		twelfthLabel.font = [UIFont boldSystemFontOfSize:14];
		twelfthLabel.shadowOffset = CGSizeMake(1,1);
		twelfthLabel.shadowColor = [UIColor whiteColor];
		twelfthLabel.textColor = [UIColor colorWithRed:0.0 green:0.2 blue:0.5 alpha:1.0];
		twelfthLabel.backgroundColor = [UIColor clearColor];
		twelfthLabel.text = @"placeholder";
		twelfthLabel.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
		twelfthLabel.adjustsFontSizeToFitWidth = YES;
		twelfthLabel.minimumFontSize = 10;
		twelfthLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		twelfthLabel.lineBreakMode = UILineBreakModeTailTruncation;
		twelfthLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		twelfthLabel.highlightedTextColor = [UIColor clearColor];
		
		[cell addSubview:twelfthLabel];
		
		UILabel *thirteenthLabel =
			[[[UILabel alloc] initWithFrame:CGRectMake(205, 0, 60, 20)] autorelease];
		thirteenthLabel.tag = 13;
		thirteenthLabel.font = [UIFont boldSystemFontOfSize:14];
		thirteenthLabel.shadowOffset = CGSizeMake(1,1);
		thirteenthLabel.shadowColor = [UIColor whiteColor];
		thirteenthLabel.textColor = [UIColor colorWithRed:0.0 green:0.2 blue:0.5 alpha:1.0];
		thirteenthLabel.backgroundColor = [UIColor clearColor];
		thirteenthLabel.text = @"placeholder";
		thirteenthLabel.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
		thirteenthLabel.adjustsFontSizeToFitWidth = YES;
		thirteenthLabel.minimumFontSize = 10;
		thirteenthLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		thirteenthLabel.lineBreakMode = UILineBreakModeTailTruncation;
		thirteenthLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		thirteenthLabel.highlightedTextColor = [UIColor clearColor];
		
		[cell addSubview:thirteenthLabel];
		
		UILabel *fourteenthLabel =
			[[[UILabel alloc] initWithFrame:CGRectMake(210, 0, 60, 20)] autorelease];
		fourteenthLabel.tag = 14;
		fourteenthLabel.font = [UIFont boldSystemFontOfSize:14];
		fourteenthLabel.shadowOffset = CGSizeMake(1,1);
		fourteenthLabel.shadowColor = [UIColor whiteColor];
		fourteenthLabel.textColor = [UIColor colorWithRed:0.0 green:0.2 blue:0.5 alpha:1.0];
		fourteenthLabel.backgroundColor = [UIColor clearColor];
		fourteenthLabel.text = @"placeholder";
		fourteenthLabel.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
		fourteenthLabel.adjustsFontSizeToFitWidth = YES;
		fourteenthLabel.minimumFontSize = 10;
		fourteenthLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		fourteenthLabel.lineBreakMode = UILineBreakModeTailTruncation;
		fourteenthLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		fourteenthLabel.highlightedTextColor = [UIColor clearColor];
		
		[cell addSubview:fourteenthLabel];
		
		UILabel *fifteenthLabel =
			[[[UILabel alloc] initWithFrame:CGRectMake(215, 0, 60, 20)] autorelease];
		fifteenthLabel.tag = 15;
		fifteenthLabel.font = [UIFont boldSystemFontOfSize:14];
		fifteenthLabel.shadowOffset = CGSizeMake(1,1);
		fifteenthLabel.shadowColor = [UIColor whiteColor];
		fifteenthLabel.textColor = [UIColor colorWithRed:0.0 green:0.2 blue:0.5 alpha:1.0];
		fifteenthLabel.backgroundColor = [UIColor clearColor];
		fifteenthLabel.text = @"placeholder";
		fifteenthLabel.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
		fifteenthLabel.adjustsFontSizeToFitWidth = YES;
		fifteenthLabel.minimumFontSize = 10;
		fifteenthLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		fifteenthLabel.lineBreakMode = UILineBreakModeTailTruncation;
		fifteenthLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		fifteenthLabel.highlightedTextColor = [UIColor clearColor];
		
		[cell addSubview:fifteenthLabel];
		
		UILabel *sixteenthLabel =
			[[[UILabel alloc] initWithFrame:CGRectMake(220, 0, 60, 20)] autorelease];
		sixteenthLabel.tag = 16;
		sixteenthLabel.font = [UIFont boldSystemFontOfSize:14];
		sixteenthLabel.shadowOffset = CGSizeMake(1,1);
		sixteenthLabel.shadowColor = [UIColor whiteColor];
		sixteenthLabel.textColor = [UIColor colorWithRed:0.0 green:0.2 blue:0.5 alpha:1.0];
		sixteenthLabel.backgroundColor = [UIColor clearColor];
		sixteenthLabel.text = @"placeholder";
		sixteenthLabel.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
		sixteenthLabel.adjustsFontSizeToFitWidth = YES;
		sixteenthLabel.minimumFontSize = 10;
		sixteenthLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		sixteenthLabel.lineBreakMode = UILineBreakModeTailTruncation;
		sixteenthLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		sixteenthLabel.highlightedTextColor = [UIColor clearColor];
		
		[cell addSubview:sixteenthLabel];
		
		UILabel *seventeenthLabel =
			[[[UILabel alloc] initWithFrame:CGRectMake(225, 0, 60, 20)] autorelease];
		seventeenthLabel.tag = 17;
		seventeenthLabel.font = [UIFont boldSystemFontOfSize:14];
		seventeenthLabel.shadowOffset = CGSizeMake(1,1);
		seventeenthLabel.shadowColor = [UIColor whiteColor];
		seventeenthLabel.textColor = [UIColor colorWithRed:0.0 green:0.2 blue:0.5 alpha:1.0];
		seventeenthLabel.backgroundColor = [UIColor clearColor];
		seventeenthLabel.text = @"placeholder";
		seventeenthLabel.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
		seventeenthLabel.adjustsFontSizeToFitWidth = YES;
		seventeenthLabel.minimumFontSize = 10;
		seventeenthLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		seventeenthLabel.lineBreakMode = UILineBreakModeTailTruncation;
		seventeenthLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		seventeenthLabel.highlightedTextColor = [UIColor clearColor];
		
		[cell addSubview:seventeenthLabel];
		
		UILabel *eighteenthLabel =
			[[[UILabel alloc] initWithFrame:CGRectMake(230, 0, 60, 20)] autorelease];
		eighteenthLabel.tag = 18;
		eighteenthLabel.font = [UIFont boldSystemFontOfSize:14];
		eighteenthLabel.shadowOffset = CGSizeMake(1,1);
		eighteenthLabel.shadowColor = [UIColor whiteColor];
		eighteenthLabel.textColor = [UIColor colorWithRed:0.0 green:0.2 blue:0.5 alpha:1.0];
		eighteenthLabel.backgroundColor = [UIColor clearColor];
		eighteenthLabel.text = @"placeholder";
		eighteenthLabel.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
		eighteenthLabel.adjustsFontSizeToFitWidth = YES;
		eighteenthLabel.minimumFontSize = 10;
		eighteenthLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		eighteenthLabel.lineBreakMode = UILineBreakModeTailTruncation;
		eighteenthLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		eighteenthLabel.highlightedTextColor = [UIColor clearColor];
		
		[cell addSubview:eighteenthLabel];
		
		UILabel *nineteenthLabel =
			[[[UILabel alloc] initWithFrame:CGRectMake(235, 0, 60, 20)] autorelease];
		nineteenthLabel.tag = 19;
		nineteenthLabel.font = [UIFont boldSystemFontOfSize:14];
		nineteenthLabel.shadowOffset = CGSizeMake(1,1);
		nineteenthLabel.shadowColor = [UIColor whiteColor];
		nineteenthLabel.textColor = [UIColor colorWithRed:0.0 green:0.2 blue:0.5 alpha:1.0];
		nineteenthLabel.backgroundColor = [UIColor clearColor];
		nineteenthLabel.text = @"placeholder";
		nineteenthLabel.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
		nineteenthLabel.adjustsFontSizeToFitWidth = YES;
		nineteenthLabel.minimumFontSize = 10;
		nineteenthLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		nineteenthLabel.lineBreakMode = UILineBreakModeTailTruncation;
		nineteenthLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		nineteenthLabel.highlightedTextColor = [UIColor clearColor];
		
		[cell addSubview:nineteenthLabel];
		
		UILabel *twentiethLabel =
			[[[UILabel alloc] initWithFrame:CGRectMake(240, 0, 60, 20)] autorelease];
		twentiethLabel.tag = 20;
		twentiethLabel.font = [UIFont boldSystemFontOfSize:14];
		twentiethLabel.shadowOffset = CGSizeMake(1,1);
		twentiethLabel.shadowColor = [UIColor whiteColor];
		twentiethLabel.textColor = [UIColor colorWithRed:0.0 green:0.2 blue:0.5 alpha:1.0];
		twentiethLabel.backgroundColor = [UIColor clearColor];
		twentiethLabel.text = @"placeholder";
		twentiethLabel.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
		twentiethLabel.adjustsFontSizeToFitWidth = YES;
		twentiethLabel.minimumFontSize = 10;
		twentiethLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		twentiethLabel.lineBreakMode = UILineBreakModeTailTruncation;
		twentiethLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		twentiethLabel.highlightedTextColor = [UIColor clearColor];
		
		[cell addSubview:twentiethLabel];

		double endTime = [NSDate timeIntervalSinceReferenceDate];
		
		NSLog(@"Generated cell in %g seconds", endTime - startTime);
    }
	
	[(UILabel *)[cell viewWithTag:1]
		setText:[NSString stringWithFormat:@"Row %ld", indexPath.row]];
	
    return cell;
}

@end
