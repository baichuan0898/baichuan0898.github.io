//
//  RootViewController.m
//  NibOrNot
//
//  Created by Matt Gallagher on 2010/03/02.
//  Copyright Matt Gallagher 2010. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "RootViewController.h"
#import "CodeGeneratedController.h"
#import "NibLoadedController.h"

@implementation RootViewController

//
// numberOfSectionsInTableView:
//
// Return the number of sections for the table.
//
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

//
// tableView:numberOfRowsInSection:
//
// Returns the number of rows in a given section.
//
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 4;
}


//
// tableView:cellForRowAtIndexPath:
//
// Returns the cell for a given indexPath.
//
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
	{
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    
	// Configure the cell.
	if (indexPath.row == 0)
	{
		cell.textLabel.text = @"Code generated single cell";
	}
	else if (indexPath.row == 1)
	{
		cell.textLabel.text = @"Nib loaded single cell";
	}
	else if (indexPath.row == 2)
	{
		cell.textLabel.text = @"Code generated 20 cells";
	}
	else if (indexPath.row == 3)
	{
		cell.textLabel.text = @"Nib loaded 20 cells";
	}

    return cell;
}



//
// tableView:didSelectRowAtIndexPath:
//
// Pushes the selected view controller onto the navigation controller
//
// Parameters:
//    tableView - our table view
//    indexPath - the indexPath of the selected row
//
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	UIViewController *viewController;
	if (indexPath.row == 0)
	{
		viewController = [[[CodeGeneratedController alloc] initWithRowCount:1] autorelease];
	}
	else if (indexPath.row == 1)
	{
		viewController = [[[NibLoadedController alloc] initWithRowCount:1] autorelease];
	}
	else if (indexPath.row == 2)
	{
		viewController = [[[CodeGeneratedController alloc] initWithRowCount:20] autorelease];
	}
	else if (indexPath.row == 3)
	{
		viewController = [[[NibLoadedController alloc] initWithRowCount:20] autorelease];
	}
	
	[self.navigationController pushViewController:viewController animated:YES];
	[self.tableView deselectRowAtIndexPath:indexPath animated:YES];
}

@end

