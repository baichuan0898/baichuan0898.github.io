#import <Foundation/Foundation.h>
#import <libkern/OSAtomic.h>

@interface Node : NSObject
{
	NSSet *linkedNodes;
}
@property (nonatomic, retain) NSSet *linkedNodes;
@end

@implementation Node
@synthesize linkedNodes;
@end

const NSInteger NUM_LINKED_NODES = 2;

NSArray *addDecreasingLinksToNodes(NSArray *nodes)
{
	NSMutableArray *allLinks = [NSMutableArray arrayWithCapacity:[nodes count] / NUM_LINKED_NODES];
	
	NSInteger i;
	for (i = 0; i < [nodes count]; i += NUM_LINKED_NODES)
	{
		Node *link = [[[Node alloc] init] autorelease];
		[allLinks addObject:link];

		NSSet *links = [NSSet setWithObject:link];
		
		NSInteger j;
		for (j = i; j < i + NUM_LINKED_NODES; j++)
		{
			((Node *)[nodes objectAtIndex:j]).linkedNodes = links;
		}
	}
	
	return allLinks;
}

NSArray *addIncreasingLinksToNodes(NSArray *nodes)
{
	NSMutableArray *allLinks = [NSMutableArray arrayWithCapacity:[nodes count] * NUM_LINKED_NODES];
	
	for (Node *node in nodes)
	{
		NSMutableSet *links = [NSMutableSet setWithCapacity:NUM_LINKED_NODES];
		NSInteger i;
		for (i = 0; i < NUM_LINKED_NODES; i++)
		{
			Node *link = [[[Node alloc] init] autorelease];
			[links addObject:link];
			[allLinks addObject:link];
		}
		
		node.linkedNodes = links;
	}
	
	return allLinks;
}

void TraverseGraphFromNode1(Node *startingNode)
{
	NSDate *startDate = [NSDate date];
	
	NSMutableSet *visitedNodes = [NSMutableSet setWithObject:startingNode];
	NSMutableArray *queue = [NSMutableArray arrayWithObject:startingNode];

	while ([queue count] > 0)
	{
		NSMutableSet *newNodes = [[((Node *)[queue lastObject]).linkedNodes mutableCopy] autorelease];
		[newNodes minusSet:visitedNodes];
		
		[visitedNodes unionSet:newNodes];
		[queue replaceObjectsInRange:NSMakeRange(0, 0) withObjectsFromArray:[newNodes allObjects]];
		
		[queue removeLastObject];
	}
	
	NSDate *endDate = [NSDate date];
	NSTimeInterval interval = [endDate timeIntervalSinceDate:startDate];

	NSLog(@"1: Visited %ld nodes in %f seconds", [visitedNodes count], interval);
}

void TraverseGraphFromNode2(Node *startingNode)
{
	NSDate *startDate = [NSDate date];
	
	NSMutableSet *visitedNodes = [NSMutableSet setWithObject:startingNode];
	NSMutableArray *queue = [NSMutableArray arrayWithObject:startingNode];
	NSInteger nodeCount = 0;
	
	while ([queue count] > 0)
	{
		NSSet *newNodes = ((Node *)[queue lastObject]).linkedNodes;
		for (Node *newNode in newNodes)
		{
			if (![visitedNodes containsObject:newNode])
			{
				[visitedNodes addObject:newNode];
				[queue insertObject:newNode atIndex:0];
			}
		}

		[queue removeLastObject];
		nodeCount++;
	}
	
	NSDate *endDate = [NSDate date];
	NSTimeInterval interval = [endDate timeIntervalSinceDate:startDate];

	NSLog(@"2: Visited %ld nodes in %f seconds", nodeCount, interval);
}

void TraverseGraphFromNode3(Node *startingNode)
{
	NSDate *startDate = [NSDate date];
	
	NSMutableSet *visitedNodes = [NSMutableSet setWithObject:startingNode];
	NSMutableArray *queue = [NSMutableArray arrayWithObject:startingNode];
	NSInteger nodeCount = 0;
	
	while ([queue count] > 0)
	{
		NSSet *newNodes = ((Node *)[queue objectAtIndex:0]).linkedNodes;
		for (Node *newNode in newNodes)
		{
			if (![visitedNodes containsObject:newNode])
			{
				[visitedNodes addObject:newNode];
				[queue addObject:newNode];
			}
		}

		[queue removeObjectAtIndex:0];
		nodeCount++;
	}
	
	NSDate *endDate = [NSDate date];
	NSTimeInterval interval = [endDate timeIntervalSinceDate:startDate];

	NSLog(@"3: Visited %ld nodes in %f seconds", nodeCount, interval);
}

void TraverseGraphFromNode4(Node *startingNode)
{
	NSDate *startDate = [NSDate date];
	
	NSMutableSet *visitedNodes = [NSMutableSet setWithObject:startingNode];
	NSMutableArray *queue = [NSMutableArray arrayWithObject:startingNode];
	NSInteger nodeCount = 0;
	
	while ([queue count] > 0)
	{
		NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
		
		NSSet *newNodes = ((Node *)[queue objectAtIndex:0]).linkedNodes;
		for (Node *newNode in newNodes)
		{
			if (![visitedNodes containsObject:newNode])
			{
				[visitedNodes addObject:newNode];
				[queue addObject:newNode];
			}
		}

		[queue removeObjectAtIndex:0];
		nodeCount++;
		
		[pool drain];
	}
	
	NSDate *endDate = [NSDate date];
	NSTimeInterval interval = [endDate timeIntervalSinceDate:startDate];

	NSLog(@"4: Visited %ld nodes in %f seconds", nodeCount, interval);
}

NSMutableSet *recursiveSet = nil;
NSInteger recursiveNodeCount = 0;

void RecursivelyTraverse(Node *node)
{
	NSSet *newNodes = node.linkedNodes;
	for (Node *newNode in newNodes)
	{
		if (![recursiveSet containsObject:newNode])
		{
			[recursiveSet addObject:newNode];
			RecursivelyTraverse(newNode);
		}
	}
	
	recursiveNodeCount++;
}

void TraverseGraphFromNode6(Node *startingNode)
{
	NSDate *startDate = [NSDate date];
	
	recursiveSet = [NSMutableSet setWithObject:startingNode];
	
	RecursivelyTraverse(startingNode);
	
	NSDate *endDate = [NSDate date];
	NSTimeInterval interval = [endDate timeIntervalSinceDate:startDate];

	NSLog(@"6: Visited %ld nodes in %f seconds", recursiveNodeCount, interval);
}

NSOperationQueue *operationQueue = nil;
NSLock *operationQueueVisitedNodesLock = nil;
NSMutableSet *operationQueueVisitedNodes = nil;
volatile SInt32 operationQueueVisitedNodeCount = 0;

@interface TraversalOperation : NSOperation
{
	Node *node;
}
- (id)initWithNode:(Node *)newNode;
@end

@implementation TraversalOperation

- (id)initWithNode:(Node *)newNode
{
	self = [super init];
	if (self != nil)
	{
		node = [newNode retain];
	}
	return self;
}

- (void)main
{
	NSSet *newNodes = node.linkedNodes;
	
	for (Node *newNode in newNodes)
	{
		[operationQueueVisitedNodesLock lock];
		if (![operationQueueVisitedNodes containsObject:newNode])
		{
			[operationQueueVisitedNodes addObject:newNode];
			operationQueueVisitedNodeCount++;
			[operationQueueVisitedNodesLock unlock];
			[operationQueue addOperation:[[[TraversalOperation alloc] initWithNode:newNode] autorelease]];
		}
		else
		{
			[operationQueueVisitedNodesLock unlock];
		}
	}
}

- (void)dealloc
{
	[node release];
	[super dealloc];
}

@end

void TraverseGraphFromNode5(Node *startingNode)
{
	
	operationQueue = [[NSOperationQueue alloc] init];
	[operationQueue setMaxConcurrentOperationCount:1];
	operationQueueVisitedNodesLock = [[NSLock alloc] init];
	operationQueueVisitedNodes = [[NSMutableSet alloc] init];

	NSDate *startDate = [NSDate date];

	operationQueueVisitedNodeCount++;
	[operationQueue addOperation:[[[TraversalOperation alloc] initWithNode:startingNode] autorelease]];
	[operationQueue waitUntilAllOperationsAreFinished];
	
	NSDate *endDate = [NSDate date];
	NSTimeInterval interval = [endDate timeIntervalSinceDate:startDate];

	NSLog(@"5: Visited %d nodes in %f seconds", operationQueueVisitedNodeCount, interval);

	[operationQueue release];
	[operationQueueVisitedNodesLock release];
	[operationQueueVisitedNodes release];
}

int main (int argc, const char * argv[])
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
	const NSInteger HALF_GRAPH_DEPTH = 20;
	Node *head = [[[Node alloc] init] autorelease];
	NSArray *nodeArray = [NSArray arrayWithObject:head];
	
	NSInteger i;
	NSInteger totalNodeCount = 1;
	for (i = 0; i < HALF_GRAPH_DEPTH; i++)
	{
		nodeArray = addIncreasingLinksToNodes(nodeArray);
		totalNodeCount += [nodeArray count];
	}
	for (i = 0; i < HALF_GRAPH_DEPTH; i++)
	{
		nodeArray = addDecreasingLinksToNodes(nodeArray);
		totalNodeCount += [nodeArray count];
	}
	NSLog(@"Created %ld nodes", totalNodeCount);
	
	TraverseGraphFromNode1(head);
	TraverseGraphFromNode2(head);
	TraverseGraphFromNode3(head);
	TraverseGraphFromNode4(head);
	TraverseGraphFromNode5(head);
	TraverseGraphFromNode6(head);
	
    [pool drain];
    return 0;
}
