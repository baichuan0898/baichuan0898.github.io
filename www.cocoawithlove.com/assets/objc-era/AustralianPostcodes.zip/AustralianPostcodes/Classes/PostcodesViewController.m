//
//  PostcodesViewController.m
//  AustralianPostcodes
//
//  Created by Matt Gallagher on 2009/12/07.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "PostcodesViewController.h"
#import "PostcodesController.h"
#import "MapViewController.h"

@implementation PostcodesViewController

@synthesize fetchedResultsController;

//
// initWithSortKey:
//
// Init method for the object.
//
- (id)initWithSortKey:(NSString *)aSortKey
{
	self = [super initWithStyle:UITableViewStylePlain];
	if (self != nil)
	{
		sortKey = [aSortKey retain];
	}
	return self;
}

//
// title
//
// returns the text to show in the navigation bar
//
- (NSString *)title
{
	return [NSString stringWithFormat:NSLocalizedString(@"By %@", nil),
		NSLocalizedString(sortKey, nil)];
}

#pragma mark -- Table view methods

//
// viewDidLoad
//
// Load the data for the view when the view is loaded.
//
- (void)viewDidLoad
{
	[super viewDidLoad];

	[searchString release];
	searchString = nil;

	NSError *error = nil;
	if (![[self fetchedResultsController] performFetch:&error])
	{
		NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
		abort();
	}
}

//
// viewDidUnload
//
// Unloads elements loaded by the view.
//
- (void)viewDidUnload
{
	[super viewDidUnload];
}

//
// numberOfSectionsInTableView:
//
// Parameters:
//    tableView - should be the table we control
//
// returns the number of sections in the table as specified by the fetched
//	results controller.
//
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return [[fetchedResultsController sections] count];
}


//
// tableView:numberOfRowsInSection:
//
// Parameters:
//    tableView - should be the table we control
//    section - a section in the table
//
// returns the number of rows in the section as specified by the fetched
//	results controller.
//
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	id <NSFetchedResultsSectionInfo> sectionInfo =
		[[fetchedResultsController sections] objectAtIndex:section];
	return [sectionInfo numberOfObjects] + 1;
}


//
// searchBarCellForTableView:
//
// Constructs the search bar for the table (intended for use by
// tableView:cellForRowAtIndexPath:).
//
// Parameters:
//    tableView - the table
//
// returns the constructed and configured search bar
//
- (UITableViewCell *)searchBarCellForTableView:(UITableView *)tableView
{
	static NSString *SearchCellIdentifier = @"SearchCell";
	UITableViewCell *searchCell =
		[tableView dequeueReusableCellWithIdentifier:SearchCellIdentifier];
	if (searchCell == nil)
	{
		searchCell =
			[[[UITableViewCell alloc]
				initWithStyle:UITableViewCellStyleDefault
				reuseIdentifier:SearchCellIdentifier]
			autorelease];
		UISearchBar *searchBar =
			[[[UISearchBar alloc]
				initWithFrame:searchCell.contentView.bounds]
			autorelease];
		[searchBar setShowsCancelButton:YES];
		[searchBar setDelegate:self];
		[searchCell.contentView addSubview:searchBar];
	}
	
	return searchCell;
}

//
// tableView:cellForRowAtIndexPath:
//
// Constructs/configures the view for a given row of data
//
// Parameters:
//    tableView - should be the table we control
//    indexPath - the indexPath of the row whose view we will construct/configure
//
// returns the constructed/configured row
//
- (UITableViewCell *)tableView:(UITableView *)tableView
	cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	//
	// For the first row, construct and return the search bar
	//
	if (indexPath.row == 0)
	{
		return [self searchBarCellForTableView:tableView];
	}
	
	//
	// All other rows, construct and return the data cell
	//
	static NSString *DataCellIdentifier = @"DataCell";
	UITableViewCell *cell =
		[tableView dequeueReusableCellWithIdentifier:DataCellIdentifier];
	if (cell == nil)
	{
		cell =
			[[[UITableViewCell alloc]
				initWithStyle:UITableViewCellStyleValue1
				reuseIdentifier:DataCellIdentifier]
			autorelease];
		cell.detailTextLabel.textAlignment = UITextAlignmentLeft;
	}
	
	NSIndexPath *offsetIndexPath =
		[NSIndexPath
			indexPathForRow:indexPath.row - 1
			inSection:indexPath.section];
	
	// Configure the cell.
	Postcode *postcode =
		[fetchedResultsController objectAtIndexPath:offsetIndexPath];
	cell.textLabel.text = [postcode title];
	cell.detailTextLabel.text = [postcode subtitle];
	
	return cell;
}


//
// tableView:didSelectRowAtIndexPath:
//
// When a row in the postcodes view is selected, bring up the Map View for
// the selected postcode.
//
// Parameters:
//    tableView - should be the table view we control
//    indexPath - the index path of the selected row
//
- (void)tableView:(UITableView *)tableView
	didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	if (indexPath.row == 0)
	{
		return;
	}
	
	NSIndexPath *offsetIndexPath =
		[NSIndexPath
			indexPathForRow:indexPath.row - 1
			inSection:indexPath.section];
	
	 Postcode *selectedObject =
	 	[[self fetchedResultsController] objectAtIndexPath:offsetIndexPath];
	 MapViewController *detailViewController =
	 	[[[MapViewController alloc] initWithPostcode:selectedObject] autorelease];
	[self.navigationController pushViewController:detailViewController animated:YES];
}

#pragma mark -- Fetched results controller

//
// fetchedResultsController
//
// returns the configured results controller for this view's table.
//
- (NSFetchedResultsController *)fetchedResultsController
{
	if (fetchedResultsController != nil)
	{
		return fetchedResultsController;
	}
	
	// Create the fetch request for the entity.
	NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
	// Edit the entity name as appropriate.
	NSEntityDescription *entity =
		[NSEntityDescription
			entityForName:@"Postcode"
			inManagedObjectContext:
				[PostcodesController sharedPostcodesController].managedObjectContext];
	[fetchRequest setEntity:entity];
	
	// Apply a filter predicate
	if ([searchString length] > 0)
	{
		NSNumber *searchNumber =
			[NSNumber numberWithInteger:[searchString integerValue]];
		if ([searchNumber integerValue] > 0)
		{
			[fetchRequest setPredicate:
				[NSPredicate predicateWithFormat:
					@"postcode == %@",
					[NSNumber numberWithInteger:[searchString integerValue]]]];
		}
		else
		{
			[fetchRequest setPredicate:
				[NSPredicate predicateWithFormat:
					@"suburb CONTAINS %@",
					[searchString uppercaseString]]];
		}
	}
	
	// Set the batch size to a suitable number.
	[fetchRequest setFetchBatchSize:10];
	
	// Edit the sort key as appropriate.
	NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:sortKey ascending:YES];
	NSArray *sortDescriptors = [[NSArray alloc] initWithObjects:sortDescriptor, nil];
	
	[fetchRequest setSortDescriptors:sortDescriptors];
	
	// Edit the section name key path and cache name if appropriate.
	// nil for section name key path means "no sections".
	NSFetchedResultsController *aFetchedResultsController =
		[[NSFetchedResultsController alloc]
			initWithFetchRequest:fetchRequest
			managedObjectContext:[PostcodesController sharedPostcodesController].managedObjectContext
			sectionNameKeyPath:nil
			cacheName:[searchString length] > 0 ? nil : sortKey];
	aFetchedResultsController.delegate = self;
	self.fetchedResultsController = aFetchedResultsController;
	
	[aFetchedResultsController release];
	[fetchRequest release];
	[sortDescriptor release];
	[sortDescriptors release];
	
	return fetchedResultsController;
}	


//
// controllerDidChangeContent:
//
// Responds to changes in the controller's data by reloading the view.
//
// Parameters:
//    controller - our fetched results controller
//
- (void)controllerDidChangeContent:(NSFetchedResultsController *)controller
{
	// In the simplest, most efficient, case, reload the table view.
	[self.tableView reloadData];
}

//
// setSearchString:
//
// Sets the search string and forces a refresh of the data
//
// Parameters:
//    setSearchString - the string to use as the search string
//
- (void)setSearchString:(NSString *)newSearchString
{
	self.fetchedResultsController = nil;
	[searchString release];
	searchString = [newSearchString retain];

	NSError *error = nil;
	if (![[self fetchedResultsController] performFetch:&error])
	{
		NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
		abort();
	}
	
	[self.tableView reloadData];
}

#pragma mark -- Search bar delegate methods

//
// searchBarCancelButtonClicked:
//
// Clear the search and dismiss the keyboard when the cancel button is pressed.
// Also clear the "focusSearchBar" flag.
//
// Parameters:
//    searchBar - the search bar
//
- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
	searchBar.text = @"";
	
	if ([searchString length] > 0)
	{
		[self setSearchString:nil];
	}
	
	[searchBar resignFirstResponder];
}

//
// searchBarSearchButtonClicked:
//
// Clear the "focusSearchBar" flag and dismiss the keyboard.
//
// Parameters:
//    searchBar - the search bar
//
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
	[self setSearchString:searchBar.text];
}

//
// dealloc
//
// Frees the instance memory.
//
- (void)dealloc
{
	[fetchedResultsController release];
	[sortKey release];
	[super dealloc];
}


@end

