//
//  Postcode.m
//  AustralianPostcodes
//
//  Created by Matt Gallagher on 2009/12/08.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "Postcode.h"


@implementation Postcode

- (CLLocationCoordinate2D)coordinate
{
	CLLocationCoordinate2D coordinate;
	coordinate.longitude = [[self valueForKey:@"longitude"] floatValue];
	coordinate.latitude = [[self valueForKey:@"latitude"] floatValue];
	return coordinate;
}

- (NSString *)title
{
	return [NSString stringWithFormat:@"%04ld",
		[[self valueForKey:@"postcode"] integerValue]];
}

- (NSString *)subtitle
{
	return [NSString stringWithFormat:@"%@, %@",
		[[self valueForKey:@"suburb"] capitalizedString],
		[self valueForKey:@"state"]];
}

@end
