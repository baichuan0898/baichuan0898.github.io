//
//  RootViewController.m
//  AustralianPostcodes
//
//  Created by Matt Gallagher on 2009/12/05.
//  Copyright Matt Gallagher 2009. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "RootViewController.h"

@implementation RootViewController

#pragma mark -
#pragma mark Table view methods

//
// viewDidLoad
//
// Load the data for the view when the view is loaded.
//
- (void)viewDidLoad
{
	[super viewDidLoad];

	rowData =
		[[NSArray alloc] initWithContentsOfFile:
			[[NSBundle mainBundle]
				pathForResource:@"RootViewStructure"
				ofType:@"plist"]];
}

//
// viewDidUnload
//
// Load the data for the view when the view is loaded.
//
- (void)viewDidUnload
{
	[super viewDidUnload];

	[rowData release];
	rowData = nil;
}

//
// numberOfSectionsInTableView:
//
// Parameters:
//    tableView - should be the table we control
//
// returns 1 (we have only one section)
//
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

//
// tableView:numberOfRowsInSection:
//
// Parameters:
//    tableView - should be the table we control
//    section - a section in the table
//
// returns the number of rows in the section as specified by loaded plist
//
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return [rowData count];
}

//
// tableView:cellForRowAtIndexPath:
//
// Constructs/configures the view for a given row of data
//
// Parameters:
//    tableView - should be the table we control
//    indexPath - the indexPath of the row whose view we will construct/configure
//
// returns the constructed/configured row
//
- (UITableViewCell *)tableView:(UITableView *)tableView
	cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	static NSString *CellIdentifier = @"Cell";
	
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
	}
	
	// Configure the cell.
	cell.textLabel.text =
		[[rowData objectAtIndex:indexPath.row] objectForKey:@"label"];
	
	return cell;
}

//
// tableView:didSelectRowAtIndexPath:
//
// When a row in the postcodes view is selected, bring up the Map View for
// the selected postcode.
//
// Parameters:
//    tableView - should be the table view we control
//    indexPath - the index path of the selected row
//
- (void)tableView:(UITableView *)tableView
	didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	NSDictionary *row = [rowData objectAtIndex:indexPath.row];
	Class viewControllerClass =
		NSClassFromString([row objectForKey:@"viewControllerClassName"]);
	SEL initSelector =
		NSSelectorFromString([row objectForKey:@"initMethodSelector"]);
	id parameter = [row objectForKey:@"initParameter"];
	
	UIViewController *viewController =
		[[[viewControllerClass alloc]
			performSelector:initSelector withObject:parameter]
		autorelease];
	[self.navigationController pushViewController:viewController animated:YES];
}

#pragma mark -
#pragma mark Memory management

//
// dealloc
//
// Release instance memory
//
- (void)dealloc
{
	[rowData release];
	[super dealloc];
}

@end

