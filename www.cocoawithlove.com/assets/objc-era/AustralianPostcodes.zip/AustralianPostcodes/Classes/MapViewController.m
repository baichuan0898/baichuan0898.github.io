//
//  MapViewController.m
//  AustralianPostcodes
//
//  Created by Matt Gallagher on 2009/12/07.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "MapViewController.h"
#import "PostcodesController.h"
#import "Postcode.h"

const double MapViewAperture = 0.03;
const double HalfSearchAperture = 0.1;
const double AnnotationDelay = 2.0;

@implementation MapViewController

//
// initWithPostcode:
//
// Configures the map to display the given postcode (or, if postcode is nil,
// to get data from the current GPS locaiton).
//
// Parameters:
//    aPostcode - the postcode object to display (or nil for GPS location)
//
// returns the configured object
//
- (id)initWithPostcode:(Postcode *)aPostcode
{
	if (self = [super initWithNibName:@"MapView" bundle:nil])
	{
		postcode = [aPostcode retain];
	}
	return self;
}

//
// title
//
// returns the text to show in the navigation bar
//
- (NSString *)title
{
	if (postcode)
	{
		return [postcode title];
	}
	
	return NSLocalizedString(@"GPS Location", nil);
}

//
// postcodesNearCoordinate:
//
// Fetchs the array of nearby postcode locations
//
// Parameters:
//    coordinate - the coordinate near which to search
//
// returns the array
//
- (NSArray *)postcodesNearCoordinate:(CLLocationCoordinate2D)coordinate
{
	NSManagedObjectContext *context =
		[PostcodesController sharedPostcodesController].managedObjectContext;
	NSFetchRequest *request = 
		[[[NSFetchRequest alloc] init] autorelease];
	[request setEntity:
		[NSEntityDescription
			entityForName:@"Postcode"
			inManagedObjectContext:context]];
			
	//
	// Restrict results to those that are within 0.25 latitude and longitude.
	//
	[request setPredicate:[NSPredicate predicateWithFormat:
		@"latitude BETWEEN {%@, %@} AND longitude BETWEEN {%@, %@}",
			[NSNumber numberWithFloat:coordinate.latitude - HalfSearchAperture],
			[NSNumber numberWithFloat:coordinate.latitude + HalfSearchAperture],
			[NSNumber numberWithFloat:coordinate.longitude - HalfSearchAperture],
			[NSNumber numberWithFloat:coordinate.longitude + HalfSearchAperture]]];

	NSError *error = nil;
	NSArray *results = [context executeFetchRequest:request error:&error];
	if (error)
	{
		NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
		abort();
	}
	
	return results;
}

//
// updateToPostcode:
//
// Sets the labels to reflect the current postcode
//
// Parameters:
//    aPostcode - the current postcode
//
- (void)updateToPostcode:(Postcode *)aPostcode
{
	if (aPostcode)
	{
		[mapView setRegion:
			MKCoordinateRegionMake(aPostcode.coordinate,
				MKCoordinateSpanMake(MapViewAperture, MapViewAperture))];
		
		postcodeView.text = [aPostcode title];
		suburbView.text = [aPostcode subtitle];
		stateView.text = [aPostcode valueForKey:@"state"];
		postOfficeView.text = [[aPostcode valueForKey:@"postOffice"] capitalizedString];
	}
	else
	{
		postcodeView.text = NSLocalizedString(@"Outside AU postcode area.", nil);
		suburbView.text = NSLocalizedString(@"Outside AU postcode area.", nil);
		stateView.text = NSLocalizedString(@"Outside AU postcode area.", nil);
		postOfficeView.text = NSLocalizedString(@"Outside AU postcode area.", nil);
	}
}

- (void)selectAnnotation:(Postcode *)aPostcode
{
	[mapView selectAnnotation:aPostcode animated:YES];
}

//
// viewDidLoad
//
// Implement viewDidLoad to do additional setup after loading the view.
//
- (void)viewDidLoad
{
	[super viewDidLoad];
	
	if (postcode)
	{
		[self updateToPostcode:postcode];

		[mapView removeAnnotations:mapView.annotations];
		[mapView addAnnotations:[self postcodesNearCoordinate:postcode.coordinate]];
		[self
			performSelector:@selector(selectAnnotation:)
			withObject:postcode
			afterDelay:AnnotationDelay];
	}
	else
	{
		locationManager = [[CLLocationManager alloc] init];
		locationManager.delegate = self;
		locationManager.desiredAccuracy = kCLLocationAccuracyKilometer;
		[locationManager startUpdatingLocation];
		
		postcodeView.text = NSLocalizedString(@"Waiting for GPS data...", nil);
		suburbView.text = NSLocalizedString(@"Waiting for GPS data...", nil);
		stateView.text = NSLocalizedString(@"Waiting for GPS data...", nil);
		postOfficeView.text = NSLocalizedString(@"Waiting for GPS data...", nil);
	}
}

//
// viewDidUnload
//
// Unloads elements loaded by the view.
//
- (void)viewDidUnload
{
	[super viewDidUnload];
}

//
// shouldAutorotateToInterfaceOrientation:
//
// Change the rotation of the view.
//
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

//
// locationManager:didUpdateToLocation:fromLocation:
//
// Responds to a location update from the GPS by looking for the nearest postcode
// and centering on that.
//
// Parameters:
//    manager - the location manager
//    newLocation - the new location
//    oldLocation - the old location
//
- (void)locationManager:(CLLocationManager *)manager
	didUpdateToLocation:(CLLocation *)newLocation
		   fromLocation:(CLLocation *)oldLocation
{
	NSArray *results = [self postcodesNearCoordinate:newLocation.coordinate];
	if ([results count] == 0)
	{
		[self updateToPostcode:nil];

		[mapView setRegion:
			MKCoordinateRegionMake(newLocation.coordinate,
				MKCoordinateSpanMake(MapViewAperture, MapViewAperture))];
		return;
	}
	
	//
	// Now sort the results we received to find the closest
	//
	NSInteger closestIndex = 0;
	NSInteger currentIndex = 0;
	double closestDistanceSquared = CGFLOAT_MAX;
	for (Postcode *current in results)
	{
		double longitude = [[current valueForKey:@"longitude"] doubleValue];
		double latitude = [[current valueForKey:@"latitude"] doubleValue];
		double delatLongitude = longitude - newLocation.coordinate.longitude;
		double delatLatitude = latitude - newLocation.coordinate.latitude;
		
		double distanceSquared =
			delatLongitude * delatLongitude + delatLatitude * delatLatitude;
		if (distanceSquared < closestDistanceSquared)
		{
			closestDistanceSquared = distanceSquared;
			closestIndex = currentIndex;
		}
		currentIndex++;
	}
	
	[self updateToPostcode:[results objectAtIndex:closestIndex]];
	[mapView removeAnnotations:mapView.annotations];
	[mapView addAnnotations:results];
	[self
		performSelector:@selector(selectAnnotation:)
		withObject:[results objectAtIndex:closestIndex]
		afterDelay:AnnotationDelay];

	[locationManager stopUpdatingLocation];
}

//
// dealloc
//
// Release instance memory.
//
- (void)dealloc
{
	[locationManager release];
	[postcode release];
	[super dealloc];
}

@end
