//
//  DateController.m
//  WorldTimeConverter
//
//  Created by Matt Gallagher on 10/10/08.
//  Copyright 2008 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file without charge in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "DateController.h"

@implementation DateController

@synthesize timezones;
@synthesize date;
@synthesize destinationDate;
@synthesize sourceTimezoneIndex;
@synthesize destinationTimezoneIndex;

//
// initialize
//
// Setup the dependent keys (destinationDate is dependent on everything).
//
+ (void)initialize
{
	[self
		setKeys:
			[NSArray arrayWithObjects:
				@"sourceTimezoneIndex",
				@"destinationTimezoneIndex",
				@"date",
				nil]
		triggerChangeNotificationsForDependentKey:@"destinationDate"];
}

//
// init
//
// Init method for the object.
//
- (id)init
{
	self = [super init];
	if (self != nil)
	{
		NSArray *timezoneNames = [NSTimeZone knownTimeZoneNames];
		timezones = [[NSMutableArray arrayWithCapacity:[timezoneNames count]] retain];
		for (NSString *name in
			[timezoneNames sortedArrayUsingSelector:@selector(compare:)])
		{
			[(NSMutableArray *)timezones addObject:[NSTimeZone timeZoneWithName:name]];
		}
		if ([timezones indexOfObject:[NSTimeZone localTimeZone]] == NSNotFound)
		{
			[(NSMutableArray *)timezones insertObject:[NSTimeZone localTimeZone] atIndex:0];
		}
		
		date = [[NSDate date] retain];
	}
	return self;
}

//
// awakeFromNib
//
// It's nice to have the selected rows visible on startup.
//
- (void)awakeFromNib
{
	[self resetSourceTimezone:self];
	[self resetDestinationTimezone:self];

	[sourceTable scrollRowToVisible:[[self sourceTimezoneIndex] firstIndex]];
	[destinationTable scrollRowToVisible:[[self destinationTimezoneIndex] firstIndex]];
}

//
// indexPathForLocalTimeZone
//
// Convenience method for creating an index path into the timezones array for
// the current timezone.
//
- (NSIndexSet *)indexPathForLocalTimeZone
{
	return [NSIndexSet indexSetWithIndex:
		[timezones indexOfObject:[NSTimeZone localTimeZone]]];
}

//
// destinationDate
//
// Returns a date obtained by adding the interval between time zones to the
// source date. This interval may be negative.
//
- (NSDate *)destinationDate
{
	if (sourceTimezoneIndex == nil || [sourceTimezoneIndex firstIndex] == NSNotFound ||
		destinationTimezoneIndex == nil || [destinationTimezoneIndex firstIndex] == NSNotFound)
	{
		return [NSDate date];
	}
	
	NSTimeZone *sourceTimeZone =
		[timezones objectAtIndex:[sourceTimezoneIndex firstIndex]];
	NSTimeZone *destinationTimeZone =
		[timezones objectAtIndex:[destinationTimezoneIndex firstIndex]];
	NSInteger sourceSeconds =
		[sourceTimeZone secondsFromGMTForDate:date];
	NSInteger destinationSeconds =
		[destinationTimeZone secondsFromGMTForDate:date];

	NSTimeInterval interval = destinationSeconds - sourceSeconds;
	return
		[[[NSDate alloc]
			initWithTimeInterval:interval sinceDate:date]
		autorelease];
}

//
// resetSourceTime
//
// Sets the source date to the current time.
//
- (IBAction)resetSourceTime:(id)sender
{
	[self willChangeValueForKey:@"date"];
	[date release];
	date = [[NSDate date] retain];
	[self didChangeValueForKey:@"date"];
}

//
// resetSourceTimezone
//
// Sets the source timezone to the current timezone.
//
- (IBAction)resetSourceTimezone:(id)sender
{
	self.sourceTimezoneIndex = [self indexPathForLocalTimeZone];
	[sourceTable scrollRowToVisible:[sourceTimezoneIndex firstIndex]];
}

//
// resetDestinationTimezone
//
// Sets the destination timezone to the current timezone.
//
- (IBAction)resetDestinationTimezone:(id)sender
{
	self.destinationTimezoneIndex = [self indexPathForLocalTimeZone];
	[destinationTable scrollRowToVisible:[destinationTimezoneIndex firstIndex]];
}

//
// dealloc
//
// Releases instance memory.
//
- (void)dealloc
{
	[timezones release];
	[sourceTimezoneIndex release];
	[destinationTimezoneIndex release];
	[date release];
	[super dealloc];
}


@end
