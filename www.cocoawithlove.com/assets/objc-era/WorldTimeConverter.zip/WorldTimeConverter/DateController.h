//
//  DateController.h
//  WorldTimeConverter
//
//  Created by Matt Gallagher on 10/10/08.
//  Copyright 2008 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file without charge in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import <Cocoa/Cocoa.h>


@interface DateController : NSObject
{
	NSDate *date;
	NSArray *timezones;
	IBOutlet NSTableView *sourceTable;
	IBOutlet NSTableView *destinationTable;
	NSIndexSet *sourceTimezoneIndex;
	NSIndexSet *destinationTimezoneIndex;
}

@property (nonatomic, retain) NSDate *date;
@property (nonatomic, retain) NSArray *timezones;
@property (nonatomic, readonly) NSDate *destinationDate;
@property (nonatomic, retain) NSIndexSet *sourceTimezoneIndex;
@property (nonatomic, retain) NSIndexSet *destinationTimezoneIndex;

- (IBAction)resetSourceTime:(id)sender;
- (IBAction)resetSourceTimezone:(id)sender;
- (IBAction)resetDestinationTimezone:(id)sender;
- (NSIndexSet *)indexPathForLocalTimeZone;

@end
