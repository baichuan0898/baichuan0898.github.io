//
//  TextMaskingAppDelegate.m
//  TextMasking
//
//  Created by Matt Gallagher on 2009/09/09.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "TextMaskingAppDelegate.h"
#import "MaskedTextView.h"

@implementation TextMaskingAppDelegate

@synthesize window;

- (void)fire:(NSTimer *)aTimer
{
	NSDateFormatter *dateFormatter = [[[NSDateFormatter alloc] init] autorelease];
	[dateFormatter setDateStyle:NSDateFormatterNoStyle];
	[dateFormatter setTimeStyle:NSDateFormatterMediumStyle];

	((MaskedTextView *)[[self window] contentView]).text = [dateFormatter stringFromDate:[NSDate date]];

}

- (void)clearTimer
{
	[tickTimer invalidate];
	tickTimer = nil;
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application
	[self fire:nil];
	tickTimer =
		[NSTimer
			scheduledTimerWithTimeInterval:1.0
			target:self
			selector:@selector(fire:)
			userInfo:nil
			repeats:YES];
}

- (void)dealloc
{
	[self clearTimer];
	[super dealloc];
}

@end
