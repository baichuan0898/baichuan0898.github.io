//
//  MaskedTextView.m
//  TextMasking
//
//  Created by Matt Gallagher on 2009/09/09.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "MaskedTextView.h"


@implementation MaskedTextView

@synthesize text;

- (void)setText:(NSString *)newText
{
	if (newText != text)
	{
		[text release];
		text = [newText retain];
		[self setNeedsDisplay:YES];
	}
}

- (void)drawRect:(NSRect)rect
{
	// Create a grayscale context for the mask
	CGColorSpaceRef colorspace = CGColorSpaceCreateDeviceGray();
	CGContextRef maskContext =
	CGBitmapContextCreate(
		NULL,
		self.bounds.size.width,
		self.bounds.size.height,
		8,
		self.bounds.size.width,
		colorspace,
		0);
	CGColorSpaceRelease(colorspace);
	
	// Switch to the context for drawing
	NSGraphicsContext *maskGraphicsContext =
		[NSGraphicsContext
			graphicsContextWithGraphicsPort:maskContext
			flipped:NO];
	[NSGraphicsContext saveGraphicsState];
	[NSGraphicsContext setCurrentContext:maskGraphicsContext];
	
	// Draw a black background
	[[NSColor darkGrayColor] setFill];
	CGContextFillRect(maskContext, rect);

	// Draw the text right-way-up (non-flipped context)
	[text
		drawInRect:rect
		withAttributes:
			[NSDictionary dictionaryWithObjectsAndKeys:
				[NSFont fontWithName:@"HelveticaNeue-Bold" size:124], NSFontAttributeName,
				[NSColor whiteColor], NSForegroundColorAttributeName,
			nil]];

    // Switch back to the window's context
	[NSGraphicsContext restoreGraphicsState];

	// Create an image mask from what we've drawn so far
	CGImageRef alphaMask = CGBitmapContextCreateImage(maskContext);

	// Draw a white background in the window
	CGContextRef windowContext = [[NSGraphicsContext currentContext] graphicsPort];
	[[NSColor whiteColor] setFill];
	CGContextFillRect(windowContext, rect);

    // Draw the image, clipped by the mask
	CGContextSaveGState(windowContext);
	CGContextClipToMask(windowContext, NSRectToCGRect(self.bounds), alphaMask);
	[[NSImage imageNamed:@"shuttle"] drawInRect:rect fromRect:NSZeroRect
		operation:NSCompositeCopy fraction:1.0];
	CGContextRestoreGState(windowContext);
	CGImageRelease(alphaMask);
}

@end

