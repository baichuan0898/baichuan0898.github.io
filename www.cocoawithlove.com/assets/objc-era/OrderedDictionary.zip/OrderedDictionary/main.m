#import <Foundation/Foundation.h>
#import "OrderedDictionary.h"

int main (int argc, const char * argv[])
{
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];

	OrderedDictionary *dictionary =
		[OrderedDictionary dictionaryWithObjectsAndKeys:
			@"firstObject", @"firstKey",
			@"secondObject", @"secondKey",
			@"thirdObject", @"thirdKey",
			@"fourthObject", @"fourthKey",
			nil];
    
	NSLog(@"Contents of the dictionary: %@", dictionary);
	
	[dictionary insertObject:@"onePointFive" forKey:@"firstAndABitKey" atIndex:1];
	
	NSLog(@"New contents of the dictionary: %@", dictionary);
	
	dictionary = [[OrderedDictionary alloc] init];
	[dictionary setObject:@"one" forKey:@"two"];
	NSLog(@"FInal contents of the dictionary: %@", dictionary);
	
	
	dictionary = [dictionary copy];
	[dictionary setObject:@"one" forKey:@"two"];
	NSLog(@"FInal contents of the dictionary: %@", dictionary);
    [pool drain];

    return 0;
}
