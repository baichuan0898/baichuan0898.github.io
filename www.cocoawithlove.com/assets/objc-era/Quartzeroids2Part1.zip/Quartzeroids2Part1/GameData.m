//
//  GameData.m
//  Quartzeroids2
//
//  Created by Matt Gallagher on 15/02/09.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file without charge in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "GameData.h"
#import "SynthesizeSingleton.h"

const double GAME_ASPECT = 16.0 / 10.0;

@implementation GameData

SYNTHESIZE_SINGLETON_FOR_CLASS(GameData);

//
// gameWidth
//
// Returns the width for the game area. Defaults to screen width.
//
- (double)gameWidth
{
	static double gameWidth = 0;
	
	if (gameWidth == 0)
	{
		NSSize screenSize = [[NSScreen mainScreen] frame].size;
		if ((screenSize.width / screenSize.height) > GAME_ASPECT)
		{
			screenSize.width = screenSize.height * GAME_ASPECT;
		}
		gameWidth = screenSize.width;
	}

	return gameWidth;
}

//
// gameHeight
//
// Returns the height for the game area. Defaults to screen height.
//
- (double)gameHeight
{
	static double gameHeight = 0;
	
	if (gameHeight == 0)
	{
		NSSize screenSize = [[NSScreen mainScreen] frame].size;
		if ((screenSize.width / screenSize.height) < GAME_ASPECT)
		{
			screenSize.height = screenSize.width / GAME_ASPECT;
		}
		gameHeight = screenSize.height;
	}

	return gameHeight;
}

@end
