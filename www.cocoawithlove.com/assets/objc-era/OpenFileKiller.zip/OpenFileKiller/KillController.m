//
//  KillController.m
//  OpenFileKiller
//
//  Created by Matt Gallagher on 4/05/09.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "KillController.h"
#import "NSTask+OneLineTasksWithOutput.h"
#import "NSString+SeparatingIntoLines.h"

@implementation KillController

//
// updateProcesses:
//
// Runs "lsof" to get the processes that have the current file path open.
// The result is parsed and the process names and process IDs are stored in the
// "processes" array.
//
// Parameters:
//    sender - the text field or nil
//
- (IBAction)updateProcesses:(id)sender
{
	NSError *error;
	NSString *outputString =
		[NSTask
			stringByLaunchingPath:@"/usr/sbin/lsof"
			withArguments:
				[NSArray arrayWithObjects:
					@"-F",
					@"pc",
					[textField stringValue],
				nil]
			error:&error];
	if (error)
	{
		NSLog(@"An error occurred launching process:\n%@", [error localizedDescription]);
		[self willChangeValueForKey:@"processes"];
		[processes autorelease];
		processes = [[NSArray alloc] init];
		[self didChangeValueForKey:@"processes"];
		return;
	}

	NSArray *lines = [outputString arrayBySeparatingIntoParagraphs];
	if ([lines count] > 1)
	{
		[self willChangeValueForKey:@"processes"];
		[processes autorelease];
		processes = [[NSMutableArray alloc] init];
		
		NSInteger lineIndex = 0;
		NSInteger lineCount = [lines count];
		while (lineIndex < lineCount - 1)
		{
			NSString *line1 = [lines objectAtIndex:lineIndex++];
			NSString *line2 = [lines objectAtIndex:lineIndex++];
			
			if ([line1 length] == 0 || [line2 length] == 0)
			{
				continue;
			}
			
			NSString *processID;
			NSString *processName;
			if ([line1 hasPrefix:@"p"])
			{
				processID = [line1 substringFromIndex:1];
				processName = [line2 substringFromIndex:1];
			}
			else
			{
				processID = [line2 substringFromIndex:1];
				processName = [line1 substringFromIndex:1];
			}
			
			[(NSMutableArray *)processes addObject:
				[NSDictionary dictionaryWithObjectsAndKeys:
					processName, @"processName",
					processID, @"processID",
				nil]];
		}
		[self didChangeValueForKey:@"processes"];
	}
	else
	{
		[self willChangeValueForKey:@"processes"];
		[processes autorelease];
		processes = [[NSArray alloc] init];
		[self didChangeValueForKey:@"processes"];
	}
}

//
// killProcess:
//
// Invoked when the "Kill Process" button is clicked. Requests elevated
// privileges and kills the selected process ID.
//
// Parameters:
//    sender - the button.
//
- (IBAction)killProcess:(id)sender
{
	NSDictionary *processInfo = [[processesController selectedObjects] objectAtIndex:0];
	NSString *processID = [processInfo objectForKey:@"processID"];

	NSError *error;

	if (!authorization)
	{
		authorization = [SFAuthorization authorization];
		BOOL result =
			[authorization
				obtainWithRights:NULL
				flags:kAuthorizationFlagExtendRights
				environment:NULL
				authorizedRights:NULL
				error:&error];
		if (!result)
		{
			NSLog(@"SFAuthorization error: %@", [error localizedDescription]); 
			authorization = nil;
			return;
		}
		[authorization retain];
	}

	NSString *output =
		[NSTask
			stringByLaunchingPath:@"/bin/sh"
			withArguments:
				[NSArray arrayWithObjects:
					@"-c",
					[NSString stringWithFormat:@"kill -9 %@", processID],
				nil]
			authorization:authorization
			error:&error];
	if (!output)
	{
		NSLog(@"Error from AuthorizationExecuteWithPrivileges: %ld",
			[error code]); 
		return;
	}

	NSLog(@"Output %@", output);
	[self updateProcesses:nil];
}

//
// chooseFile:
//
// When the "Choose File:" button is clicked, displays an open dialog allowing
// a file to be selected. Selected file's path is set in the text field and
// the process list is updated.
//
// Parameters:
//    sender - the button.
//
- (IBAction)chooseFile:(id)sender
{
    NSOpenPanel *openPanel = [NSOpenPanel openPanel];
    NSInteger result = [openPanel runModal];
    if (result == NSOKButton)
	{
        NSString *filename = [[openPanel filenames] objectAtIndex:0];
		[textField setStringValue:filename];
    }
	
	[self updateProcesses:nil];
}

//
// application:openFiles:
//
// When a file is opened, set the path and update the processes.
//
// Parameters:
//    sender - the NSApplication object
//    filenames - the array of file paths
//
- (void)application:(NSApplication *)sender openFiles:(NSArray *)filenames
{
	if ([filenames count] > 0)
	{
		[textField setStringValue:[filenames objectAtIndex:0]];
		[self updateProcesses:nil];
	}
}

//
// receiveFilePath:
//
// When a file is dragged, set the path and update the processes.
//
// Parameters:
//    aFilePath - the path of the file
//
- (void)receiveFilePath:(NSString *)aFilePath
{
	[textField setStringValue:aFilePath];
	[self updateProcesses:nil];
}

//
// dealloc
//
// Releases instance memory.
//
- (void)dealloc
{
	[authorization release];
	[super dealloc];
}


@end
