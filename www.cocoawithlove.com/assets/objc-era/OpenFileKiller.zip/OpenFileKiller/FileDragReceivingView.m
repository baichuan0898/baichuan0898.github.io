//
//  FileDragReceivingView.m
//  OpenFileKiller
//
//  Created by Matt Gallagher on 4/05/09.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "FileDragReceivingView.h"

@implementation FileDragReceivingView

- (void)awakeFromNib
{
	[self setFocusRingType:NSFocusRingTypeNone];
	[self registerForDraggedTypes:[NSArray arrayWithObject:NSFilenamesPboardType]];
}

- (NSDragOperation)draggingEntered:(id < NSDraggingInfo >)sender
{
	[self setFocusRingType:NSFocusRingTypeDefault];
	[self setNeedsDisplay:YES];
	return NSDragOperationGeneric;
}

- (void)draggingExited:(id < NSDraggingInfo >)sender
{
	[self setFocusRingType:NSFocusRingTypeNone];
	[self setNeedsDisplay:YES];
}

- (BOOL)performDragOperation:(id < NSDraggingInfo >)sender
{
	[self setFocusRingType:NSFocusRingTypeNone];
	[self setNeedsDisplay:YES];
	
    NSPasteboard *pboard = [sender draggingPasteboard];
    if ([[pboard types] containsObject:NSFilenamesPboardType])
	{
        NSArray *files = [pboard propertyListForType:NSFilenamesPboardType];
		if ([files count] > 0)
		{
			if ([receiver respondsToSelector:@selector(receiveFilePath:)])
			{
				[receiver receiveFilePath:[files objectAtIndex:0]];
			}
		}
    }
    return YES;
}

- (void)drawRect:(NSRect)rect
{
	if ([self focusRingType] != NSFocusRingTypeNone)
	{
		[NSGraphicsContext saveGraphicsState];
		[[NSColor clearColor] set];
		NSSetFocusRingStyle(NSFocusRingAbove);
		[[NSBezierPath bezierPathWithRect:NSInsetRect([self bounds], 2, 2)] fill];
		[NSGraphicsContext restoreGraphicsState];
	}
	else
	{
		[[NSColor clearColor] set];
		[[NSBezierPath bezierPathWithRect:[self bounds]] fill];
	}
}

@end
