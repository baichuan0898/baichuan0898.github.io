//
//  StickyWindowController.m
//  StickiesClient
//
//  Created by Matt Gallagher on 4/01/09.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file without charge in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "StickyWindowController.h"
#import "StickiesAppDelegate.h"

NSString *windowFrameKey = @"windowFrameAsString";

@implementation StickyWindowController

//
// init
//
// Init method for the object.
//
- (id)initWithSticky:(NSManagedObject *)newSticky
{
	self = [super initWithWindowNibName:@"Sticky"];
	if (self != nil)
	{
		sticky = [newSticky retain];
		[sticky addObserver:self forKeyPath:windowFrameKey options:NSKeyValueObservingOptionNew context:nil];
		[[self window] makeKeyAndOrderFront:self];
	}
	return self;
}

//
// dealloc
//
// Releases instance memory.
//
- (void)dealloc
{
	[sticky release];
	[super dealloc];
}

- (void)close
{
    [sticky removeObserver:self forKeyPath:windowFrameKey];
	[super close];
}

- (BOOL)shouldCascadeWindows
{
	return NO;
}

- (void)windowDidLoad
{
	NSString *frameString = [sticky valueForKey:windowFrameKey];
	if (frameString == nil)
	{
		[sticky setValue:NSStringFromRect([[self window] frame]) forKey:windowFrameKey];
	}
	else
	{
		[[self window] setFrame:NSRectFromString(frameString) display:NO];
	}
}

- (NSManagedObject *)sticky
{
	return sticky;
}

// Destroy the sticky
- (BOOL)windowShouldClose:(id)sender
{
	[[NSApp delegate] removeSticky:sticky];
	return YES;
}

- (void)rememberWindowFrame
{
	[sticky setValue:NSStringFromRect([[self window] frame]) forKey:windowFrameKey];
}

- (void)windowDidMove:(NSNotification *)aNotification
{
    [self rememberWindowFrame];
}

- (void)windowDidResize:(NSNotification *)aNotification 
{
    [self rememberWindowFrame];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context 
{
    // If the value of a sticky's frame changes in the managed object, we update the window to match
    if ([keyPath isEqual:windowFrameKey]) {
        NSRect newFrame = NSRectFromString([change objectForKey:NSKeyValueChangeNewKey]);
        // Don't setFrame if the frame hasn't changed; this prevents infinite recursion
        if (! NSEqualRects([[self window] frame], newFrame)) {
            [[self window] setFrame:newFrame display:YES];
        }
    }
}

@end
