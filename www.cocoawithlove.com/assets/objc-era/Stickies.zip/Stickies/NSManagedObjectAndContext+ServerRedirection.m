//
//  NSManagedObjectAndContext+ServerRedirection.m
//  ClientServerStickies
//
//  Created by Matt Gallagher on 5/01/09.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file without charge in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "NSManagedObjectAndContext+ServerRedirection.h"

#ifdef STICKIES_SERVER

@implementation NSManagedObjectContext (ServerRedirection)

- (id)remotelyAllocateWithEntity:(NSEntityDescription *)entity
{
	NSEntityDescription *localEntity = [entity valueForKey:@"self"];
	return [[NSManagedObject alloc] initWithEntity:localEntity insertIntoManagedObjectContext:self];
}

- (void)forwardContextChangeNotificationsTo:(id)receiver
{
	[[NSNotificationCenter defaultCenter]
		addObserver:receiver
		selector:@selector(forwardNotification:)
		name:@"_NSObjectsChangedInManagingContextPrivateNotification"
		object:self];
}

@end

#else

@implementation NSManagedObject (ServerRedirection)

- (id)initWithEntity:(NSEntityDescription *)entity insertIntoManagedObjectContext:(NSManagedObjectContext *)context
{
	return [context remotelyAllocateWithEntity:entity];
}

@end

#endif
