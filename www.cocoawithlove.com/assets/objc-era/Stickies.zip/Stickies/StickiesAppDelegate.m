/*

File: StickiesAppDelegate.m

Abstract: The Stickies application delegate

Disclaimer: IMPORTANT:  This Apple software is supplied to you by Apple
Computer, Inc. ("Apple") in consideration of your agreement to the
following terms, and your use, installation, modification or
redistribution of this Apple software constitutes acceptance of these
terms.  If you do not agree with these terms, please do not use,
install, modify or redistribute this Apple software.

In consideration of your agreement to abide by the following terms, and
subject to these terms, Apple grants you a personal, non-exclusive
license, under Apple's copyrights in this original Apple software (the
"Apple Software"), to use, reproduce, modify and redistribute the Apple
Software, with or without modifications, in source and/or binary forms;
provided that if you redistribute the Apple Software in its entirety and
without modifications, you must retain this notice and the following
text and disclaimers in all such redistributions of the Apple Software. 
Neither the name, trademarks, service marks or logos of Apple Computer,
Inc. may be used to endorse or promote products derived from the Apple
Software without specific prior written permission from Apple.  Except
as expressly stated in this notice, no other rights or licenses, express
or implied, are granted by Apple herein, including but not limited to
any patent rights that may be infringed by your derivative works or by
other works in which the Apple Software may be incorporated.

The Apple Software is provided by Apple on an "AS IS" basis.  APPLE
MAKES NO WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION
THE IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE, REGARDING THE APPLE SOFTWARE OR ITS USE AND
OPERATION ALONE OR IN COMBINATION WITH YOUR PRODUCTS.

IN NO EVENT SHALL APPLE BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL
OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION,
MODIFICATION AND/OR DISTRIBUTION OF THE APPLE SOFTWARE, HOWEVER CAUSED
AND WHETHER UNDER THEORY OF CONTRACT, TORT (INCLUDING NEGLIGENCE),
STRICT LIABILITY OR OTHERWISE, EVEN IF APPLE HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.

Copyright © 2005 Apple Computer, Inc., All Rights Reserved

*/

#import "StickiesAppDelegate.h"
#import "StickyWindowController.h"
#import "NSManagedObjectAndContext+ServerRedirection.h"

#define STICKIES_SERVER_PORT 61404	// Something arbitrary

static NSNib *stickyNib;

@implementation StickiesAppDelegate

+ (void)initialize 
{ 
    stickyNib = [[NSNib alloc] initWithNibNamed:@"Sticky" bundle:nil];
}

- (BOOL)connection:(NSConnection *)conn handleRequest:(NSDistantObjectRequest *)doReq
{
	NSInvocation *invocation = [doReq invocation];

	// Invoke the message as requested
	[invocation invoke];

	// Replace the output of entitiesByName with something that encodes better
	if ([invocation selector] == @selector(entitiesByName))
	{
		id retVal;
		[invocation getReturnValue:&retVal];
		
		NSDictionary *rebuilt = [NSDictionary dictionaryWithDictionary:retVal];
		[invocation setReturnValue:&rebuilt];
	}

	[doReq replyWithException:nil];

	return YES;
}

- (void)applicationDidFinishLaunching:(NSNotification *)notification 
{
	stickyWindowControllers = [[NSMutableArray alloc] init];
	[stickiesController addObserver:self forKeyPath:@"arrangedObjects" options:NSKeyValueObservingOptionNew context:nil];
}

- (void)syncWithStickiesController 
{
	NSSet *newArrangedObjects = [NSSet setWithArray:[stickiesController arrangedObjects]];
	NSSet *oldArrangedObjects = [NSSet setWithArray:[stickyWindowControllers valueForKey:@"sticky"]];

	NSMutableSet *createdObjects = [NSMutableSet setWithSet:newArrangedObjects];
	[createdObjects minusSet:oldArrangedObjects];
	
	for (NSManagedObject *sticky in createdObjects)
	{
		[stickyWindowControllers addObject:[[[StickyWindowController alloc] initWithSticky:sticky] autorelease]];
	}
	for (StickyWindowController *stickyWindowController in [NSArray arrayWithArray:stickyWindowControllers])
	{
		if ([oldArrangedObjects containsObject:[stickyWindowController sticky]] &&
			![newArrangedObjects containsObject:[stickyWindowController sticky]])
		{
			[stickyWindowController close];
			[stickyWindowControllers removeObject:stickyWindowController];
		}
	}
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context 
{
    if ([keyPath isEqualTo:@"arrangedObjects"])
	{
		[self syncWithStickiesController];
	}
}

- (void)removeSticky:(id)aSticky 
{
    [stickiesController removeObject:aSticky];
}

//
// ----------------All the code below this line is part of the Xcode template for a non-document CoreData app. ----------------------
// 

- (NSManagedObjectModel *)managedObjectModel {
    if (managedObjectModel) return managedObjectModel;
	
	NSMutableSet *allBundles = [[NSMutableSet alloc] init];
	[allBundles addObject: [NSBundle mainBundle]];
	[allBundles addObjectsFromArray: [NSBundle allFrameworks]];
    
    managedObjectModel = [[NSManagedObjectModel mergedModelFromBundles: [allBundles allObjects]] retain];
    [allBundles release];
    
    return managedObjectModel;
}

- (NSString *)applicationSupportFolder {

    NSString *applicationSupportFolder = nil;
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSUserDomainMask, YES);
    if ( [paths count] == 0 ) {
        NSRunAlertPanel(@"Alert", @"Can't find application support folder", @"Quit", nil, nil);
        [[NSApplication sharedApplication] terminate:self];
    } else {
        applicationSupportFolder = [[paths objectAtIndex:0] stringByAppendingPathComponent:@"ClientServer Stickies"];
    }
    return applicationSupportFolder;
}

- (NSManagedObjectContext *) managedObjectContext {
	if (managedObjectContext) {
		return managedObjectContext;
	}

#ifdef STICKIES_SERVER
    NSError *error;
    NSString *applicationSupportFolder = nil;
    NSURL *url;
    NSFileManager *fileManager;
    NSPersistentStoreCoordinator *coordinator;
    
    fileManager = [NSFileManager defaultManager];
    applicationSupportFolder = [self applicationSupportFolder];
    if ( ![fileManager fileExistsAtPath:applicationSupportFolder isDirectory:NULL] ) {
        [fileManager createDirectoryAtPath:applicationSupportFolder attributes:nil];
    }
    
    url = [NSURL fileURLWithPath: [applicationSupportFolder stringByAppendingPathComponent: @"Stickies.xml"]];
    coordinator = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel: [self managedObjectModel]];
    if ([coordinator addPersistentStoreWithType:NSXMLStoreType configuration:nil URL:url options:nil error:&error]){
        managedObjectContext = [[NSManagedObjectContext alloc] init];
        [managedObjectContext setPersistentStoreCoordinator: coordinator];
    } else {
        [[NSApplication sharedApplication] presentError:error];
    }    
    [coordinator release];
    
	//
	// Create a port
	//
	NSSocketPort *port = [[[NSSocketPort alloc] initWithTCPPort:STICKIES_SERVER_PORT] autorelease];

	//
	// Create a connection on the port
	//
	NSConnection *theConnection = [[NSConnection connectionWithReceivePort:port
		sendPort:nil] retain];
	[theConnection setDelegate:self];
	[theConnection setRootObject:managedObjectContext];

#else
	managedObjectContext = nil;
	
	@try
	{
		NSSocketPort *port = [[[NSSocketPort alloc] initRemoteWithTCPPort:STICKIES_SERVER_PORT host:@"127.0.0.1"] autorelease];

		NSConnection *theConnection = [[NSConnection connectionWithReceivePort:nil
			sendPort:port] retain];
		[theConnection setDelegate:self];
		managedObjectContext = (NSManagedObjectContext *)[[theConnection rootProxy] retain];
	}
	@catch (NSException *e)
	{
		[[NSAlert
			alertWithMessageText:@"Connection error"
			defaultButton:nil
			alternateButton:nil
			otherButton:nil
			informativeTextWithFormat:@"Server not found. Application will terminate."]
		runModal];
		
		[NSApp terminate:self];
	}
	
	[managedObjectContext forwardContextChangeNotificationsTo:self];
#endif
	
	return managedObjectContext;
}

- (void)forwardNotification:(NSNotification *)aNotification
{
	[[NSNotificationCenter defaultCenter]
		postNotification:aNotification];
}

- (IBAction) saveAction:(id)sender {
    NSError *error = nil;
    if (![[self managedObjectContext] save:&error]) {
        [[NSApplication sharedApplication] presentError:error];
    }
}

- (NSApplicationTerminateReply)applicationShouldTerminate:(NSApplication *)sender {
    int reply = NSTerminateNow;

#ifdef STICKIES_SERVER
    NSError *error;
    NSManagedObjectContext *context;
    context = [self managedObjectContext];
    if (context != nil) {
        if ([context commitEditing]) {
            if (![context save:&error]) {
				
				// This default error handling implementation should be changed to make sure the error presented includes application specific error recovery. For now, simply display 2 panels.
                BOOL errorResult = [[NSApplication sharedApplication] presentError:error];
				
				if (errorResult == YES) { // Then the error was handled
					reply = NSTerminateCancel;
				} else {
					
					// Error handling wasn't implemented. Fall back to displaying a "quit anyway" panel.
					int alertReturn = NSRunAlertPanel(nil, @"Could not save changes while quitting. Quit anyway?" , @"Quit anyway", @"Cancel", nil);
					if (alertReturn == NSAlertAlternateReturn) {
						reply = NSTerminateCancel;	
					}
				}
            }
        } else {
            reply = NSTerminateCancel;
        }
    }
#else
	[stickiesController removeObserver:self forKeyPath:@"arrangedObjects"];
	for (StickyWindowController *stickyWindowController in stickyWindowControllers)
	{
		[stickyWindowController close];
	}
	[stickyWindowControllers release];
#endif

    return reply;
}

@end

