//
//  TestClasses.h
//  ThreadingOverheads
//
//  Created by Matt Gallagher on 2010/09/14.
//  Copyright 2010 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import <Foundation/Foundation.h>

@class JobQueue;

@interface Job : NSObject
{
	NSInteger iterationsRemaining;
	NSCondition *finishedSignal;
}

@property (nonatomic, assign) NSInteger iterationsRemaining;

- (id)initWithIterations:(NSInteger)iterations;
- (void)performIterationAndRequeueInJobQueue:(JobQueue *)aJobQueue;
- (void)blockUntilFinished;

@end

@interface JobQueue : NSObject
{
}

- (void)queueJob:(Job *)aJob;

@end

@interface SingleThreadedQueue : JobQueue
{
	NSMutableArray *jobQueue;
}
@end

@interface RunLoopQueue : JobQueue
{
	NSThread *runLoopThread;
	BOOL terminated;
}
@end

@interface DetachThreadQueue : JobQueue
{
}
@end

@interface DetachThreadWithVerificationQueue : JobQueue
{
}
@end

@interface DispatchDedicatedQueue : JobQueue
{
	dispatch_queue_t queue;
}
@end

@interface DispatchGlobalConcurrentQueue : JobQueue
{
	dispatch_queue_t queue;
}
@end
