//
//  ThreadingOverheads.m
//  ThreadingOverheads
//
//  Created by Matt Gallagher on 2010/09/14.
//  Copyright 2010 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import <Foundation/Foundation.h>
#import "TestClasses.h"
#include <mach/mach_time.h>

double MachTimeDifferenceInSeconds(uint64_t start, uint64_t end)
{
    uint64_t delta = end - start;
	mach_timebase_info_data_t timebaseInfo;
	kern_return_t err = mach_timebase_info(&timebaseInfo);
	
	if(!err)
	{
		return delta * 1.0e-9 * timebaseInfo.numer / (double)timebaseInfo.denom;
    }
    
    return NAN;
}

int main (int argc, const char * argv[]) {
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	
	NSArray *jobQueueClasses =
		[[NSArray alloc] initWithObjects:
			[SingleThreadedQueue class],
			[RunLoopQueue class],
			[DetachThreadQueue class],
			[DetachThreadWithVerificationQueue class],
			[DispatchDedicatedQueue class],
			[DispatchGlobalConcurrentQueue class],
		nil];
	
	const NSInteger NumJobIterations = 6250;
	const NSInteger NumQueues = 16;
	
	for (Class jobQueueClass in jobQueueClasses)
	{
		NSMutableArray *jobQueues = [[NSMutableArray alloc] initWithCapacity:NumQueues];
		NSMutableArray *jobs = [[NSMutableArray alloc] initWithCapacity:NumQueues];
		for (NSInteger i = 0; i < NumQueues; i++)
		{
			JobQueue *jobQueue = [[jobQueueClass alloc] init];
			Job *job = [[Job alloc] initWithIterations:NumJobIterations];
			[jobQueues addObject:jobQueue];
			[jobs addObject:job];
			[job release];
			[jobQueue release];
		}
		
		NSLog(@"Running %ld iterations in %ld queues using %@",
			NumJobIterations, NumQueues, NSStringFromClass(jobQueueClass));
		
		uint64_t start = mach_absolute_time();
		
		for (NSInteger i = 0; i < NumQueues; i++)
		{
			JobQueue *jobQueue = [jobQueues objectAtIndex:i];
			Job *job = [jobs objectAtIndex:i];
			[jobQueue queueJob:job];
		}
		for (Job *job in jobs)
		{
			[job blockUntilFinished];
		}

		uint64_t end = mach_absolute_time();
		double elapsed = MachTimeDifferenceInSeconds(start, end);
		NSLog(@"Finished is %f seconds", elapsed);

		[jobs release];
		[jobQueues release];
	}
	
    [pool drain];
    return 0;
}
