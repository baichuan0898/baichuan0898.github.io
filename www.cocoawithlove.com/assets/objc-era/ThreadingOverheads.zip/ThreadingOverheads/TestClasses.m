//
//  TestClasses.m
//  ThreadingOverheads
//
//  Created by Matt Gallagher on 2010/09/14.
//  Copyright 2010 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "TestClasses.h"

@implementation JobQueue

- (void)queueJob:(Job *)aJob
{
	[NSException raise:NSInternalInconsistencyException format:@"Abstract method invoked"];
}

- (void)lastJobFinished
{
}

@end

@implementation Job

@synthesize iterationsRemaining;

- (id)initWithIterations:(NSInteger)iterations
{
	self = [super init];
	if (self)
	{
		iterationsRemaining = iterations;
		finishedSignal = [[NSCondition alloc] init];
	}
	return self;
}

- (void)performIterationAndRequeueInJobQueue:(JobQueue *)aJobQueue
{
	[finishedSignal lock];
	iterationsRemaining--;
	
	if (iterationsRemaining == 0)
	{
		[finishedSignal broadcast];
		[finishedSignal unlock];
		[aJobQueue lastJobFinished];
	}
	else
	{
		[finishedSignal unlock];
		[aJobQueue queueJob:self];
	}
}

- (void)blockUntilFinished
{
	[finishedSignal lock];
	if (iterationsRemaining > 0)
	{
		[finishedSignal wait];
	}
	[finishedSignal unlock];
	[finishedSignal release];
	finishedSignal = nil;
}

- (void)killJob
{
	[finishedSignal lock];
	iterationsRemaining = 0;
	[finishedSignal broadcast];
	[finishedSignal unlock];
}

@end

@implementation SingleThreadedQueue

- (void)queueJob:(Job *)aJob
{
	if (!jobQueue)
	{
		jobQueue = [[NSMutableArray alloc] init];
		[jobQueue addObject:aJob];
		
		while ([jobQueue count] > 0)
		{
			Job *nextJob = [jobQueue objectAtIndex:0];
			[jobQueue removeObjectAtIndex:0]; 
			[nextJob performIterationAndRequeueInJobQueue:self];
		}
		
		[jobQueue release];
		jobQueue = nil;
	}
	else
	{
		[jobQueue addObject:aJob];
	}
}

@end

@implementation RunLoopQueue

- (id)init
{
	self = [super init];
	if (self != nil)
	{
		runLoopThread = [[NSThread alloc] initWithTarget:self selector:@selector(runLoop) object:nil];
		[runLoopThread start];
	}
	return self;
}

- (void)runLoop
{
	//
	// Run loops will exit if they have no sources. We add a dummy NSPort object
	// to the run loop so it will run until we call CFRunLoopStop().
	//
	NSPort *dummyPort = [[NSMachPort alloc] init];
	[[NSRunLoop currentRunLoop]
		addPort:dummyPort
		forMode:NSDefaultRunLoopMode];
		
	CFRunLoopRun();
	
	[[NSRunLoop currentRunLoop]
		removePort:dummyPort
		forMode:NSDefaultRunLoopMode];
	[dummyPort release];
}

- (void)lastJobFinished
{
	CFRunLoopStop(CFRunLoopGetCurrent());
}

- (void)queueJob:(Job *)aJob
{
	[aJob
		performSelector:@selector(performIterationAndRequeueInJobQueue:)
		onThread:runLoopThread 
		withObject:self
		waitUntilDone:NO];
}

- (void)dealloc
{
	[runLoopThread release];
	runLoopThread = nil;
	[super dealloc];
}


@end

@implementation DetachThreadQueue

- (void)threadEntry:(Job *)aJob
{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	[aJob performIterationAndRequeueInJobQueue:self];
	[pool release];
}

- (void)queueJob:(Job *)aJob
{
	[NSThread detachNewThreadSelector:@selector(threadEntry:) toTarget:self withObject:aJob];
}

@end

@implementation DetachThreadWithVerificationQueue

- (void)threadEntry:(id)threadParameters
{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];

	NSCondition *startedCondition = [threadParameters objectForKey:@"condition"];
	Job *aJob = [threadParameters objectForKey:@"job"];
	
	[startedCondition lock];
	[startedCondition signal];
	[startedCondition unlock];

	[aJob performIterationAndRequeueInJobQueue:self];
	[pool release];
}

- (void)queueJob:(Job *)aJob
{
	NSCondition *startedCondition = [[NSCondition alloc] init];
	NSDictionary *threadParameters =
		[NSDictionary dictionaryWithObjectsAndKeys:
			aJob, @"job",
			startedCondition, @"condition",
		nil];
	
	[startedCondition lock];

	[NSThread detachNewThreadSelector:@selector(threadEntry:) toTarget:self withObject:threadParameters];

	if (![startedCondition waitUntilDate:[NSDate dateWithTimeIntervalSinceNow:10.0]])
	{
		NSLog(@"Thread creation failed.");
		[aJob killJob];
	}
	
	[startedCondition unlock];
	[startedCondition release];
}

@end

@implementation DispatchDedicatedQueue

- (id)init
{
	self = [super init];
	if (self != nil)
	{
		NSString *nameFromSelf = [NSString stringWithFormat:@"queue%p", self];
		queue = dispatch_queue_create([nameFromSelf UTF8String], NULL);
	}
	return self;
}

- (void)dealloc
{
	dispatch_release(queue);
	[super dealloc];
}

- (void)queueJob:(Job *)aJob
{
	dispatch_async(queue, ^{
		[aJob performIterationAndRequeueInJobQueue:self];
	});
}

@end

@implementation DispatchGlobalConcurrentQueue

- (id)init
{
	self = [super init];
	if (self != nil)
	{
		queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
		dispatch_retain(queue);
	}
	return self;
}

- (void)dealloc
{
	dispatch_release(queue);
	[super dealloc];
}

- (void)queueJob:(Job *)aJob
{
	dispatch_async(queue, ^{
		[aJob performIterationAndRequeueInJobQueue:self];
	});
}

@end
