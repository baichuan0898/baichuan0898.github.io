//
//  QuartzGLTestView.m
//  QuartzGLTest
//
//  Created by Matt Gallagher on 2011/03/25.
//  Copyright 2011 Matt Gallagher. All rights reserved.
//

#import "QuartzGLTestView.h"

@implementation QuartzGLTestView

- (void)setFPS:(double)newFPS
{
	fps = newFPS;
}

- (void)drawRect:(NSRect)rect
{
//
// Test 1 tests drawing a flat rectangle
// Test 2 tests drawing text
// Test 3 tests drawing lines
//
#define TEST 1
#if TEST == 1

	[[[NSColor redColor] colorWithAlphaComponent:0.01] set];
	for (NSInteger k = 0; k < 1000; k++)
	{
		[[NSBezierPath bezierPathWithRect:rect] fill];
	}

#elif TEST == 2

	for (NSInteger j = 0; j < 2000; j++)
	{
		NSString *displayString =
			@"A string to excercise basic Cocoa text drawing.";
		[displayString
			drawAtPoint:NSMakePoint(0, 0.5 * self.bounds.size.height)
			withAttributes:nil];
	}

#elif TEST == 3

	[[NSColor grayColor] set];
	for (NSInteger l = 0; l < 2000; l++)
	{
		CGFloat xCoord1 = self.bounds.size.width * random() / (CGFloat)INT_MAX;
		CGFloat xCoord2 = self.bounds.size.width * random() / (CGFloat)INT_MAX;
		CGFloat yCoord1 = self.bounds.size.height * random() / (CGFloat)INT_MAX;
		CGFloat yCoord2 = self.bounds.size.height * random() / (CGFloat)INT_MAX;
		
		NSBezierPath *line = [NSBezierPath bezierPath];
		[line moveToPoint:NSMakePoint(xCoord1, yCoord1)];
		[line lineToPoint:NSMakePoint(xCoord2, yCoord2)];
		[line stroke];
	}

#endif
	
	NSString *fpsDisplay = [NSString stringWithFormat:@"%f fps", fps];
	[fpsDisplay drawAtPoint:NSZeroPoint withAttributes:nil];
}

@end
