//
//  QuartzGLTestWindowController.m
//  QuartzGLTest
//
//  Created by Matt Gallagher on 2011/03/25.
//  Copyright 2011 Matt Gallagher. All rights reserved.
//

#import "QuartzGLTestWindowController.h"
#import "QuartzGLTestView.h"

@implementation QuartzGLTestWindowController

- (void)windowDidLoad
{
	updateTimes = [[NSMutableArray alloc] init];
	updateTimer =
		[[NSTimer
			scheduledTimerWithTimeInterval:0.001
			target:self
			selector:@selector(drawFrame)
			userInfo:nil
			repeats:YES]
		retain];
}

- (void)drawFrame
{
	//
	// Keep a record of frame times over the last 10 seconds to provide a
	// frame rate average over 10 seconds
	//
	NSInteger i = 0;
	while (i < [updateTimes count] && [[updateTimes objectAtIndex:i] timeIntervalSinceNow] < -10)
	{
		[updateTimes removeObjectAtIndex:0];
	}
	[updateTimes addObject:[NSDate date]];
	
	//
	// Perform the update using a display (don't wait for deferred drawing)
	//
	[[[self window] contentView] display];
	
	//
	// Update the FPS rate on the view
	//
	NSTimeInterval interval = -[[updateTimes objectAtIndex:0] timeIntervalSinceNow];
	[(QuartzGLTestView *)[[self window] contentView]
		setFPS:[updateTimes count] / interval];
}

- (NSString *)windowNibName
{
	return @"QuartzGLTestWindow";
}

- (void)windowWillClose:(NSNotification *)notification
{
	[[NSApplication sharedApplication] terminate:nil];
}

- (void)dealloc
{
	[updateTimer invalidate];
	[updateTimer release];
	updateTimer = nil;
	
	[super dealloc];
}

@end
