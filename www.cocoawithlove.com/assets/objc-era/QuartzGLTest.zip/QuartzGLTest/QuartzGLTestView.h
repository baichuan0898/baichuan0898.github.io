//
//  QuartzGLTestView.h
//  QuartzGLTest
//
//  Created by Matt Gallagher on 2011/03/25.
//  Copyright 2011 Matt Gallagher. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface QuartzGLTestView : NSView
{
	double fps;
}

- (void)setFPS:(double)newFPS;

@end
