//
//  main.m
//  QuartzGLTest
//
//  Created by Matt Gallagher on 2011/03/25.
//  Copyright 2011 Matt Gallagher. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
