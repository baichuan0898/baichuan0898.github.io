//
//  QuartzGLTestAppDelegate.h
//  QuartzGLTest
//
//  Created by Matt Gallagher on 2011/03/25.
//  Copyright 2011 Matt Gallagher. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class QuartzGLTestWindowController;

@interface QuartzGLTestAppDelegate : NSObject <NSApplicationDelegate> {
    QuartzGLTestWindowController *windowController;
}

@property (nonatomic, retain) IBOutlet QuartzGLTestWindowController *windowController;

@end
