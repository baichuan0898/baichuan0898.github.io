//
//  QuartzGLTestAppDelegate.m
//  QuartzGLTest
//
//  Created by Matt Gallagher on 2011/03/25.
//  Copyright 2011 Matt Gallagher. All rights reserved.
//

#import "QuartzGLTestAppDelegate.h"
#import "QuartzGLTestWindowController.h"

@implementation QuartzGLTestAppDelegate

@synthesize windowController;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application 
	self.windowController = [[[QuartzGLTestWindowController alloc] init] autorelease];
	[[self.windowController window] makeKeyAndOrderFront:self];
}

@end
