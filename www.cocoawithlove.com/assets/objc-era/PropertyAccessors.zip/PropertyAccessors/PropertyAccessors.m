//
//  PropertyAccessors.m
//  PropertyAccessors
//
//  Created by Matt Gallagher on 2009/11/14.
//  Copyright Matt Gallagher 2009 . All rights reserved.
//

#import <objc/objc-auto.h>
#import "PropertyCoalescing.h"

NSManagedObjectModel *managedObjectModel();
NSManagedObjectContext *managedObjectContext();

@interface NSManagedObjectContext (FetchAdditions)

- (NSSet *)fetchObjectSetForRequest:(NSFetchRequest *)request;

@end

@implementation NSManagedObjectContext (FetchAdditions)

- (NSSet *)fetchObjectSetForRequest:(NSFetchRequest *)request
{
	NSError *error = nil;
	NSArray *results = [self executeFetchRequest:request error:&error];
	
	NSAssert(error == nil, [error description]);
	
	return [NSSet setWithArray:results];
}

@end

@interface NSManagedObject (Properties)

@property (nonatomic, retain) NSSet *projects;
@property (nonatomic, retain) NSSet *employees;
@property (nonatomic, retain) NSString *name;
@property (nonatomic, retain) NSManagedObject *company;
@property (nonatomic, retain) NSManagedObject *project;

@end

int main (int argc, const char * argv[]) {
	
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
	// Create the managed object context
    NSManagedObjectContext *context = managedObjectContext();
	
	// Custom code here...
	NSFetchRequest *fetchRequest = [[[NSFetchRequest alloc] init] autorelease];
	[fetchRequest setEntity:[NSEntityDescription entityForName:@"Company" inManagedObjectContext:context]];
	[fetchRequest setRelationshipKeyPathsForPrefetching:
		[NSArray arrayWithObjects:@"projects", @"projects.employees", nil]];
	
	const NSInteger NumCompanies = 10;
	const NSInteger NumProjectsPerCompany = 100;
	const NSInteger NumEmployeesPerProject = 100;
	
	NSLog(@"Attempting to prefetch all objects...");
	
	NSSet *companies = [context fetchObjectSetForRequest:fetchRequest];
	BOOL databaseCreated = NO;
	if ([companies count] == 0)
	{
		NSLog(@"No objects found. Creating %ld companies...", NumCompanies);

		for (NSInteger i = 0; i < NumCompanies; i++)
		{
			NSManagedObject *company =
				[NSEntityDescription
					insertNewObjectForEntityForName:@"Company"
					inManagedObjectContext:context];
				
			for (NSInteger j = 0; j < NumProjectsPerCompany; j++)
			{
				NSManagedObject *project =
					[NSEntityDescription
						insertNewObjectForEntityForName:@"Project"
						inManagedObjectContext:context];
				
				project.company = company;
				project.name = [NSString stringWithFormat:@"Project %ld", j];
				
				for (NSInteger k = 0; k < NumEmployeesPerProject; k++)
				{
					NSManagedObject *employee =
						[NSEntityDescription
							insertNewObjectForEntityForName:@"Employee"
							inManagedObjectContext:context];
					
					employee.project = project;
					employee.name = [NSString stringWithFormat:@"Employee %ld", j];
				}
			}
			
			if (i % 10 == 0)
			{
				NSLog(@"Created company %ld", i);
			}
		}
		
		databaseCreated = YES;
		companies = [context fetchObjectSetForRequest:fetchRequest];
	}
	NSLog(@"Objects ready.");
	
	NSDate *startDate;
	NSDate *endDate;
	NSTimeInterval timeElapsed;
	const NSInteger NumTestInterations = 10;
	
	//
	// Test the basic key value accessor
	//
	startDate = [NSDate date];
	for (NSInteger test = 0; test < NumTestInterations; test++)
	{
   		NSAutoreleasePool *testPool = [[NSAutoreleasePool alloc] init];
		
		for (NSManagedObject *company in companies)
		{
			NSSet *allProject = [company valueForKey:@"projects"];
			NSCAssert([allProject count] == NumProjectsPerCompany,
				@"Test returned incorrect result count.");
		}
		
		[testPool drain];
	}
	endDate = [NSDate date];
	timeElapsed = [endDate timeIntervalSinceDate:startDate];
	NSLog(@"Basic key value accessor took                   %g seconds.", timeElapsed);

	//
	// Test the basic property accessor
	//
	startDate = [NSDate date];
	for (NSInteger test = 0; test < NumTestInterations; test++)
	{
   		NSAutoreleasePool *testPool = [[NSAutoreleasePool alloc] init];
		
		for (NSManagedObject *company in companies)
		{
			NSSet *allProjects = company.projects;
			NSCAssert([allProjects count] == NumProjectsPerCompany,
				@"Test returned incorrect result count.");
		}
		
		[testPool drain];
	}
	endDate = [NSDate date];
	timeElapsed = [endDate timeIntervalSinceDate:startDate];
	NSLog(@"Basic property accessor test took               %g seconds.", timeElapsed);
	
	//
	// Test the key path accessor
	//
	startDate = [NSDate date];
	for (NSInteger test = 0; test < NumTestInterations; test++)
	{
   		NSAutoreleasePool *testPool = [[NSAutoreleasePool alloc] init];
		
		for (NSManagedObject *company in companies)
		{
			NSSet *allProjectNames = [company valueForKeyPath:@"projects.name"];
			NSCAssert([allProjectNames count] == NumProjectsPerCompany,
				@"Test returned incorrect result count.");
		}
		
		[testPool drain];
	}
	endDate = [NSDate date];
	timeElapsed = [endDate timeIntervalSinceDate:startDate];
	NSLog(@"Key Path set iteration test took                %g seconds.", timeElapsed);

	//
	// Test the slowObjectValuesForProperty: accessor
	//
	startDate = [NSDate date];
	for (NSInteger test = 0; test < NumTestInterations; test++)
	{
   		NSAutoreleasePool *testPool = [[NSAutoreleasePool alloc] init];
		
		for (NSManagedObject *company in companies)
		{
			NSSet *allProjectNames = [company.projects slowObjectValuesForProperty:@selector(name)];
			NSCAssert([allProjectNames count] == NumProjectsPerCompany,
				@"Test returned incorrect result count.");
		}
		
		[testPool drain];
	}
	endDate = [NSDate date];
	timeElapsed = [endDate timeIntervalSinceDate:startDate];
	NSLog(@"Slow objectValuesForProperty: test took         %g seconds.", timeElapsed);

	//
	// Test the objectValuesForProperty: accessor
	//
	startDate = [NSDate date];
	for (NSInteger test = 0; test < NumTestInterations; test++)
	{
   		NSAutoreleasePool *testPool = [[NSAutoreleasePool alloc] init];
		
		for (NSManagedObject *company in companies)
		{
			NSSet *allProjectNames = [company.projects objectValuesForProperty:@selector(name)];
			NSCAssert([allProjectNames count] == NumProjectsPerCompany,
				@"Test returned incorrect result count.");
		}
		
		[testPool drain];
	}
	endDate = [NSDate date];
	timeElapsed = [endDate timeIntervalSinceDate:startDate];
	NSLog(@"Optimized objectValuesForProperty: test took    %g seconds.", timeElapsed);

	//
	// Test the key path coalescing accessor
	//
	startDate = [NSDate date];
	for (NSInteger test = 0; test < NumTestInterations; test++)
	{
   		NSAutoreleasePool *testPool = [[NSAutoreleasePool alloc] init];
		
		for (NSManagedObject *company in companies)
		{
			NSSet *allEmployees = [company valueForKeyPath:@"projects.@distinctUnionOfSets.employees"];
			NSCAssert([allEmployees count] == NumProjectsPerCompany * NumEmployeesPerProject,
				@"Test returned incorrect result count.");
		}
		
		[testPool drain];
	}
	endDate = [NSDate date];
	timeElapsed = [endDate timeIntervalSinceDate:startDate];
	NSLog(@"Key path coalescing accessor test took          %g seconds.", timeElapsed);

	//
	// Test the slowCoalescedValuesForProperty: accessor
	//
	startDate = [NSDate date];
	for (NSInteger test = 0; test < NumTestInterations; test++)
	{
   		NSAutoreleasePool *testPool = [[NSAutoreleasePool alloc] init];
		
		for (NSManagedObject *company in companies)
		{
			NSSet *allEmployees = [company.projects slowCoalescedValuesForProperty:@selector(employees)];
			NSCAssert([allEmployees count] == NumProjectsPerCompany * NumEmployeesPerProject,
				@"Test returned incorrect result count.");
		}
		
		[testPool drain];
	}
	endDate = [NSDate date];
	timeElapsed = [endDate timeIntervalSinceDate:startDate];
	NSLog(@"Slow coalescedValuesForProperty: test took      %g seconds.", timeElapsed);

	//
	// Test the coalescedValuesForProperty: accessor
	//
	startDate = [NSDate date];
	for (NSInteger test = 0; test < NumTestInterations; test++)
	{
   		NSAutoreleasePool *testPool = [[NSAutoreleasePool alloc] init];
		
		for (NSManagedObject *company in companies)
		{
			NSSet *allEmployees = [company.projects coalescedValuesForProperty:@selector(employees)];
			NSCAssert([allEmployees count] == NumProjectsPerCompany * NumEmployeesPerProject,
				@"Test returned incorrect result count.");
		}
		
		[testPool drain];
	}
	endDate = [NSDate date];
	timeElapsed = [endDate timeIntervalSinceDate:startDate];
	NSLog(@"Optimized coalescedValuesForProperty: test took %g seconds.", timeElapsed);

	// Save the managed object context
	if (databaseCreated)
	{
		NSLog(@"Writing newly created database. This will take a few seconds.");
	}
    NSError *error = nil;    
    if (![context save:&error]) {
        NSLog(@"Error while saving\n%@",
              ([error localizedDescription] != nil) ? [error localizedDescription] : @"Unknown Error");
		[pool drain];
        exit(1);
    }
	
	[pool drain];
	
    return 0;
}



NSManagedObjectModel *managedObjectModel() {
    
    static NSManagedObjectModel *model = nil;
    
    if (model != nil) {
        return model;
    }
    
	NSString *path = [[[NSProcessInfo processInfo] arguments] objectAtIndex:0];
	path = [path stringByDeletingPathExtension];
	NSURL *modelURL = [NSURL fileURLWithPath:[path stringByAppendingPathExtension:@"mom"]];
    model = [[NSManagedObjectModel alloc] initWithContentsOfURL:modelURL];
    
    return model;
}



NSManagedObjectContext *managedObjectContext() {
	
    static NSManagedObjectContext *context = nil;
    if (context != nil) {
        return context;
    }
    
    context = [[NSManagedObjectContext alloc] init];
    
    NSPersistentStoreCoordinator *coordinator = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel: managedObjectModel()];
    [context setPersistentStoreCoordinator: coordinator];
	[coordinator release];
    
    NSString *STORE_TYPE = NSSQLiteStoreType;
	
	NSString *path = [[[NSProcessInfo processInfo] arguments] objectAtIndex:0];
	path = [path stringByDeletingPathExtension];
	NSURL *url = [NSURL fileURLWithPath:[path stringByAppendingPathExtension:@"sqlite"]];
    
	NSError *error;
    NSPersistentStore *newStore = [coordinator addPersistentStoreWithType:STORE_TYPE configuration:nil URL:url options:nil error:&error];
    
    if (newStore == nil) {
        NSLog(@"Store Configuration Failure\n%@",
              ([error localizedDescription] != nil) ?
              [error localizedDescription] : @"Unknown Error");
    }
    
    return context;
}

