//
//  PropertyCoalescing.m
//  PropertyAccessors
//
//  Created by Matt Gallagher on 2009/11/14.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//

#import "PropertyCoalescing.h"
#import <objc/message.h>

@implementation NSSet (PropertyCoalescing)

- (NSSet *)slowObjectValuesForProperty:(SEL)propertySelector
{
	NSMutableSet *result = [NSMutableSet set];
	for (id object in self)
	{
		id value = objc_msgSend(object, propertySelector);
		if (value)
		{
			[result addObject:value];
		}
	}
	return result;
}

- (NSSet *)setByCoalescingSets
{
	NSMutableSet *result = [NSMutableSet set];
	for (NSSet *object in self)
	{
		[result unionSet:object];
	}
	return result;
}

- (NSSet *)slowCoalescedValuesForProperty:(SEL)propertySelector
{
	return [[self objectValuesForProperty:propertySelector] setByCoalescingSets];
}

- (NSSet *)objectValuesForProperty:(SEL)propertySelector
{
	NSMutableSet *result = [NSMutableSet setWithCapacity:[self count]];
	for (id object in self)
	{
		id value = objc_msgSend(object, propertySelector);
		if (value)
		{
			[result addObject:value];
		}
	}
	return result;
}

- (NSSet *)coalescedValuesForProperty:(SEL)propertySelector
{
	NSInteger count = 0;
	for (id object in self)
	{
		count += [objc_msgSend(object, propertySelector) count];
	}
	NSMutableSet *result = [NSMutableSet setWithCapacity:count];
	for (id object in self)
	{
		id value = objc_msgSend(object, propertySelector);
		if (value)
		{
			[result unionSet:value];
		}
	}
	return result;
}

@end
