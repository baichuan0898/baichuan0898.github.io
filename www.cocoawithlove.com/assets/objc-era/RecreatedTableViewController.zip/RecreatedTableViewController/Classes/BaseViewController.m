//
//  BaseViewController.m
//  RecreatedTableViewController
//
//  Created by Matt Gallagher on 22/03/09.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "BaseViewController.h"


@implementation BaseViewController

//
// updateWithDateComponents:
//
// The default implementation of this method does nothing. Subclasses should
// override to update when the date changes.
//
- (void)updateWithDateComponents:(NSDateComponents *)components
{
}

//
// timerUpdate:
//
- (void)timerUpdate:(NSTimer *)aTimer
{
	NSDate *date = [NSDate date];
	NSCalendar *calendar = [NSCalendar currentCalendar];
	
	const NSInteger unitFlags =
		NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit;
	NSDateComponents *components =
		[calendar components:unitFlags fromDate:date];
	
	if (![components isEqual:lastComponents])
	{
		[lastComponents release];
		lastComponents = [components retain];
		[self updateWithDateComponents:components];
	}
}

//
// viewDidAppear:
//
- (void)viewWillAppear:(BOOL)animated
{
	[self timerUpdate:nil];
	timer = [NSTimer
		scheduledTimerWithTimeInterval:0.05
		target:self
		selector:@selector(timerUpdate:)
		userInfo:nil
		repeats:YES];
}

//
// viewWillDisappear:
//
- (void)viewWillDisappear:(BOOL)animated
{
	[timer invalidate];
	[lastComponents release];
	lastComponents = nil;
}

@end
