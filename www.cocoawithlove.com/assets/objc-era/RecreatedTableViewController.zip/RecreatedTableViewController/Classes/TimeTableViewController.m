//
//  TimeTableViewController.m
//  RecreatedTableViewController
//
//  Created by Matt Gallagher on 22/03/09.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "TimeTableViewController.h"
#import "DetailViewController.h"

@implementation TimeTableViewController

//
// title
//
- (NSString *)title
{
	return @"Time as a table";
}

//
// componentNames
//
// Returns the array of row components.
//
+ (NSArray *)componentNames
{
	return [NSArray arrayWithObjects:@"hour", @"minute", @"second", nil];
}

//
// dealloc
//
// Releases instance memory.
//
- (void)dealloc
{
	[tableView release];
	[super dealloc];
}

//
// loadView
//
// Handle construction of the table view.
//
- (void)loadView
{
	if (self.nibName)
	{
		[super loadView];
		NSAssert(tableView != nil, @"NIB file did not set tableView property.");
		return;
	}
	
	UITableView *newTableView =
		[[[UITableView alloc]
			initWithFrame:CGRectZero
			style:UITableViewStylePlain]
		autorelease];
	self.view = newTableView;
	self.tableView = newTableView;
}

//
// tableView
//
// This method connects to the view property by default.
//
- (UITableView *)tableView
{
	return tableView;
}

//
// setTableView
//
// This method connects to the view property by default.
//
- (void)setTableView:(UITableView *)newTableView
{
	[tableView release];
	tableView = [newTableView retain];
	[tableView setDelegate:self];
	[tableView setDataSource:self];
}

//
// numberOfSectionsInTableView:
//
// Return the number of sections for the table.
//
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

//
// tableView:numberOfRowsInSection:
//
// Returns the number of rows in a given section.
//
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return lastComponents ? [[TimeTableViewController componentNames] count] : 0;
}

//
// updateWithDateComponents:
//
// The default implementation of this method does nothing. Subclasses should
// override to update when the date changes.
//
- (void)updateWithDateComponents:(NSDateComponents *)components
{
	[self.tableView reloadData];
}

//
// tableView:cellForRowAtIndexPath:
//
// Returns the cell for a given indexPath.
//
- (UITableViewCell *)tableView:(UITableView *)aTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	static NSString *cellIdentifier = @"Cell";
	
	UITableViewCell *cell = [aTableView dequeueReusableCellWithIdentifier:cellIdentifier];
	if (cell == nil)
	{
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:cellIdentifier] autorelease];
		cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	}
	
	NSString *componentName = [[TimeTableViewController componentNames] objectAtIndex:[indexPath row]];
	cell.text =
		[NSString stringWithFormat:@"%@s: %ld",
			[componentName capitalizedString],
			[lastComponents
				performSelector:NSSelectorFromString(componentName)
				withObject:nil]];
	
	return cell;
}

//
// tableView:didSelectRowAtIndexPath:
//
// Handle row selection
//
- (void)tableView:(UITableView *)aTableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	UIViewController *childViewController =
		[[[DetailViewController alloc]
			initWithComponentName:
				[[TimeTableViewController componentNames]
					objectAtIndex:[indexPath row]]]
		autorelease];
	
	[self.navigationController pushViewController:childViewController animated:YES];
}

@end

