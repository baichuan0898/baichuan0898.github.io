//
//  DetailViewController.m
//  RecreatedTableViewController
//
//  Created by Matt Gallagher on 22/03/09.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "DetailViewController.h"


@implementation DetailViewController

//
// initWithComponentName:
//
// Init method for the object.
//
- (id)initWithComponentName:(NSString *)aComponentName
{
	self = [super init];
	if (self != nil)
	{
		componentName = [aComponentName retain];
	}
	return self;
}

//
// title
//
- (NSString *)title
{
	return [componentName capitalizedString];
}

//
// dealloc
//
// Releases instance memory.
//
- (void)dealloc
{
	[componentName release];
	[super dealloc];
}

//
// loadView
//
// Handle construction of the table view.
//
- (void)loadView
{
	[super loadView];
	
	self.view.backgroundColor = [UIColor whiteColor];
	
	UILabel *componentLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 20, 300, 50)];
	componentLabel.text = [NSString stringWithFormat:
		@"Value for %@ component:", componentName];
	[self.view addSubview:componentLabel];

	displayLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 70, 300, 50)];
	[self.view addSubview:displayLabel];
}

//
// updateWithDateComponents:
//
// The default implementation of this method does nothing. Subclasses should
// override to update when the date changes.
//
- (void)updateWithDateComponents:(NSDateComponents *)components
{
	displayLabel.text =
		[NSString stringWithFormat:@"%ld",
			[components
				performSelector:NSSelectorFromString(componentName)
				withObject:nil]];
}

@end
