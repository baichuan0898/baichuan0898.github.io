//
//  TapZoomRotateViewController.m
//  TapZoomRotate
//
//  Created by Matt Gallagher on 2010/09/27.
//  Copyright 2010 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file, free of charge, in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "TapZoomRotateViewController.h"
#import "ZoomingViewController.h"

@implementation TapZoomRotateViewController

@synthesize zoomingView;

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation
{
	return YES;
}

- (void)viewDidLoad
{
	zoomingViewController = [[ZoomingViewController alloc] init];
	zoomingViewController.view = zoomingView;
	
	CGRect zoomingViewFrame = zoomingViewController.view.frame;
	CGRect ownBounds = self.view.bounds;
	zoomingViewController.view.frame = CGRectMake(
		ownBounds.origin.x + 0.5 * (ownBounds.size.width - zoomingViewFrame.size.width),
		ownBounds.origin.y + 0.5 * (ownBounds.size.height - zoomingViewFrame.size.height),
		zoomingViewFrame.size.width,
		zoomingViewFrame.size.height);
}

- (void)viewWillDisappear:(BOOL)animated
{
	[zoomingViewController dismissFullscreenView];
}

- (void)viewDidUnload
{
	// Release any retained subviews of the main view.
	[zoomingViewController release];
	zoomingViewController = nil;
	self.zoomingView = nil;
}

@end
