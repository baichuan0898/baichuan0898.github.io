//
//  GameController.m
//  Quartzeroids2
//
//  Created by Matt Gallagher on 15/02/09.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file without charge in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "GameController.h"
#import "GameData.h"
#import "ImageLayer.h"
#import "GameObjectLayer.h"
#import "AsteroidFrontLayer.h"

@implementation GameController

//
// updateContentViewFrame:
//
// When the window (and hence the window's content view) changes size, this
// will resize, reposition and rescale the content by adjusting the
// backgroundLayer (to which all other CALayers are parented).
//
- (void)updateContentViewFrame:(NSNotification *)notification
{
	double gameWidth = [[GameData sharedGameData] gameWidth];
	double gameHeight = [[GameData sharedGameData] gameHeight];
	
	NSSize contentSize = [contentView bounds].size;

	NSSize aspectSize = contentSize;
	double scale;
	if ((aspectSize.width / aspectSize.height) > (gameWidth / gameHeight))
	{
		scale = aspectSize.height / gameHeight;
		aspectSize.width = aspectSize.height * (gameWidth / gameHeight);
	}
	else
	{
		scale = aspectSize.width / gameWidth;
		aspectSize.height = aspectSize.width * (gameHeight / gameWidth);
	}
	
	[CATransaction begin];
	[CATransaction setValue:(id)kCFBooleanTrue forKey:kCATransactionDisableActions];
	backgroundLayer.transform = CATransform3DMakeScale(scale, scale, 1.0);
	backgroundLayer.frame =
		CGRectMake(
			0.5 * (contentSize.width - aspectSize.width),
			0.5 * (contentSize.height - aspectSize.height),
			aspectSize.width,
			aspectSize.height);
	[CATransaction commit];

	[contentView becomeFirstResponder];
}

//
// createImageLayerForGameObject:
//
// The game data sends a notification when a new game object is created. We
// create a layer to display that object here. The layer will maintain
// its own observations of further changes.
//
- (void)createImageLayerForGameObject:(NSNotification *)notification
{
	NSString *gameObjectKey = [notification object];
	
	GameObjectLayer *newLayer =
		[[[GameObjectLayer alloc]
			initWithGameObjectKey:gameObjectKey]
		autorelease];

	[CATransaction begin];
	[CATransaction
		setValue:[NSNumber numberWithBool:YES]
		forKey:kCATransactionDisableActions];
	[backgroundLayer addSublayer:newLayer];
	[CATransaction commit];
	
	if ([gameObjectKey rangeOfString:GAME_ASTEROID_KEY_BASE].location == 0)
	{
		AsteroidFrontLayer *asteroidFrontLayer =
			[[[AsteroidFrontLayer alloc]
				initWithGameObjectKey:gameObjectKey]
			autorelease];
		
		[CATransaction begin];
		[CATransaction
			setValue:[NSNumber numberWithBool:YES]
			forKey:kCATransactionDisableActions];
		[backgroundLayer addSublayer:asteroidFrontLayer];
		[CATransaction commit];
	}
}

//
// observeValueForKeyPath:ofObject:change:context:
//
// Receives key value change notifications for the following keys.
//
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object
	change:(NSDictionary *)change context:(void *)context
{
	if ([keyPath isEqualToString:GAME_DATA_MESSAGE_KEY])
	{
		NSString *value = [change objectForKey:NSKeyValueChangeNewKey];
		
		if ([value isEqual:[NSNull null]])
		{
			[[readyText layer] setHidden:YES];
		}
		else
		{
			[[readyText layer] setHidden:NO];
			[readyText setStringValue:value];
		}
		return;
	}
	
	[super observeValueForKeyPath:keyPath ofObject:object change:change
		context:context];
}

//
// awakeFromNib
//
// Creates the background layer and sets the startup state.
//
- (void)awakeFromNib
{
	frontLayers = [[NSMutableDictionary alloc] init];
	
	[readyText setHidden:YES];
	[continueButton setHidden:YES];

	[contentView layer].backgroundColor = CGColorCreateGenericRGB(0, 0, 0, 1);
	CGColorRelease([contentView layer].backgroundColor);
	
	backgroundLayer =
		[[[ImageLayer alloc]
			initWithImageNamed:@"background"
			frame:NSZeroRect]
		autorelease];
	backgroundLayer.masksToBounds = YES;
	[[contentView layer] insertSublayer:backgroundLayer atIndex:0];
	[self updateContentViewFrame:nil];
	
	[[[GameData sharedGameData] gameData]
		addObserver:self
		forKeyPath:GAME_DATA_MESSAGE_KEY
		options:NSKeyValueObservingOptionNew
		context:nil];
	[[readyText layer] setHidden:YES];
	
	[livesText
		bind:NSValueBinding
		toObject:[[GameData sharedGameData] gameData]
		withKeyPath:GAME_DATA_LIVES_KEY
		options:nil];
	[levelText
		bind:NSValueBinding
		toObject:[[GameData sharedGameData] gameData]
		withKeyPath:GAME_DATA_LEVEL_KEY
		options:nil];
	
	[[NSNotificationCenter defaultCenter]
		addObserver:self
		selector:@selector(updateContentViewFrame:)
		name:NSViewFrameDidChangeNotification
		object:contentView];
	[[NSNotificationCenter defaultCenter]
		addObserver:self
		selector:@selector(createImageLayerForGameObject:)
		name:GAME_OBJECT_NEW_NOTIFICATION
		object:nil];
	[[NSNotificationCenter defaultCenter]
		addObserver:self
		selector:@selector(gameEnded:)
		name:GAME_OVER_NOTIFICATION
		object:nil];
}

//
// gameEnded:
//
// Updates the UI for the out-of-game state.
//
- (IBAction)gameEnded:(id)sender
{
	[continueButton setHidden:YES];
	[buttonContainerView setHidden:NO];
}

//
// togglePause
//
// Invoked when "Escape" is pressed.
//
- (IBAction)togglePause:(id)sender
{
	if ([buttonContainerView isHidden] == YES)
	{
		[[GameData sharedGameData] stopUpdates];
		[buttonContainerView setHidden:NO];
	}
	else
	{
		if ([continueButton isHidden] == NO)
		{
			[buttonContainerView setHidden:YES];
			[contentView becomeFirstResponder];

			[[GameData sharedGameData] startUpdates];
		}
	}
}

//
// newGame:
//
// Starts the game.
//
- (IBAction)newGame:(id)sender
{
	[continueButton setHidden:NO];
	[buttonContainerView setHidden:YES];
	[contentView becomeFirstResponder];
	
	[[GameData sharedGameData] newGame];
}

//
// toggleFullscreen:
//
// Toggles the fullscreen window for the game.
//
- (IBAction)toggleFullscreen:(id)sender
{
	if ([contentView isInFullScreenMode])
	{
		[contentView exitFullScreenModeWithOptions:nil];
	}
	else
	{
		[contentView enterFullScreenMode:[[contentView window] screen] withOptions:nil];
		
		for (NSView *view in [NSArray arrayWithArray:[contentView subviews]])
		{
			[view removeFromSuperview];
			[contentView addSubview:view];
		}
	}
}

//
// validateMenuItem:
//
// Need to disable pause when not in a game
//
- (BOOL)validateMenuItem:(NSMenuItem *)item
{
	//
	// Finally start handling our own special cases...
	//
	if ([item action] == @selector(togglePause:))
	{
		if ([continueButton isHidden])
		{
			return NO;
		}
		else
		{
			return YES;
		}
	}

	//
	// Assume if we are in the responder chain then all other messages we
	// can respond to are enabled.
	//
	return YES;
}

//
// dealloc
//
// Releases instance memory.
//
- (void)dealloc
{
	for (NSString *gameObjectKey in frontLayers)
	{
		[[[GameData sharedGameData] gameObjects] removeObserver:self forKeyPath:gameObjectKey];
	}
	[frontLayers release];
	
	[[[GameData sharedGameData] gameData]
		removeObserver:self
		forKeyPath:GAME_DATA_MESSAGE_KEY];

	[[NSNotificationCenter defaultCenter]
		removeObserver:self];
	[super dealloc];
}

@end
