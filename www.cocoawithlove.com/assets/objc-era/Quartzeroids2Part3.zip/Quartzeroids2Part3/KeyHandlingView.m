//
//  KeyHandlingView.m
//  Quartzeroids2
//
//  Created by Matt Gallagher on 15/02/09.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file without charge in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "KeyHandlingView.h"
#import "GameData.h"
#import "GameController.h"

@implementation KeyHandlingView

//
// acceptFirstResponder
//
// We will accept key events.
//
- (BOOL)acceptsFirstResponder
{
	return YES;
}

//
// keyDown:
//
// Interpret key down.
//
- (void)keyDown:(NSEvent *)event
{
	NSString *characters = [event characters];
	if ([characters length] == 1 && ![event isARepeat])
	{
		const NSInteger ESCAPE_KEY_CODE = 27;
		
		unichar character = [characters characterAtIndex:0];
		if (character == NSLeftArrowFunctionKey)
		{
			[[GameData sharedGameData] setLeftKeyDown:YES];
		}
		else if (character == NSRightArrowFunctionKey)
		{
			[[GameData sharedGameData] setRightKeyDown:YES];
		}
		else if (character == NSUpArrowFunctionKey)
		{
			[[GameData sharedGameData] setUpKeyDown:YES];
		}
		else if (character == ' ')
		{
			[[GameData sharedGameData] setShootKeyDown:YES];
		}
		else if (character == ESCAPE_KEY_CODE)
		{
			[gameController togglePause:self];
		}
	}
}

//
// keyUp:
//
// Interpret key up.
//
- (void)keyUp:(NSEvent *)event
{
	NSString *characters = [event characters];
	if ([characters length] == 1)
	{
		unichar character = [characters characterAtIndex:0];
		if (character == NSLeftArrowFunctionKey)
		{
			[[GameData sharedGameData] setLeftKeyDown:NO];
		}
		else if (character == NSRightArrowFunctionKey)
		{
			[[GameData sharedGameData] setRightKeyDown:NO];
		}
		else if (character == NSUpArrowFunctionKey)
		{
			[[GameData sharedGameData] setUpKeyDown:NO];
		}
		else if (character == ' ')
		{
			[[GameData sharedGameData] setShootKeyDown:NO];
		}
	}
	
	[super keyUp:event];
}

@end
