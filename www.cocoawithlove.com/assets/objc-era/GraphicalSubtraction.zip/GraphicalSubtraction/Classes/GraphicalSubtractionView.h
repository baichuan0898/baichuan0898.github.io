//
//  GraphicalSubtractionView.h
//  GraphicalSubtraction
//
//  Created by Matt Gallagher on 2010/05/18.
//  Copyright 2010 Matt Gallagher. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface GraphicalSubtractionView : UIView {

}

- (CGGradientRef)backgroundGradient;

@end
