//
//  GraphicalSubtractionViewController.h
//  GraphicalSubtraction
//
//  Created by Matt Gallagher on 2010/05/18.
//  Copyright Matt Gallagher 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GraphicalSubtractionViewController : UIViewController {

}

@end

