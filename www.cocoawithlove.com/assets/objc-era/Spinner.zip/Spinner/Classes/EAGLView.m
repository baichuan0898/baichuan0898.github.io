//
//  EAGLView.m
//  Spinner
//
//  Created by Matt Gallagher on 2010/02/08.
//  Copyright Matt Gallagher 2010. All rights reserved.
//

#import "EAGLView.h"

#import "ES1Renderer.h"

void doNothingff(float *a, float *b)
{
}

void doNothingif(int *a, float *b)
{
}

@implementation EAGLView

@synthesize animating;

// You must implement this method
+ (Class)layerClass
{
    return [CAEAGLLayer class];
}

//The EAGL view is stored in the nib file. When it's unarchived it's sent -initWithCoder:
- (id)initWithCoder:(NSCoder*)coder
{    
    if ((self = [super initWithCoder:coder]))
    {
        // Get the layer
        CAEAGLLayer *eaglLayer = (CAEAGLLayer *)self.layer;

        eaglLayer.opaque = TRUE;
        eaglLayer.drawableProperties = [NSDictionary dictionaryWithObjectsAndKeys:
                                        [NSNumber numberWithBool:FALSE], kEAGLDrawablePropertyRetainedBacking, kEAGLColorFormatRGBA8, kEAGLDrawablePropertyColorFormat, nil];

        if (!renderer)
        {
            renderer = [[ES1Renderer alloc] init];

            if (!renderer)
            {
                [self release];
                return nil;
            }
        }

        animating = FALSE;
        animationTimer = nil;
    }

    return self;
}

- (void)fpsLog:(id)sender
{
	NSLog(@"FPS: %f", frames / 5.0);
	frames = 0;
}

- (void)drawView:(id)sender
{
	frames++;
    [renderer render];
}

- (void)layoutSubviews
{
    [renderer resizeFromLayer:(CAEAGLLayer*)self.layer];
    [self drawView:nil];
}

- (void)startAnimation
{
    if (!animating)
    {
        animationTimer = [NSTimer scheduledTimerWithTimeInterval:0.001 target:self selector:@selector(drawView:) userInfo:nil repeats:TRUE];
        fpsTimer = [NSTimer scheduledTimerWithTimeInterval:5.0 target:self selector:@selector(fpsLog:) userInfo:nil repeats:TRUE];

        animating = TRUE;
    }
}

- (void)stopAnimation
{
    if (animating)
    {
		[animationTimer invalidate];
		animationTimer = nil;
        animating = FALSE;
    }
}

- (void)dealloc
{
    [renderer release];

    [super dealloc];
}

@end
