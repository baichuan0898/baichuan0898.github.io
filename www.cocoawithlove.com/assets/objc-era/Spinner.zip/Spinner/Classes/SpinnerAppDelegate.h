//
//  SpinnerAppDelegate.h
//  Spinner
//
//  Created by Matt Gallagher on 2010/02/08.
//  Copyright Matt Gallagher 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@class EAGLView;

@interface SpinnerAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    EAGLView *glView;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet EAGLView *glView;

@end

