#include <stdio.h>
#include <stdlib.h>
#include <math.h>

enum
{
	ProcessName = 0,
	OutputFile,
	TableSteps,
	ArgumentCount
};

int main (int argc, const char * argv[])
{
	if (argc != ArgumentCount)
	{
		return 1;
	}
	
    FILE *outputFile = fopen(argv[OutputFile], "w");
	long tableSteps = strtol(argv[TableSteps], NULL, 10);
	
	fprintf(outputFile, "const float SinTable[%ld] = \n", tableSteps);
	fprintf(outputFile, "{\n");
	for (long i = 0; i < tableSteps; i++)
	{
		fprintf(outputFile, "    %ff,\n", 0.5f * sinf(i * 2.0f * 3.14159265f / tableSteps));
	}
	fprintf(outputFile, "\n};\n");
	fprintf(outputFile, "const long SinTableSize = %ld;", tableSteps);
	
    return 0;
}
