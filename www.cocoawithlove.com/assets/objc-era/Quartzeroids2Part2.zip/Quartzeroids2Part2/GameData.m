//
//  GameData.m
//  Quartzeroids2
//
//  Created by Matt Gallagher on 15/02/09.
//  Copyright 2009 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file without charge in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "GameData.h"
#import "SynthesizeSingleton.h"
#import "GameObject.h"
#include <mach/mach_time.h>

NSString *GAME_OBJECT_NEW_NOTIFICATION = @"GameObjectNewNotification";

const double GAME_ASPECT = 16.0 / 10.0;
const double GAME_UPDATE_DURATION = 0.03;

NSString *GAME_PLAYER_KEY = @"player";
NSString *GAME_SHOT_KEY_BASE = @"shot";
NSString *GAME_ASTEROID_KEY_BASE = @"asteroid";

@implementation GameData

SYNTHESIZE_SINGLETON_FOR_CLASS(GameData);

//
// init
//
// Init method for the object.
//
- (id)init
{
	self = [super init];
	if (self != nil)
	{
		gameObjects = [[NSMutableDictionary alloc] init];

		srandom((unsigned)(mach_absolute_time() & 0xFFFFFFFF));
	}
	return self;
}

//
// gameWidth
//
// Returns the width for the game area. Defaults to screen width.
//
- (double)gameWidth
{
	static double gameWidth = 0;
	
	if (gameWidth == 0)
	{
		NSSize screenSize = [[NSScreen mainScreen] frame].size;
		if ((screenSize.width / screenSize.height) > GAME_ASPECT)
		{
			screenSize.width = screenSize.height * GAME_ASPECT;
		}
		gameWidth = screenSize.width;
	}

	return gameWidth;
}

//
// gameHeight
//
// Returns the height for the game area. Defaults to screen height.
//
- (double)gameHeight
{
	static double gameHeight = 0;
	
	if (gameHeight == 0)
	{
		NSSize screenSize = [[NSScreen mainScreen] frame].size;
		if ((screenSize.width / screenSize.height) < GAME_ASPECT)
		{
			screenSize.height = screenSize.width / GAME_ASPECT;
		}
		gameHeight = screenSize.height;
	}

	return gameHeight;
}

#pragma mark gameObjects accessors

//
// gameObjects
//
// Accessor for the dictionary of game objects
//
- (NSDictionary *)gameObjects
{
	return gameObjects;
}

#pragma mark gameObjects Management

//
// addGameObject:forKey:
//
// The object is added to the gameObjects dictionary
// using the "name" as a key and notification is sent.
//
- (void)addGameObject:(GameObject *)newGameObject forKey:(NSString *)gameObjectKey
{
	[gameObjects setObject:newGameObject forKey:gameObjectKey];
	newGameObject.keyInGameData = gameObjectKey;
	
	[[NSNotificationCenter defaultCenter]
		postNotificationName:GAME_OBJECT_NEW_NOTIFICATION object:gameObjectKey];
}

//
// removeGameObjectForKey:
//
// The object is removed from the gameObjects dictionary
// using the "name" as a key.
//
- (void)removeGameObjectForKey:(NSString *)gameObjectKey
{
	((GameObject *)[gameObjects objectForKey:gameObjectKey]).keyInGameData = nil;
	[gameObjects removeObjectForKey:gameObjectKey];
}

#pragma mark Game Loops

//
// newGame
//
// Temporary code to create test objects for the game.
//
- (void)newGame
{
	[gameObjects removeAllObjects];

	const double PLAYER_SIZE = 0.075;

	GameObject *player = [[GameObject alloc]
		initWithImageName:@"ship"
		x:0.5 * GAME_ASPECT
		y:0.5
		width:PLAYER_SIZE
		height:PLAYER_SIZE
		visible:YES];
	[[GameData sharedGameData] addGameObject:player forKey:GAME_PLAYER_KEY];

	const double ASTEROID_LARGE_SIZE = 0.1;
	const double ASTEROID_START_RADIUS = 0.40;
	const double ASTEROID_MIN_SPEED = 0.033;
	const double ASTEROID_MAX_SPEED = 0.166;
	NSInteger i;
	for (i = 0; i < 3; i++)
	{
		double angle = 2.0 * M_PI * (double)random() / (double)INT_MAX;
		double x = 0.5 * GAME_ASPECT + ASTEROID_START_RADIUS * cos(angle);
		double y = 0.5 + ASTEROID_START_RADIUS * sin(angle);
		
		GameObject *asteroid = [[GameObject alloc]
			initWithImageName:@"asteroid-back"
			x:x
			y:y
			width:ASTEROID_LARGE_SIZE
			height:ASTEROID_LARGE_SIZE
			visible:YES];
		[[GameData sharedGameData]
			addGameObject:asteroid
			forKey:[NSString stringWithFormat:@"%@%ld", GAME_ASTEROID_KEY_BASE, i]];
		asteroid.trajectory = 2.0 * M_PI * (double)random() / (double)INT_MAX;
		asteroid.speed =
			ASTEROID_MIN_SPEED +
			(ASTEROID_MAX_SPEED - ASTEROID_MIN_SPEED) *
				(double)random() / (double)INT_MAX;
	}

	const double SHOT_SIZE = 0.02;
	GameObject *shot = [[GameObject alloc]
		initWithImageName:@"shot-frame1"
		x:0.5 * GAME_ASPECT
		y:0.5 + PLAYER_SIZE
		width:SHOT_SIZE
		height:SHOT_SIZE
		visible:YES];
	[[GameData sharedGameData]
		addGameObject:shot
		forKey:[NSString stringWithFormat:@"%@%ld", GAME_SHOT_KEY_BASE, i]];
	shot.trajectory = M_PI_2;
	shot.speed = ASTEROID_MAX_SPEED;

	[self changeRunSelector:@selector(updateLevel:)];
}

//
// updateLevel
//
// Updates the game state
//
- (void)updateLevel:(NSTimer *)aTimer
{
	if (lastUpdate)
	{
		frameDuration = [[NSDate date] timeIntervalSinceDate:lastUpdate];
		[lastUpdate release];
		lastUpdate = [[NSDate alloc] init];
	}
	else
	{
		frameDuration = GAME_UPDATE_DURATION;
	}
	
	NSArray *allKeys = [gameObjects allKeys];
	for (NSString *gameObjectKey in allKeys)
	{
		[gameObjects willChangeValueForKey:gameObjectKey];
		GameObject *gameObject = [gameObjects objectForKey:gameObjectKey];
		if ([gameObject updateWithTimeInterval:frameDuration])
		{
			[gameObjects removeObjectForKey:gameObjectKey];
		}
		[gameObjects didChangeValueForKey:gameObjectKey];
	}
}

//
// startUpdates
//
// Starts the update timer.
//
- (void)startUpdates
{
	[lastUpdate release];
	lastUpdate = nil;
	
	timer =
		[NSTimer
			scheduledTimerWithTimeInterval:GAME_UPDATE_DURATION
			target:self
			selector:updateSelector
			userInfo:nil
			repeats:YES];
}

//
// stopUpdates
//
// Removes the timer.
//
- (void)stopUpdates
{
	[timer invalidate];
	timer = nil;
}

//
// changeRunSelector:
//
// Switches to a new run loop selector
//
- (void)changeRunSelector:(SEL)newSelector
{
	[self stopUpdates];
	updateSelector = newSelector;
	[self startUpdates];
}

@end
