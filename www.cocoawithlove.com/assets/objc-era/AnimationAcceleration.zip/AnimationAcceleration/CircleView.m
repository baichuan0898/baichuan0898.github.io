//
//  CircleView.m
//  AnimationAcceleration
//
//  Created by Matt Gallagher on 7/09/08.
//  Copyright 2008 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file without charge in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "CircleView.h"


@implementation CircleView

- (id)initWithSize:(CGFloat)newSize color:(NSColor *)newColor
{
	NSRect newFrame = NSMakeRect(0, 0, newSize + 2, newSize + 2);
	self = [super initWithFrame:newFrame];
	if (self)
	{
		color = [newColor retain];
	}
	return self;
}

- (void)dealloc
{
	[color release];
	[super dealloc];
}

- (void)drawRect:(NSRect)rect
{
	NSBezierPath *path = [NSBezierPath bezierPathWithOvalInRect:NSInsetRect(self.bounds, 1, 1)];
	[color set];
	[path fill];
	[[NSColor blackColor] set];
	[path setLineWidth:1.0];
	[path stroke];
}

@end
