//
//  AnimationView.m
//  AnimationAcceleration
//
//  Created by Matt Gallagher on 7/09/08.
//  Copyright 2008 Matt Gallagher. All rights reserved.
//
//  Permission is given to use this source code file without charge in any
//  project, commercial or otherwise, entirely at your risk, with the condition
//  that any redistribution (in part or whole) of source code must retain
//  this copyright and permission notice. Attribution in compiled projects is
//  appreciated but not required.
//

#import "AnimationView.h"
#import "CircleView.h"
#import "Evaluate.h"
#import <QuartzCore/CoreAnimation.h>

const int INTERSTITIAL_STEPS = 99;
#define PIX_ALIGN(x) (floor(x) + 0.5)

@implementation AnimationView

- (id)initWithFrame:(NSRect)frame
{
	self = [super initWithFrame:frame];
	if (self)
	{
		configurations =
			[[NSArray arrayWithObjects:
				[NSDictionary dictionaryWithObjectsAndKeys:
					[[[BezierEvaluator alloc] initWithFirst:1.0 / 3.0 second:2.0 / 3.0] autorelease], @"evaluator",
					NSLocalizedString(@"Linear", nil), @"name",
					nil],
				[NSDictionary dictionaryWithObjectsAndKeys:
					[[[BezierEvaluator alloc] initWithFirst:0.0 second:1.0] autorelease], @"evaluator",
					NSLocalizedString(@"Ease In, Ease Out", nil), @"name",
					nil],
				[NSDictionary dictionaryWithObjectsAndKeys:
					[[[BezierEvaluator alloc] initWithFirst:0.0 second:1.0 / 3.0] autorelease], @"evaluator",
					NSLocalizedString(@"Quadratic acceleration", nil), @"name",
					nil],
				[NSDictionary dictionaryWithObjectsAndKeys:
					[[[ExponentialDecayEvaluator alloc] initWithCoefficient:6.0] autorelease], @"evaluator",
					NSLocalizedString(@"Exponential Decay", nil), @"name",
					nil],
				[NSDictionary dictionaryWithObjectsAndKeys:
					[[[SecondOrderResponseEvaluator alloc] initWithOmega:20.0 zeta:0.33] autorelease], @"evaluator",
					NSLocalizedString(@"Second Order System Response", nil), @"name",
					nil],
				nil]
			retain];
		currentConfiguration = [configurations objectAtIndex:0];
	}
	return self;
}

- (void)dealloc
{
	[configurations release];
	[super dealloc];
}

- (void)setCurrentConfiguration:(NSDictionary *)newConfiguration
{
	// Set but don't retain. It's assumed that "configurations" already retains
	// it.
	currentConfiguration = newConfiguration;
	
	// Restart the animations.
	[[linearDot layer] removeAllAnimations];
	[[acceleratedDot layer] removeAllAnimations];
}

- (void)awakeFromNib
{
	// Create the two dot objects that we'll animate and add them to the view.
	linearDot = [[[CircleView alloc] initWithSize:5.0 color:[NSColor grayColor]] autorelease];
	[self addSubview:linearDot];
	[[linearDot layer] setAnchorPoint:CGPointMake(0.5, 0.5)];
	[[linearDot layer] setPosition:NSPointToCGPoint([self originPoint])];
	acceleratedDot = [[[CircleView alloc] initWithSize:9.0 color:[NSColor redColor]] autorelease];
	[self addSubview:acceleratedDot];
	[[acceleratedDot layer] setAnchorPoint:CGPointMake(0.5, 0.5)];
	[[acceleratedDot layer] setPosition:NSPointToCGPoint([self originPoint])];

	// Start the animations deferred, otherwise the won't work (don't know why)
	[self performSelector:@selector(startAnimations) withObject:nil afterDelay:0.0];
}

- (void)startAnimations
{
	// Move the two dot objects to the origin without animating
	[CATransaction begin];
	[CATransaction setValue:(id)kCFBooleanTrue forKey:kCATransactionDisableActions];
	[[acceleratedDot layer] setPosition:NSPointToCGPoint([self originPoint])];
	[[linearDot layer] setPosition:NSPointToCGPoint([self originPoint])];
	[CATransaction commit];
	
	[CATransaction flush];

	// Now, move the two dot objects to their final positions, using the default
	// animation for the linearDot and the "currentConfiguration" animation for
	// the acceleratedDot.
	[CATransaction begin];
	[CATransaction setValue:(id)kCFBooleanFalse forKey:kCATransactionDisableActions];
	[CATransaction setValue:[NSNumber numberWithFloat:2.5] forKey:kCATransactionAnimationDuration];
	[[linearDot layer] setPosition:NSPointToCGPoint([self maxXPoint])];
	AccelerationAnimation *animation =
		[AccelerationAnimation
			animationWithKeyPath:@"position.y"
			startValue:[self originPoint].y
			endValue:[self maxYPoint].y
			evaluationObject:[currentConfiguration objectForKey:@"evaluator"]
			interstitialSteps:INTERSTITIAL_STEPS];
	[animation setDelegate:self];
	[[acceleratedDot layer] setValue:[NSNumber numberWithDouble:[self maxYPoint].y] forKeyPath:@"position.y"];
	[[acceleratedDot layer] addAnimation:animation forKey:@"position"];
	[CATransaction commit];
	
	[self setNeedsDisplay:YES];
}

- (NSPoint)originPoint
{
	return
		NSMakePoint(
			self.bounds.origin.x + 0.1 * self.bounds.size.width,
			self.bounds.origin.y + 0.1 * self.bounds.size.height);
}

- (NSPoint)maxXPoint
{
	return
		NSMakePoint(
			self.bounds.origin.x + 0.9 * self.bounds.size.width,
			self.bounds.origin.y + 0.1 * self.bounds.size.height);
}

- (NSPoint)maxYPoint
{
	return
		NSMakePoint(
			self.bounds.origin.x + 0.1 * self.bounds.size.width,
			self.bounds.origin.y + 0.7 * self.bounds.size.height);
}

- (NSPoint)overshootYPoint
{
	return
		NSMakePoint(
			self.bounds.origin.x + 0.1 * self.bounds.size.width,
			self.bounds.origin.y + 0.9 * self.bounds.size.height);
}

- (void)drawRect:(NSRect)rect
{
	// Fill the background with a gradient. Light gray (top) to white (bottom).
	NSGradient* aGradient =
		[[[NSGradient alloc]
			initWithColorsAndLocations:
				[NSColor whiteColor], (CGFloat)0.0,
				[NSColor lightGrayColor], (CGFloat)1.0,
				nil]
		autorelease];
	[aGradient drawInRect:self.bounds angle:90];
	
	// Draw the axes. Inset all around by 10% of window width. The vertical
	// axes will be 0 to 1.5, the horizontal will be 0 to 1. Tick marks will
	// be shown at 1 (the endpoint of animation) on both axes.
	//
	// The "floor(value) + 0.5" is to align the lines with pixel boundaries.
	CGContextRef context = [[NSGraphicsContext currentContext] graphicsPort];
	NSPoint originPoint = [self originPoint];
	NSPoint maxXPoint = [self maxXPoint];
	NSPoint maxYPoint = [self maxYPoint];
	NSPoint overshootYPoint = [self overshootYPoint];
	CGContextMoveToPoint(context, PIX_ALIGN(originPoint.x), PIX_ALIGN(originPoint.y));
	CGContextAddLineToPoint(context, PIX_ALIGN(maxXPoint.x), PIX_ALIGN(maxXPoint.y));
	CGContextMoveToPoint(context, PIX_ALIGN(originPoint.x), PIX_ALIGN(originPoint.y));
	CGContextAddLineToPoint(context, PIX_ALIGN(overshootYPoint.x), PIX_ALIGN(overshootYPoint.y));
	CGContextMoveToPoint(context, PIX_ALIGN(maxYPoint.x) - 5, PIX_ALIGN(maxYPoint.y));
	CGContextAddLineToPoint(context, PIX_ALIGN(maxYPoint.x) + 5, PIX_ALIGN(maxYPoint.y));
	CGContextMoveToPoint(context, PIX_ALIGN(maxXPoint.x), PIX_ALIGN(maxXPoint.y) + 5);
	CGContextAddLineToPoint(context, PIX_ALIGN(maxXPoint.x), PIX_ALIGN(maxXPoint.y) - 5);
	CGContextSetLineWidth(context, 1.0);
	CGContextSetRGBStrokeColor(context, 0.5, 0.5, 0.5, 1.0);
	CGContextStrokePath(context);
	
	// Draw the acceleration curve by fetching the value of each interstitial
	// from the evaluation object.
	NSObject<Evaluate> *evaluator = [currentConfiguration objectForKey:@"evaluator"];
	CGContextMoveToPoint(context, floor(originPoint.x) + 0.5, floor(originPoint.y) + 0.5);
	double x;
	double stepSize = 1.0 / ((double)INTERSTITIAL_STEPS + 1.0);
	for (x = 0; x < 1.0; x += stepSize)
	{
		CGContextAddLineToPoint(context,
			originPoint.x + x * (maxXPoint.x - originPoint.x),
			originPoint.y + [evaluator evaluateAt:x] * (maxYPoint.y - originPoint.y));
	}
	CGContextAddLineToPoint(context, maxXPoint.x, maxYPoint.y);
	CGContextSetRGBStrokeColor(context, 0.0, 0.0, 0.0, 1.0);
	CGContextStrokePath(context);
}

- (void)animationDidStop:(CAAnimation *)theAnimation finished:(BOOL)flag
{
	[self startAnimations];
}

@end
